import React, { createContext, useContext, useState, useEffect } from 'react';
import { Invoice, Client, Build, TabType, InventoryItem, CardTransaction, CardType, CardBrand } from './types.ts';
import { INITIAL_CLIENTS, INITIAL_BUILDS, INITIAL_INVOICES, INITIAL_TRANSACTIONS } from './data.ts';
import { auth, googleAuthProvider } from './lib/firebase.ts';
import { User, signInWithPopup, signOut, onAuthStateChanged } from 'firebase/auth';

export interface SyncNotificationState {
  id: string;
  isOpen: boolean;
  type: 'build' | 'ledger' | 'client';
  actionName: string;
  status: 'syncing' | 'synced' | 'error';
  errorMessage?: string;
}

interface StateContextProps {
  user: User | null;
  loading: boolean;
  invoices: Invoice[];
  clients: Client[];
  builds: Build[];
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  signInWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  addInvoice: (invoice: Omit<Invoice, 'id'>) => Promise<void>;
  addClient: (client: Omit<Client, 'id' | 'outstandingBalance' | 'lifetimeSpend'>) => Promise<void>;
  addBuild: (build: Omit<Build, 'id' | 'greaseMonkeyNotes'>) => Promise<void>;
  updateBuildStatus: (id: string, status: Build['status']) => Promise<void>;
  updateBuildFabricationNotes: (id: string, fabricationNotes: string) => Promise<void>;
  archiveBuild: (id: string, isArchived: boolean) => Promise<void>;
  addBuildNote: (buildId: string, note: string) => Promise<void>;
  deleteInvoice: (id: string) => Promise<void>;
  deleteClient: (id: string) => Promise<void>;
  deleteBuild: (id: string) => Promise<void>;
  refetchAll: () => Promise<void>;
  globalSearchQuery: string;
  setGlobalSearchQuery: (query: string) => void;
  syncState: SyncNotificationState | null;
  dismissSyncState: () => void;
  inventory: InventoryItem[];
  lowStockThreshold: number;
  updateInventoryStock: (id: string, stock: number) => void;
  updateLowStockThreshold: (threshold: number) => void;
  addInventoryItem: (name: string, unitType: string, stock: number) => void;
  deleteInventoryItem: (id: string) => void;
  transactions: CardTransaction[];
  processCardTransaction: (params: {
    customerId: string;
    customerName: string;
    invoiceId?: string;
    amount: number;
    cardType: CardType;
    cardBrand: CardBrand;
    cardNumber: string;
    cardholderName: string;
    notes?: string;
    passFeeToCustomer?: boolean;
  }) => Promise<CardTransaction>;
  refundCardTransaction: (transactionId: string) => Promise<void>;
  updateInvoiceStatus: (invoiceId: string, status: Invoice['status']) => Promise<void>;
}

const StateContext = createContext<StateContextProps | undefined>(undefined);

const INITIAL_INVENTORY: InventoryItem[] = [
  { id: 'inv-1', name: 'Structural Steel Tubing (HSS)', unitType: 'meters', stock: 12 },
  { id: 'inv-2', name: '6061-T6 Aluminum Plate', unitType: 'sheets', stock: 4 },
  { id: 'inv-3', name: 'Stainless Steel Plate (304)', unitType: 'sheets', stock: 3 },
  { id: 'inv-4', name: 'Heavy Duty Grade-8 Fastener Pack', unitType: 'kits', stock: 25 },
  { id: 'inv-5', name: 'EPDM Rubber Damper strip', unitType: 'meters', stock: 8 },
  { id: 'inv-6', name: 'Industrial Rust-Inhibiting Primer', unitType: 'cans', stock: 15 },
  { id: 'inv-7', name: 'Powder Coat Pigment (Gloss Black)', unitType: 'lbs', stock: 5 }
];

export const StateProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [invoices, setInvoices] = useState<Invoice[]>(INITIAL_INVOICES);
  const [clients, setClients] = useState<Client[]>(INITIAL_CLIENTS);
  const [builds, setBuilds] = useState<Build[]>(INITIAL_BUILDS);
  const [activeTab, setActiveTab] = useState<TabType>('billing');
  const [globalSearchQuery, setGlobalSearchQuery] = useState('');

  const [transactions, setTransactions] = useState<CardTransaction[]>(() => {
    const saved = localStorage.getItem('fs_card_transactions');
    if (!saved) return INITIAL_TRANSACTIONS;
    try {
      return JSON.parse(saved);
    } catch {
      return INITIAL_TRANSACTIONS;
    }
  });

  useEffect(() => {
    localStorage.setItem('fs_card_transactions', JSON.stringify(transactions));
  }, [transactions]);

  const [inventory, setInventory] = useState<InventoryItem[]>(() => {
    const saved = localStorage.getItem('fs_inventory');
    if (!saved) return INITIAL_INVENTORY;
    try {
      const parsed: InventoryItem[] = JSON.parse(saved);
      const seen = new Set<string>();
      return parsed.map((item, idx) => {
        if (!item.id || seen.has(item.id)) {
          const uniqueId = `inv-${Date.now()}-${idx}-${Math.random().toString(36).substring(2, 7)}`;
          seen.add(uniqueId);
          return { ...item, id: uniqueId };
        }
        seen.add(item.id);
        return item;
      });
    } catch {
      return INITIAL_INVENTORY;
    }
  });

  const [lowStockThreshold, setLowStockThreshold] = useState<number>(() => {
    const saved = localStorage.getItem('fs_low_stock_threshold');
    return saved ? Number(saved) : 10;
  });

  useEffect(() => {
    localStorage.setItem('fs_inventory', JSON.stringify(inventory));
  }, [inventory]);

  useEffect(() => {
    localStorage.setItem('fs_low_stock_threshold', String(lowStockThreshold));
  }, [lowStockThreshold]);

  const updateInventoryStock = (id: string, stock: number) => {
    setInventory(prev => prev.map(item => item.id === id ? { ...item, stock: Math.max(0, stock) } : item));
  };

  const updateLowStockThreshold = (threshold: number) => {
    setLowStockThreshold(Math.max(0, threshold));
  };

  const addInventoryItem = (name: string, unitType: string, stock: number) => {
    const newItem: InventoryItem = {
      id: `inv-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      name,
      unitType,
      stock: Math.max(0, stock)
    };
    setInventory(prev => [...prev, newItem]);
  };

  const deleteInventoryItem = (id: string) => {
    setInventory(prev => prev.filter(item => item.id !== id));
  };

  // Sync Notification state
  const [syncState, setSyncState] = useState<SyncNotificationState | null>(null);

  // Monitor Firebase Auth state
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      if (firebaseUser) {
        try {
          // Sync/register user in our PostgreSQL backend
          const token = await firebaseUser.getIdToken();
          const response = await fetch('/api/auth/register', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${token}`,
            },
          });
          if (!response.ok) {
            console.error('Failed to register/sync user profile in database:', await response.text());
          }
          
          // Fetch initial user records from Postgres
          await loadUserData(firebaseUser);
        } catch (error) {
          console.error('Error in auth state change sequence:', error);
        }
      } else {
        setInvoices(INITIAL_INVOICES);
        setClients(INITIAL_CLIENTS);
        setBuilds(INITIAL_BUILDS);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Fetch all user records from API
  const loadUserData = async (currentUser: User) => {
    try {
      const token = await currentUser.getIdToken();
      
      const [clientsRes, buildsRes, invoicesRes] = await Promise.all([
        fetch('/api/clients', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/builds', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/invoices', { headers: { Authorization: `Bearer ${token}` } }),
      ]);

      if (clientsRes.ok && buildsRes.ok && invoicesRes.ok) {
        const clientsData = await clientsRes.json();
        const buildsData = await buildsRes.json();
        const invoicesData = await invoicesRes.json();

        setClients(clientsData);
        setBuilds(buildsData);
        setInvoices(invoicesData);
      } else {
        console.error('Failed to load user data from backend');
      }
    } catch (error) {
      console.error('Error fetching data from API:', error);
    }
  };

  const refetchAll = async () => {
    if (user) {
      await loadUserData(user);
    }
  };

  const signInWithGoogle = async () => {
    setLoading(true);
    try {
      await signInWithPopup(auth, googleAuthProvider);
    } catch (error) {
      console.error('Login failed:', error);
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    setLoading(true);
    try {
      await signOut(auth);
    } catch (error) {
      console.error('Signout failed:', error);
    } finally {
      setLoading(false);
    }
  };

  // Helper for authenticated requests
  const authenticatedFetch = async (url: string, options: RequestInit = {}) => {
    if (!user) {
      throw new Error('No authenticated user found');
    }
    const token = await user.getIdToken();
    const headers = {
      ...options.headers,
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    };
    return fetch(url, { ...options, headers });
  };

  // Notification triggers
  const triggerSync = (type: 'build' | 'ledger' | 'client', actionName: string): string => {
    const id = String(Date.now());
    setSyncState({
      id,
      isOpen: true,
      type,
      actionName,
      status: 'syncing',
    });
    return id;
  };

  const resolveSync = (id: string) => {
    setSyncState((prev) => {
      if (prev && prev.id === id) {
        setTimeout(() => {
          setSyncState((current) => (current && current.id === id ? { ...current, isOpen: false } : current));
        }, 3000);
        return { ...prev, status: 'synced' };
      }
      return prev;
    });
  };

  const failSync = (id: string, errorMessage?: string) => {
    setSyncState((prev) => {
      if (prev && prev.id === id) {
        setTimeout(() => {
          setSyncState((current) => (current && current.id === id ? { ...current, isOpen: false } : current));
        }, 4000);
        return { ...prev, status: 'error', errorMessage };
      }
      return prev;
    });
  };

  const dismissSyncState = () => {
    setSyncState(null);
  };

  const addInvoice = async (invoiceData: Omit<Invoice, 'id'>) => {
    const syncId = triggerSync('ledger', 'Adding invoice ledger entry');
    try {
      const nextId = `#FS-2024-${String(invoices.length + 1).padStart(3, '0')}`;
      const newInvoice: Invoice = {
        ...invoiceData,
        id: nextId,
      };
      const res = await authenticatedFetch('/api/invoices', {
        method: 'POST',
        body: JSON.stringify(newInvoice),
      });
      if (res.ok) {
        await refetchAll();
        resolveSync(syncId);
      } else {
        console.error('Failed to add invoice');
        failSync(syncId, 'Server rejected invoice entry');
      }
    } catch (error) {
      console.error('addInvoice error:', error);
      failSync(syncId, 'Connection failed while persisting entry');
    }
  };

  const addClient = async (clientData: Omit<Client, 'id' | 'outstandingBalance' | 'lifetimeSpend'>) => {
    const syncId = triggerSync('client', 'Adding client account');
    try {
      const nextId = `C-${String(clients.length + 1).padStart(3, '0')}`;
      const newClient: Client = {
        ...clientData,
        id: nextId,
        outstandingBalance: 0,
        lifetimeSpend: 0,
      };
      const res = await authenticatedFetch('/api/clients', {
        method: 'POST',
        body: JSON.stringify(newClient),
      });
      if (res.ok) {
        await refetchAll();
        resolveSync(syncId);
      } else {
        console.error('Failed to add client');
        failSync(syncId, 'Server rejected client entry');
      }
    } catch (error) {
      console.error('addClient error:', error);
      failSync(syncId, 'Connection failed while adding client');
    }
  };

  const addBuild = async (buildData: Omit<Build, 'id' | 'greaseMonkeyNotes'>) => {
    const syncId = triggerSync('build', 'Creating custom blueprint pipeline');
    try {
      const nextId = `B-${String(builds.length + 101)}`;
      const newBuild: Build = {
        ...buildData,
        id: nextId,
        greaseMonkeyNotes: ['Project initiated.', 'CAD layout conceptualized.'],
      };
      const res = await authenticatedFetch('/api/builds', {
        method: 'POST',
        body: JSON.stringify(newBuild),
      });
      if (res.ok) {
        await refetchAll();
        resolveSync(syncId);
      } else {
        console.error('Failed to add build');
        failSync(syncId, 'Server rejected build creation');
      }
    } catch (error) {
      console.error('addBuild error:', error);
      failSync(syncId, 'Connection failed while adding build');
    }
  };

  const updateBuildStatus = async (id: string, status: Build['status']) => {
    const syncId = triggerSync('build', `Updating status of build [${id}]`);
    try {
      const b = builds.find(item => item.id === id);
      if (!b) {
        failSync(syncId, 'Build not found in memory');
        return;
      }

      let actualCost = b.actualCost;
      let completionDate = b.completionDate;

      if (status === 'COMPLETED' || status === 'DELIVERED') {
        actualCost = b.estimatedCost;
        completionDate = new Date().toLocaleDateString('en-US', {
          month: 'short',
          day: '2-digit',
          year: 'numeric',
        });
      }

      const noteToAppend = `Status updated to [${status}] on ${new Date().toLocaleDateString()}`;

      const res = await authenticatedFetch(`/api/builds/${id}/status`, {
        method: 'PUT',
        body: JSON.stringify({
          status,
          actualCost,
          completionDate,
          noteToAppend,
        }),
      });

      if (res.ok) {
        await refetchAll();
        resolveSync(syncId);
      } else {
        console.error('Failed to update build status');
        failSync(syncId, 'Server rejected status revision');
      }
    } catch (error) {
      console.error('updateBuildStatus error:', error);
      failSync(syncId, 'Connection lost during status change');
    }
  };

  const updateBuildFabricationNotes = async (id: string, fabricationNotes: string) => {
    const syncId = triggerSync('build', `Saving blueprint specifications for [${id}]`);
    try {
      const res = await authenticatedFetch(`/api/builds/${id}/fabrication-notes`, {
        method: 'PUT',
        body: JSON.stringify({ fabricationNotes }),
      });
      if (res.ok) {
        await refetchAll();
        resolveSync(syncId);
      } else {
        console.error('Failed to update build fabrication notes');
        failSync(syncId, 'Server rejected fabrication specs save');
      }
    } catch (error) {
      console.error('updateBuildFabricationNotes error:', error);
      failSync(syncId, 'Connection lost during fabrication update');
    }
  };

  const archiveBuild = async (id: string, isArchived: boolean) => {
    const syncId = triggerSync('build', isArchived ? `Archiving blueprint [${id}]` : `Restoring blueprint [${id}]`);
    try {
      const res = await authenticatedFetch(`/api/builds/${id}/archive`, {
        method: 'PUT',
        body: JSON.stringify({ isArchived }),
      });
      if (res.ok) {
        await refetchAll();
        resolveSync(syncId);
      } else {
        console.error('Failed to archive build');
        failSync(syncId, 'Server rejected archive/restore command');
      }
    } catch (error) {
      console.error('archiveBuild error:', error);
      failSync(syncId, 'Connection failed during archiver sync');
    }
  };

  const addBuildNote = async (buildId: string, note: string) => {
    const syncId = triggerSync('build', 'Logging workshop note');
    try {
      const timestamp = new Date().toLocaleDateString('en-US', {
        month: 'short',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
      });
      const formattedNote = `${timestamp}: ${note}`;
      
      const res = await authenticatedFetch(`/api/builds/${buildId}/note`, {
        method: 'POST',
        body: JSON.stringify({ note: formattedNote }),
      });

      if (res.ok) {
        await refetchAll();
        resolveSync(syncId);
      } else {
        console.error('Failed to add build note');
        failSync(syncId, 'Server rejected log entry');
      }
    } catch (error) {
      console.error('addBuildNote error:', error);
      failSync(syncId, 'Connection failed while uploading note');
    }
  };

  const deleteInvoice = async (id: string) => {
    const syncId = triggerSync('ledger', `Deleting invoice ${id}`);
    try {
      const res = await authenticatedFetch(`/api/invoices/${id}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        await refetchAll();
        resolveSync(syncId);
      } else {
        console.error('Failed to delete invoice');
        failSync(syncId, 'Server blocked invoice removal');
      }
    } catch (error) {
      console.error('deleteInvoice error:', error);
      failSync(syncId, 'Connection failed during invoice delete');
    }
  };

  const deleteClient = async (id: string) => {
    const syncId = triggerSync('client', `Removing client account ${id}`);
    try {
      const res = await authenticatedFetch(`/api/clients/${id}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        await refetchAll();
        resolveSync(syncId);
      } else {
        console.error('Failed to delete client');
        failSync(syncId, 'Server blocked client deletion');
      }
    } catch (error) {
      console.error('deleteClient error:', error);
      failSync(syncId, 'Connection failed during client delete');
    }
  };

  const deleteBuild = async (id: string) => {
    const syncId = triggerSync('build', `Deleting blueprint pipeline [${id}]`);
    try {
      const res = await authenticatedFetch(`/api/builds/${id}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        await refetchAll();
        resolveSync(syncId);
      } else {
        console.error('Failed to delete build');
        failSync(syncId, 'Server blocked blueprint deletion');
      }
    } catch (error) {
      console.error('deleteBuild error:', error);
      failSync(syncId, 'Connection failed during build delete');
    }
  };

  const processCardTransaction = async (params: {
    customerId: string;
    customerName: string;
    invoiceId?: string;
    amount: number;
    cardType: CardType;
    cardBrand: CardBrand;
    cardNumber: string;
    cardholderName: string;
    notes?: string;
    passFeeToCustomer?: boolean;
  }): Promise<CardTransaction> => {
    const rawNum = params.cardNumber.replace(/\D/g, '');
    const lastFour = rawNum.length >= 4 ? rawNum.slice(-4) : '4242';
    const authCode = `AUTH-${Math.floor(100000 + Math.random() * 900000)}`;
    const txnId = `TXN-${Math.floor(100000 + Math.random() * 900000)}`;
    
    const timestamp = new Date().toLocaleDateString('en-US', {
      month: 'short',
      day: '2-digit',
      year: 'numeric'
    }) + ' - ' + new Date().toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit'
    });

    const processingFee = params.cardType === 'debit' 
      ? 0 
      : Number(((params.amount * 0.029) + 0.30).toFixed(2));

    const newTxn: CardTransaction = {
      id: txnId,
      timestamp,
      customerId: params.customerId,
      customerName: params.customerName,
      invoiceId: params.invoiceId,
      amount: params.amount,
      cardType: params.cardType,
      cardBrand: params.cardBrand,
      lastFour,
      cardholderName: params.cardholderName || params.customerName,
      status: 'APPROVED',
      authCode,
      notes: params.notes || `Processed via ${params.cardType.toUpperCase()} Card terminal.`,
      processingFee,
      passFeeToCustomer: params.passFeeToCustomer
    };

    setTransactions(prev => [newTxn, ...prev]);

    // If attached to an invoice, mark invoice as PAID
    if (params.invoiceId) {
      setInvoices(prev => prev.map(inv => inv.id === params.invoiceId ? { ...inv, status: 'PAID' } : inv));
      if (user) {
        try {
          await authenticatedFetch(`/api/invoices/${params.invoiceId}/status`, {
            method: 'PUT',
            body: JSON.stringify({ status: 'PAID' })
          });
        } catch (err) {
          console.error('Failed to sync invoice status:', err);
        }
      }
    }

    // Update client balance & spend
    setClients(prev => prev.map(c => {
      if (c.id === params.customerId) {
        const newBal = Math.max(0, c.outstandingBalance - params.amount);
        const newSpend = c.lifetimeSpend + params.amount;
        return { ...c, outstandingBalance: newBal, lifetimeSpend: newSpend };
      }
      return c;
    }));

    const syncId = triggerSync('ledger', `Approved ${params.cardType.toUpperCase()} Card ($${params.amount.toLocaleString()}) for ${params.customerName}`);
    resolveSync(syncId);

    return newTxn;
  };

  const refundCardTransaction = async (transactionId: string) => {
    const targetTxn = transactions.find(t => t.id === transactionId);
    if (!targetTxn || targetTxn.status === 'REFUNDED') return;

    setTransactions(prev => prev.map(t => t.id === transactionId ? { ...t, status: 'REFUNDED' } : t));

    setClients(prev => prev.map(c => {
      if (c.id === targetTxn.customerId) {
        return {
          ...c,
          outstandingBalance: c.outstandingBalance + targetTxn.amount,
          lifetimeSpend: Math.max(0, c.lifetimeSpend - targetTxn.amount)
        };
      }
      return c;
    }));

    const syncId = triggerSync('ledger', `Refunded card transaction [${transactionId}]`);
    resolveSync(syncId);
  };

  const updateInvoiceStatus = async (invoiceId: string, status: Invoice['status']) => {
    setInvoices(prev => prev.map(inv => inv.id === invoiceId ? { ...inv, status } : inv));
    if (user) {
      try {
        await authenticatedFetch(`/api/invoices/${invoiceId}/status`, {
          method: 'PUT',
          body: JSON.stringify({ status })
        });
      } catch (err) {
        console.error('Failed to update invoice status:', err);
      }
    }
  };

  return (
    <StateContext.Provider
      value={{
        user,
        loading,
        invoices,
        clients,
        builds,
        activeTab,
        setActiveTab,
        signInWithGoogle,
        logout,
        addInvoice,
        addClient,
        addBuild,
        updateBuildStatus,
        updateBuildFabricationNotes,
        archiveBuild,
        addBuildNote,
        deleteInvoice,
        deleteClient,
        deleteBuild,
        refetchAll,
        globalSearchQuery,
        setGlobalSearchQuery,
        syncState,
        dismissSyncState,
        inventory,
        lowStockThreshold,
        updateInventoryStock,
        updateLowStockThreshold,
        addInventoryItem,
        deleteInventoryItem,
        transactions,
        processCardTransaction,
        refundCardTransaction,
        updateInvoiceStatus,
      }}
    >
      {children}
    </StateContext.Provider>
  );
};

export const useAppState = () => {
  const context = useContext(StateContext);
  if (!context) {
    throw new Error('useAppState must be used within StateProvider');
  }
  return context;
};
