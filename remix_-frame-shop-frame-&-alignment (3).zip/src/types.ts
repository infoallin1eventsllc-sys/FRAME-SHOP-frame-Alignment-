/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type InvoiceStatus = 'PAID' | 'PENDING' | 'OVERDUE' | 'PARTS WAIT';

export interface Invoice {
  id: string; // e.g. #FS-2024-001
  date: string; // e.g. Oct 12, 2023
  customerId: string;
  customerName: string;
  project: string;
  projectId: string;
  amount: number;
  status: InvoiceStatus;
  clientEmail?: string;
  lastEmailedAt?: string;
  emailCount?: number;
}

export type ClientStatus = 'ACTIVE' | 'INACTIVE';

export interface Client {
  id: string;
  name: string;
  email: string;
  phone: string;
  company: string;
  avatar: string;
  outstandingBalance: number;
  lifetimeSpend: number;
  notes: string;
  status: ClientStatus;
}

export type BuildStatus = 'QUEUED' | 'IN PROGRESS' | 'PARTS WAIT' | 'COMPLETED' | 'DELIVERED';

export interface Build {
  id: string;
  name: string;
  customerId: string;
  customerName: string;
  type: string; // e.g., 'Frame Modification', 'TIG Welding', 'CNC Machined'
  description: string;
  status: BuildStatus;
  startDate: string;
  completionDate?: string;
  estimatedCost: number;
  actualCost?: number;
  greaseMonkeyNotes: string[];
  fabricationNotes?: string;
  isArchived?: boolean;
}

export type TabType = 'dashboard' | 'clients' | 'builds' | 'billing' | 'settings';

export interface InventoryItem {
  id: string;
  name: string;
  unitType: string;
  stock: number;
}

export type CardType = 'debit' | 'credit' | 'apple_pay' | 'google_pay';
export type CardBrand = 'visa' | 'mastercard' | 'amex' | 'discover' | 'apple_pay' | 'google_pay';
export type TransactionStatus = 'APPROVED' | 'DECLINED' | 'REFUNDED';

export interface CardTransaction {
  id: string; // e.g. TXN-884920
  timestamp: string;
  customerId: string;
  customerName: string;
  invoiceId?: string;
  amount: number;
  cardType: CardType;
  cardBrand: CardBrand;
  lastFour: string;
  cardholderName: string;
  status: TransactionStatus;
  authCode: string;
  notes?: string;
  processingFee: number;
  passFeeToCustomer?: boolean;
}
