import { db } from './index.ts';
import { clients, builds, invoices, users } from './schema.ts';
import { eq, and } from 'drizzle-orm';
import { Client, Build, Invoice } from '../types.ts';
import { INITIAL_CLIENTS, INITIAL_BUILDS, INITIAL_INVOICES } from '../data.ts';

// Seed initial data for a user if they have none
export async function seedUserIfNeeded(userId: number) {
  try {
    const existingClients = await db.select().from(clients).where(eq(clients.userId, userId)).limit(1);
    if (existingClients.length === 0) {
      console.log(`Seeding initial data for user ${userId}...`);
      
      // Insert clients
      for (const client of INITIAL_CLIENTS) {
        await db.insert(clients).values({
          id: client.id,
          userId,
          name: client.name,
          email: client.email,
          phone: client.phone,
          company: client.company,
          avatar: client.avatar,
          outstandingBalance: client.outstandingBalance,
          lifetimeSpend: client.lifetimeSpend,
          notes: client.notes,
          status: client.status,
        });
      }

      // Insert builds
      for (const build of INITIAL_BUILDS) {
        await db.insert(builds).values({
          id: build.id,
          userId,
          name: build.name,
          customerId: build.customerId,
          customerName: build.customerName,
          type: build.type,
          description: build.description,
          status: build.status,
          startDate: build.startDate,
          completionDate: build.completionDate || null,
          estimatedCost: build.estimatedCost,
          actualCost: build.actualCost || null,
          greaseMonkeyNotes: build.greaseMonkeyNotes || [],
        });
      }

      // Insert invoices
      for (const invoice of INITIAL_INVOICES) {
        await db.insert(invoices).values({
          id: invoice.id,
          userId,
          date: invoice.date,
          customerId: invoice.customerId,
          customerName: invoice.customerName,
          project: invoice.project,
          projectId: invoice.projectId,
          amount: invoice.amount,
          status: invoice.status,
        });
      }
      console.log(`Finished seeding initial data for user ${userId}.`);
    }
  } catch (error) {
    console.error('Failed to seed user data:', error);
  }
}

// Client queries
export async function getClients(userId: number): Promise<Client[]> {
  try {
    const dbClients = await db.select().from(clients).where(eq(clients.userId, userId));
    return dbClients.map(c => ({
      id: c.id,
      name: c.name,
      email: c.email,
      phone: c.phone,
      company: c.company,
      avatar: c.avatar,
      outstandingBalance: c.outstandingBalance,
      lifetimeSpend: c.lifetimeSpend,
      notes: c.notes,
      status: c.status as Client['status'],
    }));
  } catch (error) {
    console.error('Database query failed for getClients:', error);
    throw new Error('Database query failed. Please try again later.', { cause: error });
  }
}

export async function addClient(userId: number, client: Client): Promise<void> {
  try {
    await db.insert(clients).values({
      id: client.id,
      userId,
      name: client.name,
      email: client.email,
      phone: client.phone,
      company: client.company,
      avatar: client.avatar,
      outstandingBalance: client.outstandingBalance || 0,
      lifetimeSpend: client.lifetimeSpend || 0,
      notes: client.notes || '',
      status: client.status,
    });
  } catch (error) {
    console.error('Database query failed for addClient:', error);
    throw new Error('Database query failed. Please try again later.', { cause: error });
  }
}

export async function deleteClient(userId: number, clientId: string): Promise<void> {
  try {
    await db.delete(clients).where(and(eq(clients.userId, userId), eq(clients.id, clientId)));
  } catch (error) {
    console.error('Database query failed for deleteClient:', error);
    throw new Error('Database query failed. Please try again later.', { cause: error });
  }
}

// Build queries
export async function getBuilds(userId: number): Promise<Build[]> {
  try {
    const dbBuilds = await db.select().from(builds).where(eq(builds.userId, userId));
    return dbBuilds.map(b => ({
      id: b.id,
      name: b.name,
      customerId: b.customerId,
      customerName: b.customerName,
      type: b.type,
      description: b.description,
      status: b.status as Build['status'],
      startDate: b.startDate,
      completionDate: b.completionDate || undefined,
      estimatedCost: b.estimatedCost,
      actualCost: b.actualCost || undefined,
      greaseMonkeyNotes: b.greaseMonkeyNotes || [],
      fabricationNotes: b.fabricationNotes || '',
      isArchived: b.isArchived,
    }));
  } catch (error) {
    console.error('Database query failed for getBuilds:', error);
    throw new Error('Database query failed. Please try again later.', { cause: error });
  }
}

export async function addBuild(userId: number, build: Build): Promise<void> {
  try {
    await db.insert(builds).values({
      id: build.id,
      userId,
      name: build.name,
      customerId: build.customerId,
      customerName: build.customerName,
      type: build.type,
      description: build.description,
      status: build.status,
      startDate: build.startDate,
      completionDate: build.completionDate || null,
      estimatedCost: build.estimatedCost,
      actualCost: build.actualCost || null,
      greaseMonkeyNotes: build.greaseMonkeyNotes || [],
      fabricationNotes: build.fabricationNotes || '',
      isArchived: build.isArchived || false,
    });
  } catch (error) {
    console.error('Database query failed for addBuild:', error);
    throw new Error('Database query failed. Please try again later.', { cause: error });
  }
}

export async function updateBuildFabricationNotes(
  userId: number,
  buildId: string,
  fabricationNotes: string
): Promise<void> {
  try {
    await db.update(builds)
      .set({ fabricationNotes })
      .where(and(eq(builds.userId, userId), eq(builds.id, buildId)));
  } catch (error) {
    console.error('Database query failed for updateBuildFabricationNotes:', error);
    throw new Error('Database query failed. Please try again later.', { cause: error });
  }
}

export async function archiveBuild(
  userId: number,
  buildId: string,
  isArchived: boolean
): Promise<void> {
  try {
    await db.update(builds)
      .set({ isArchived })
      .where(and(eq(builds.userId, userId), eq(builds.id, buildId)));
  } catch (error) {
    console.error('Database query failed for archiveBuild:', error);
    throw new Error('Database query failed. Please try again later.', { cause: error });
  }
}

export async function updateBuildStatus(
  userId: number,
  buildId: string,
  status: Build['status'],
  actualCost?: number,
  completionDate?: string,
  noteToAppend?: string
): Promise<void> {
  try {
    const existing = await db.select().from(builds).where(and(eq(builds.userId, userId), eq(builds.id, buildId))).limit(1);
    if (existing.length === 0) return;

    const currentNotes = existing[0].greaseMonkeyNotes || [];
    const updatedNotes = noteToAppend ? [noteToAppend, ...currentNotes] : currentNotes;

    await db.update(builds)
      .set({
        status,
        actualCost: actualCost ?? existing[0].actualCost,
        completionDate: completionDate ?? existing[0].completionDate,
        greaseMonkeyNotes: updatedNotes,
      })
      .where(and(eq(builds.userId, userId), eq(builds.id, buildId)));
  } catch (error) {
    console.error('Database query failed for updateBuildStatus:', error);
    throw new Error('Database query failed. Please try again later.', { cause: error });
  }
}

export async function addBuildNote(userId: number, buildId: string, note: string): Promise<void> {
  try {
    const existing = await db.select().from(builds).where(and(eq(builds.userId, userId), eq(builds.id, buildId))).limit(1);
    if (existing.length === 0) return;

    const updatedNotes = [note, ...(existing[0].greaseMonkeyNotes || [])];

    await db.update(builds)
      .set({ greaseMonkeyNotes: updatedNotes })
      .where(and(eq(builds.userId, userId), eq(builds.id, buildId)));
  } catch (error) {
    console.error('Database query failed for addBuildNote:', error);
    throw new Error('Database query failed. Please try again later.', { cause: error });
  }
}

export async function deleteBuild(userId: number, buildId: string): Promise<void> {
  try {
    await db.delete(builds).where(and(eq(builds.userId, userId), eq(builds.id, buildId)));
  } catch (error) {
    console.error('Database query failed for deleteBuild:', error);
    throw new Error('Database query failed. Please try again later.', { cause: error });
  }
}

// Invoice queries
export async function getInvoices(userId: number): Promise<Invoice[]> {
  try {
    const dbInvoices = await db.select().from(invoices).where(eq(invoices.userId, userId));
    return dbInvoices.map(i => ({
      id: i.id,
      date: i.date,
      customerId: i.customerId,
      customerName: i.customerName,
      project: i.project,
      projectId: i.projectId,
      amount: i.amount,
      status: i.status as Invoice['status'],
    }));
  } catch (error) {
    console.error('Database query failed for getInvoices:', error);
    throw new Error('Database query failed. Please try again later.', { cause: error });
  }
}

export async function addInvoice(userId: number, invoice: Invoice): Promise<void> {
  try {
    await db.insert(invoices).values({
      id: invoice.id,
      userId,
      date: invoice.date,
      customerId: invoice.customerId,
      customerName: invoice.customerName,
      project: invoice.project,
      projectId: invoice.projectId,
      amount: invoice.amount,
      status: invoice.status,
    });
  } catch (error) {
    console.error('Database query failed for addInvoice:', error);
    throw new Error('Database query failed. Please try again later.', { cause: error });
  }
}

export async function updateInvoiceStatus(
  userId: number,
  invoiceId: string,
  status: Invoice['status']
): Promise<void> {
  try {
    await db.update(invoices)
      .set({ status })
      .where(and(eq(invoices.userId, userId), eq(invoices.id, invoiceId)));
  } catch (error) {
    console.error('Database query failed for updateInvoiceStatus:', error);
    throw new Error('Database query failed. Please try again later.', { cause: error });
  }
}

export async function updateInvoicesStatusByProject(
  userId: number,
  projectId: string,
  status: Invoice['status']
): Promise<void> {
  try {
    await db.update(invoices)
      .set({ status })
      .where(and(eq(invoices.userId, userId), eq(invoices.projectId, projectId)));
  } catch (error) {
    console.error('Database query failed for updateInvoicesStatusByProject:', error);
    throw new Error('Database query failed. Please try again later.', { cause: error });
  }
}

export async function deleteInvoice(userId: number, invoiceId: string): Promise<void> {
  try {
    await db.delete(invoices).where(and(eq(invoices.userId, userId), eq(invoices.id, invoiceId)));
  } catch (error) {
    console.error('Database query failed for deleteInvoice:', error);
    throw new Error('Database query failed. Please try again later.', { cause: error });
  }
}
