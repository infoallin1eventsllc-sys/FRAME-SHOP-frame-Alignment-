import { pgTable, serial, text, timestamp, doublePrecision, integer, jsonb, boolean } from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';

// Users table
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(), // Firebase Auth UID
  email: text('email').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

// Clients table
export const clients = pgTable('clients', {
  id: text('id').primaryKey(), // e.g., C-001
  userId: integer('user_id').references(() => users.id).notNull(),
  name: text('name').notNull(),
  email: text('email').notNull(),
  phone: text('phone').notNull(),
  company: text('company').notNull(),
  avatar: text('avatar').notNull(),
  outstandingBalance: doublePrecision('outstanding_balance').notNull().default(0),
  lifetimeSpend: doublePrecision('lifetime_spend').notNull().default(0),
  notes: text('notes').notNull(),
  status: text('status').notNull(), // 'ACTIVE' | 'INACTIVE'
  createdAt: timestamp('created_at').defaultNow(),
});

// Builds table
export const builds = pgTable('builds', {
  id: text('id').primaryKey(), // e.g., B-101
  userId: integer('user_id').references(() => users.id).notNull(),
  name: text('name').notNull(),
  customerId: text('customer_id').notNull(),
  customerName: text('customer_name').notNull(),
  type: text('type').notNull(),
  description: text('description').notNull(),
  status: text('status').notNull(), // 'QUEUED' | 'IN PROGRESS' etc.
  startDate: text('start_date').notNull(),
  completionDate: text('completion_date'),
  estimatedCost: doublePrecision('estimated_cost').notNull().default(0),
  actualCost: doublePrecision('actual_cost'),
  greaseMonkeyNotes: jsonb('grease_monkey_notes').$type<string[]>().notNull().default([]),
  fabricationNotes: text('fabrication_notes').notNull().default(''),
  isArchived: boolean('is_archived').notNull().default(false),
  createdAt: timestamp('created_at').defaultNow(),
});

// Invoices table
export const invoices = pgTable('invoices', {
  id: text('id').primaryKey(), // e.g., #FS-2024-001
  userId: integer('user_id').references(() => users.id).notNull(),
  date: text('date').notNull(),
  customerId: text('customer_id').notNull(),
  customerName: text('customer_name').notNull(),
  project: text('project').notNull(),
  projectId: text('project_id').notNull(),
  amount: doublePrecision('amount').notNull().default(0),
  status: text('status').notNull(), // 'PAID' | 'PENDING' etc.
  createdAt: timestamp('created_at').defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  clients: many(clients),
  builds: many(builds),
  invoices: many(invoices),
}));

export const clientsRelations = relations(clients, ({ one }) => ({
  user: one(users, {
    fields: [clients.userId],
    references: [users.id],
  }),
}));

export const buildsRelations = relations(builds, ({ one }) => ({
  user: one(users, {
    fields: [builds.userId],
    references: [users.id],
  }),
}));

export const invoicesRelations = relations(invoices, ({ one }) => ({
  user: one(users, {
    fields: [invoices.userId],
    references: [users.id],
  }),
}));
