/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { useAppState } from '../StateContext';
import { CardTransaction, CardType, TransactionStatus } from '../types';
import { 
  CreditCard, 
  X, 
  Search, 
  Filter, 
  Download, 
  Printer, 
  RotateCcw, 
  CheckCircle, 
  AlertCircle, 
  DollarSign, 
  ShieldCheck,
  TrendingUp,
  Receipt
} from 'lucide-react';

interface CardTransactionsLedgerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenTerminal: () => void;
}

export const CardTransactionsLedgerModal: React.FC<CardTransactionsLedgerModalProps> = ({
  isOpen,
  onClose,
  onOpenTerminal
}) => {
  const { transactions, refundCardTransaction } = useAppState();

  const [searchTerm, setSearchTerm] = useState('');
  const [cardTypeFilter, setCardTypeFilter] = useState<'ALL' | 'debit' | 'credit' | 'apple_pay' | 'google_pay'>('ALL');
  const [statusFilter, setStatusFilter] = useState<'ALL' | TransactionStatus>('ALL');
  const [selectedTxnForReceipt, setSelectedTxnForReceipt] = useState<CardTransaction | null>(null);
  const [refundingId, setRefundingId] = useState<string | null>(null);

  // Filtered transactions
  const filteredTransactions = useMemo(() => {
    return transactions.filter(t => {
      const matchesType = cardTypeFilter === 'ALL' || t.cardType === cardTypeFilter;
      const matchesStatus = statusFilter === 'ALL' || t.status === statusFilter;
      
      const q = searchTerm.toLowerCase().trim();
      const matchesSearch = !q ||
        t.id.toLowerCase().includes(q) ||
        t.customerName.toLowerCase().includes(q) ||
        t.authCode.toLowerCase().includes(q) ||
        t.lastFour.includes(q) ||
        (t.invoiceId && t.invoiceId.toLowerCase().includes(q));

      return matchesType && matchesStatus && matchesSearch;
    });
  }, [transactions, cardTypeFilter, statusFilter, searchTerm]);

  // Volume Statistics
  const stats = useMemo(() => {
    let totalVol = 0;
    let creditVol = 0;
    let debitVol = 0;
    let applePayVol = 0;
    let googlePayVol = 0;
    let approvedCount = 0;

    transactions.forEach(t => {
      if (t.status === 'APPROVED') {
        approvedCount++;
        totalVol += t.amount;
        if (t.cardType === 'credit') creditVol += t.amount;
        if (t.cardType === 'debit') debitVol += t.amount;
        if (t.cardType === 'apple_pay') applePayVol += t.amount;
        if (t.cardType === 'google_pay') googlePayVol += t.amount;
      }
    });

    return { totalVol, creditVol, debitVol, applePayVol, googlePayVol, approvedCount };
  }, [transactions]);

  const handleRefund = async (id: string) => {
    if (confirm('Are you sure you want to refund this card transaction? This will adjust the customer\'s balance.')) {
      setRefundingId(id);
      await refundCardTransaction(id);
      setRefundingId(null);
    }
  };

  const handlePrintReceipt = (txn: CardTransaction) => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    printWindow.document.write(`
      <html>
        <head>
          <title>Receipt ${txn.id}</title>
          <style>
            body { font-family: 'Courier New', monospace; padding: 20px; max-width: 400px; margin: 0 auto; color: #000; }
            .text-center { text-align: center; }
            .header { border-bottom: 2px dashed #000; padding-bottom: 10px; margin-bottom: 15px; }
            .title { font-weight: bold; font-size: 16px; margin: 0; }
            .subtitle { font-size: 12px; color: #555; }
            .row { display: flex; justify-content: space-between; margin: 6px 0; font-size: 13px; }
            .total-row { border-top: 2px solid #000; border-bottom: 2px solid #000; padding: 8px 0; font-weight: bold; font-size: 15px; margin-top: 15px; }
            .footer { margin-top: 25px; border-top: 1px dashed #000; pt: 10px; font-size: 11px; text-align: center; color: #444; }
            .approved { display: inline-block; border: 2px solid #000; padding: 4px 12px; font-weight: bold; font-size: 14px; margin: 10px 0; }
          </style>
        </head>
        <body>
          <div class="header text-center">
            <h2 class="title">FABRICATORS STUDIO</h2>
            <div class="subtitle">Custom Fabrication & Precision Engineering</div>
            <div class="subtitle">Card Payment Receipt</div>
            <div class="approved">${txn.status}</div>
          </div>
          
          <div class="row"><span>Date & Time:</span><span>${txn.timestamp}</span></div>
          <div class="row"><span>Transaction ID:</span><span>${txn.id}</span></div>
          <div class="row"><span>Auth Code:</span><span>${txn.authCode}</span></div>
          <div class="row"><span>Customer:</span><span>${txn.customerName}</span></div>
          <div class="row"><span>Card Type:</span><span style="text-transform: uppercase;">${txn.cardType} (${txn.cardBrand})</span></div>
          <div class="row"><span>Card Number:</span><span>•••• •••• •••• ${txn.lastFour}</span></div>
          <div class="row"><span>Cardholder:</span><span>${txn.cardholderName}</span></div>
          ${txn.invoiceId ? `<div class="row"><span>Invoice Ref:</span><span>${txn.invoiceId}</span></div>` : ''}
          
          <div class="total-row row">
            <span>TOTAL:</span>
            <span>$${txn.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
          </div>

          <div class="footer">
            <div>Thank you for your business!</div>
            <div>Merchant Copy • Retain for Records</div>
          </div>
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
    }, 250);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 md:p-6 overflow-y-auto">
      <div className="bg-[#18181a] border border-amber-500/30 rounded-lg w-full max-w-5xl overflow-hidden shadow-2xl relative text-slate-100 flex flex-col my-auto max-h-[92vh]">
        
        {/* Header */}
        <div className="bg-[#121214] border-b border-amber-500/20 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-500/10 border border-amber-500/30 rounded-md text-amber-400">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold tracking-wide uppercase text-white flex items-center gap-2">
                Card Transactions Ledger
                <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/40 px-2 py-0.5 rounded font-mono">
                  {transactions.length} Records
                </span>
              </h3>
              <p className="text-xs text-slate-400">Audit debit & credit card transactions, receipts, and card authorization logs</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                onOpenTerminal();
              }}
              className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs uppercase rounded transition-colors flex items-center gap-1.5"
            >
              <CreditCard className="w-4 h-4" />
              New Card Payment
            </button>
            <button 
              onClick={onClose}
              className="p-1.5 hover:bg-slate-800 rounded-md text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Stats Summary Bar */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-2.5 p-4 bg-[#121214]/60 border-b border-slate-800 text-xs">
          <div className="bg-[#202023] p-2.5 rounded border border-slate-800">
            <div className="text-slate-400 font-mono uppercase text-[9px]">Total Processed</div>
            <div className="text-sm font-mono font-bold text-emerald-400 mt-0.5">
              ${stats.totalVol.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </div>
          </div>

          <div className="bg-[#202023] p-2.5 rounded border border-slate-800">
            <div className="text-slate-400 font-mono uppercase text-[9px]">Credit Cards</div>
            <div className="text-sm font-mono font-bold text-amber-400 mt-0.5">
              ${stats.creditVol.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </div>
          </div>

          <div className="bg-[#202023] p-2.5 rounded border border-slate-800">
            <div className="text-slate-400 font-mono uppercase text-[9px]">Debit Cards</div>
            <div className="text-sm font-mono font-bold text-blue-400 mt-0.5">
              ${stats.debitVol.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </div>
          </div>

          <div className="bg-[#202023] p-2.5 rounded border border-slate-800">
            <div className="text-slate-400 font-mono uppercase text-[9px]"> Apple Pay</div>
            <div className="text-sm font-mono font-bold text-slate-100 mt-0.5">
              ${stats.applePayVol.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </div>
          </div>

          <div className="bg-[#202023] p-2.5 rounded border border-slate-800">
            <div className="text-slate-400 font-mono uppercase text-[9px]">G Pay Wallet</div>
            <div className="text-sm font-mono font-bold text-blue-300 mt-0.5">
              ${stats.googlePayVol.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </div>
          </div>
        </div>

        {/* Filter Controls */}
        <div className="p-4 border-b border-slate-800 flex flex-col md:flex-row justify-between items-center gap-3 bg-[#18181a]">
          
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search customer, ID, last 4..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#121214] border border-slate-700 text-white text-xs rounded pl-9 pr-3 py-2 focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="flex items-center gap-2 w-full md:w-auto">
            {/* Type filter */}
            <select
              value={cardTypeFilter}
              onChange={(e) => setCardTypeFilter(e.target.value as any)}
              className="bg-[#121214] border border-slate-700 text-white text-xs rounded px-3 py-2 focus:outline-none focus:border-amber-500"
            >
              <option value="ALL">All Payment Types</option>
              <option value="debit">🏧 Debit Cards</option>
              <option value="credit">💳 Credit Cards</option>
              <option value="apple_pay"> Apple Pay</option>
              <option value="google_pay">G Pay Wallet</option>
            </select>

            {/* Status filter */}
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="bg-[#121214] border border-slate-700 text-white text-xs rounded px-3 py-2 focus:outline-none focus:border-amber-500"
            >
              <option value="ALL">All Statuses</option>
              <option value="APPROVED">Approved</option>
              <option value="REFUNDED">Refunded</option>
            </select>
          </div>
        </div>

        {/* Transactions Table */}
        <div className="p-4 overflow-y-auto flex-1">
          {filteredTransactions.length === 0 ? (
            <div className="text-center py-12 text-slate-500 text-xs">
              No card transactions match your filters.
            </div>
          ) : (
            <div className="overflow-x-auto border border-slate-800 rounded">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-[#121214] text-slate-400 border-b border-slate-800 uppercase tracking-wider text-[11px]">
                  <tr>
                    <th className="p-3">Txn ID / Date</th>
                    <th className="p-3">Customer</th>
                    <th className="p-3">Payment Method</th>
                    <th className="p-3">Card / Token</th>
                    <th className="p-3">Amount</th>
                    <th className="p-3">Status</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 bg-[#18181a]">
                  {filteredTransactions.map(t => (
                    <tr key={t.id} className="hover:bg-slate-800/40 transition-colors">
                      
                      <td className="p-3">
                        <div className="font-bold text-white">{t.id}</div>
                        <div className="text-[10px] text-slate-400">{t.timestamp}</div>
                      </td>

                      <td className="p-3 font-sans">
                        <div className="font-semibold text-white">{t.customerName}</div>
                        {t.invoiceId && (
                          <div className="text-[10px] font-mono text-amber-400">
                            Inv: {t.invoiceId}
                          </div>
                        )}
                      </td>

                      <td className="p-3">
                        <span className={`inline-flex items-center gap-1 font-bold text-[10px] px-2 py-0.5 rounded uppercase border ${
                          t.cardType === 'debit' 
                            ? 'bg-blue-500/20 text-blue-300 border-blue-500/30' 
                            : t.cardType === 'apple_pay'
                            ? 'bg-slate-800 text-white border-slate-600'
                            : t.cardType === 'google_pay'
                            ? 'bg-blue-900/40 text-blue-200 border-blue-400/40'
                            : 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                        }`}>
                          {t.cardType === 'debit' 
                            ? '🏧 Debit' 
                            : t.cardType === 'apple_pay' 
                            ? ' Apple Pay' 
                            : t.cardType === 'google_pay' 
                            ? 'G Pay' 
                            : '💳 Credit'} ({t.cardBrand.replace('_', ' ')})
                        </span>
                      </td>

                      <td className="p-3 text-slate-300">
                        •••• {t.lastFour}
                      </td>

                      <td className="p-3 font-bold text-white text-sm">
                        ${t.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </td>

                      <td className="p-3">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase border ${
                          t.status === 'APPROVED' 
                            ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40' 
                            : 'bg-red-500/20 text-red-400 border-red-500/40'
                        }`}>
                          {t.status}
                        </span>
                      </td>

                      <td className="p-3 text-right font-sans">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => handlePrintReceipt(t)}
                            title="Print Receipt"
                            className="p-1.5 hover:bg-slate-800 rounded text-slate-300 hover:text-white transition-colors"
                          >
                            <Printer className="w-4 h-4" />
                          </button>

                          {t.status === 'APPROVED' && (
                            <button
                              onClick={() => handleRefund(t.id)}
                              disabled={refundingId === t.id}
                              title="Refund Card Transaction"
                              className="px-2 py-1 bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/40 text-[10px] font-bold uppercase rounded transition-colors"
                            >
                              Refund
                            </button>
                          )}
                        </div>
                      </td>

                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
