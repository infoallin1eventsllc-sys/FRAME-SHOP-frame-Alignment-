import React, { useState, useMemo } from 'react';
import { useAppState } from '../StateContext.tsx';
import { 
  X, 
  Plus, 
  Trash2, 
  Calculator, 
  Printer, 
  Sparkles, 
  Coins, 
  Hammer, 
  Percent, 
  FilePlus, 
  CheckCircle2,
  ChevronDown
} from 'lucide-react';

interface MaterialItem {
  id: string;
  name: string;
  unitType: string;
  unitCost: number;
  quantity: number;
}

interface LaborItem {
  id: string;
  role: string;
  hourlyRate: number;
  hours: number;
}

const MATERIAL_PRESETS = [
  { name: 'Structural Steel Tubing (HSS)', unitType: 'meters', unitCost: 45.00 },
  { name: '6061-T6 Aluminum Plate', unitType: 'sheets', unitCost: 125.00 },
  { name: 'Stainless Steel Plate (304)', unitType: 'sheets', unitCost: 165.00 },
  { name: 'Heavy Duty Grade-8 Fastener Pack', unitType: 'kits', unitCost: 28.00 },
  { name: 'EPDM Rubber Damper strip', unitType: 'meters', unitCost: 12.00 },
  { name: 'Industrial Rust-Inhibiting Primer', unitType: 'cans', unitCost: 18.50 },
  { name: 'Powder Coat Pigment (Gloss Black)', unitType: 'lbs', unitCost: 35.00 }
];

const LABOR_PRESETS = [
  { role: 'CAD Engineering & Stress Simulation', hourlyRate: 85.00 },
  { role: 'TIG Frame Precision Welding', hourlyRate: 95.00 },
  { role: 'MIG Structural Assembly Welding', hourlyRate: 80.00 },
  { role: 'CNC Precision Laser Cutting', hourlyRate: 110.00 },
  { role: 'Manual Milling & Custom Boring', hourlyRate: 75.00 },
  { role: 'Surface Prep & Shot-Blasting', hourlyRate: 60.00 },
  { role: 'Deflection QC & Laser Alignment', hourlyRate: 90.00 }
];

interface MaterialCostCalculatorProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MaterialCostCalculator: React.FC<MaterialCostCalculatorProps> = ({ isOpen, onClose }) => {
  const { clients, builds, addInvoice } = useAppState();

  // Selected associates
  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [selectedProjectId, setSelectedProjectId] = useState('');
  const [estimateName, setEstimateName] = useState('Custom Fabrication Estimate');

  // Materials & Labor Lists
  const [materials, setMaterials] = useState<MaterialItem[]>([
    { id: 'mat-1', name: 'Structural Steel Tubing (HSS)', unitType: 'meters', unitCost: 45.00, quantity: 12 },
    { id: 'mat-2', name: 'Heavy Duty Grade-8 Fastener Pack', unitType: 'kits', unitCost: 28.00, quantity: 4 },
    { id: 'mat-3', name: 'Industrial Rust-Inhibiting Primer', unitType: 'cans', unitCost: 18.50, quantity: 3 }
  ]);

  const [labors, setLabors] = useState<LaborItem[]>([
    { id: 'lab-1', role: 'CAD Engineering & Stress Simulation', hourlyRate: 85.00, hours: 4 },
    { id: 'lab-2', role: 'TIG Frame Precision Welding', hourlyRate: 95.00, hours: 8 },
    { id: 'lab-3', role: 'Deflection QC & Laser Alignment', hourlyRate: 90.00, hours: 2 }
  ]);

  // Markups / Taxes
  const [consumablesPct, setConsumablesPct] = useState(5); // % of material costs
  const [overheadPct, setOverheadPct] = useState(10); // % of labor costs
  const [markupPct, setMarkupPct] = useState(20); // profit margin on total costs
  const [taxPct, setTaxPct] = useState(0); // overall tax on total cost

  // Success state for drafting invoice
  const [draftSuccess, setDraftSuccess] = useState(false);

  // Calculative aggregates
  const rawMaterialsSubtotal = useMemo(() => {
    return materials.reduce((sum, item) => sum + (item.unitCost * item.quantity), 0);
  }, [materials]);

  const rawLaborSubtotal = useMemo(() => {
    return labors.reduce((sum, item) => sum + (item.hourlyRate * item.hours), 0);
  }, [labors]);

  const consumablesCost = useMemo(() => {
    return (rawMaterialsSubtotal * consumablesPct) / 100;
  }, [rawMaterialsSubtotal, consumablesPct]);

  const overheadCost = useMemo(() => {
    return (rawLaborSubtotal * overheadPct) / 100;
  }, [rawLaborSubtotal, overheadPct]);

  const costBasis = rawMaterialsSubtotal + rawLaborSubtotal + consumablesCost + overheadCost;

  const profitMarkupCost = useMemo(() => {
    return (costBasis * markupPct) / 100;
  }, [costBasis, markupPct]);

  const preTaxTotal = costBasis + profitMarkupCost;

  const taxCost = useMemo(() => {
    return (preTaxTotal * taxPct) / 100;
  }, [preTaxTotal, taxPct]);

  const grandTotal = preTaxTotal + taxCost;

  if (!isOpen) return null;

  // Materials logic
  const handleAddMaterial = () => {
    const id = `mat-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    setMaterials([...materials, { id, name: '', unitType: 'pieces', unitCost: 0, quantity: 1 }]);
  };

  const handleApplyMaterialPreset = (id: string, presetIndex: number) => {
    const preset = MATERIAL_PRESETS[presetIndex];
    setMaterials(materials.map(item => 
      item.id === id 
        ? { ...item, name: preset.name, unitType: preset.unitType, unitCost: preset.unitCost }
        : item
    ));
  };

  const handleUpdateMaterial = (id: string, fields: Partial<MaterialItem>) => {
    setMaterials(materials.map(item => item.id === id ? { ...item, ...fields } : item));
  };

  const handleRemoveMaterial = (id: string) => {
    setMaterials(materials.filter(item => item.id !== id));
  };

  // Labor logic
  const handleAddLabor = () => {
    const id = `lab-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    setLabors([...labors, { id, role: '', hourlyRate: 0, hours: 1 }]);
  };

  const handleApplyLaborPreset = (id: string, presetIndex: number) => {
    const preset = LABOR_PRESETS[presetIndex];
    setLabors(labors.map(item => 
      item.id === id 
        ? { ...item, role: preset.role, hourlyRate: preset.hourlyRate }
        : item
    ));
  };

  const handleUpdateLabor = (id: string, fields: Partial<LaborItem>) => {
    setLabors(labors.map(item => item.id === id ? { ...item, ...fields } : item));
  };

  const handleRemoveLabor = (id: string) => {
    setLabors(labors.filter(item => item.id !== id));
  };

  // Trigger invoice generation
  const handleDraftInvoice = async () => {
    if (!selectedCustomerId) {
      alert('Please select a Customer Account first.');
      return;
    }

    const client = clients.find(c => c.id === selectedCustomerId);
    const proj = builds.find(b => b.id === selectedProjectId);

    await addInvoice({
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' }),
      customerId: selectedCustomerId,
      customerName: client?.name || 'Unknown Client',
      project: proj?.name || estimateName,
      projectId: selectedProjectId || 'B-EST',
      amount: Math.round(grandTotal * 100) / 100,
      status: 'PENDING'
    });

    setDraftSuccess(true);
    setTimeout(() => {
      setDraftSuccess(false);
    }, 4000);
  };

  // Print estimate
  const handlePrintEstimate = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('Please allow popups to print estimate.');
      return;
    }

    const client = clients.find(c => c.id === selectedCustomerId);
    const proj = builds.find(b => b.id === selectedProjectId);

    const materialsHtml = materials.map((item, index) => `
      <tr>
        <td style="text-align: center;">${index + 1}</td>
        <td><strong>${item.name || 'Custom Material'}</strong></td>
        <td style="text-align: center; text-transform: uppercase;">${item.unitType}</td>
        <td style="text-align: right;">$${item.unitCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
        <td style="text-align: center;">${item.quantity}</td>
        <td style="text-align: right; font-weight: bold;">$${(item.unitCost * item.quantity).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
      </tr>
    `).join('');

    const laborHtml = labors.map((item, index) => `
      <tr>
        <td style="text-align: center;">${index + 1}</td>
        <td><strong>${item.role || 'Custom Labor Task'}</strong></td>
        <td style="text-align: right;">$${item.hourlyRate.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} / hr</td>
        <td style="text-align: center;">${item.hours} hrs</td>
        <td style="text-align: right; font-weight: bold;">$${(item.hourlyRate * item.hours).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
      </tr>
    `).join('');

    const printContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Heavy Duty Fabrication - Estimate Sheet</title>
        <style>
          @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
          
          body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            color: #0f172a;
            margin: 0;
            padding: 0;
            background-color: #ffffff;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }
          
          .print-page {
            max-width: 850px;
            margin: 40px auto;
            padding: 40px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            background: #ffffff;
            position: relative;
            box-sizing: border-box;
          }
          
          .header-row {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            border-bottom: 2px solid #0f172a;
            padding-bottom: 24px;
            margin-bottom: 30px;
          }
          
          .company-title {
            font-size: 24px;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: #0f172a;
          }
          
          .company-subtitle {
            font-size: 12px;
            color: #475569;
            margin: 4px 0 0 0;
            font-weight: 500;
          }

          .company-address {
            font-size: 11px;
            color: #64748b;
            margin: 4px 0 0 0;
          }
          
          .invoice-title {
            font-size: 30px;
            font-weight: 900;
            text-align: right;
            color: #f97316;
            margin: 0 0 8px 0;
            letter-spacing: -0.02em;
          }
          
          .invoice-meta {
            text-align: right;
          }

          .meta-item {
            font-size: 12px;
            color: #334155;
            margin: 3px 0;
          }
          
          .details-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
            margin-bottom: 35px;
          }
          
          .details-col h4 {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.1em;
            color: #64748b;
            margin: 0 0 10px 0;
            border-bottom: 1px solid #cbd5e1;
            padding-bottom: 6px;
            font-weight: 700;
          }
          
          .details-col p {
            font-size: 13px;
            margin: 4px 0;
            line-height: 1.5;
            color: #1e293b;
          }
          
          .section-title {
            font-size: 14px;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: #0f172a;
            margin: 25px 0 12px 0;
            border-left: 4px solid #f97316;
            padding-left: 10px;
          }
          
          table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 25px;
          }
          
          th {
            background-color: #0f172a;
            color: #ffffff;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            padding: 10px 12px;
            text-align: left;
            font-weight: 600;
          }
          
          td {
            padding: 10px 12px;
            font-size: 12px;
            border-bottom: 1px solid #e2e8f0;
            color: #334155;
            vertical-align: middle;
          }
          
          .footer-row {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-top: 25px;
          }
          
          .notes-box {
            width: 450px;
            background-color: #f8fafc;
            padding: 16px;
            border: 1px solid #e2e8f0;
            border-radius: 4px;
          }

          .notes-box h5 {
            margin: 0 0 6px 0;
            font-size: 11px;
            color: #475569;
            text-transform: uppercase;
            letter-spacing: 0.05em;
          }

          .notes-box p {
            margin: 0;
            font-size: 12px;
            color: #64748b;
            line-height: 1.5;
          }

          .totals-box {
            width: 320px;
          }
          
          .totals-line {
            display: flex;
            justify-content: space-between;
            padding: 6px 0;
            font-size: 12px;
            color: #475569;
          }
          
          .grand-total {
            border-top: 2px solid #0f172a;
            font-size: 18px;
            font-weight: 900;
            padding-top: 12px;
            color: #f97316;
          }
          
          .footer-note {
            margin-top: 60px;
            text-align: center;
            font-size: 11px;
            color: #94a3b8;
            border-top: 1px solid #e2e8f0;
            padding-top: 24px;
          }
          
          @media print {
            body {
              background-color: #ffffff;
              color: #000000;
              padding: 0;
              margin: 0;
            }
            .print-page {
              max-width: 100%;
              border: none;
              border-radius: 0;
              margin: 0;
              padding: 10mm;
              page-break-after: always;
              page-break-inside: avoid;
            }
          }
        </style>
      </head>
      <body>
        <div class="print-page">
          <div class="header-row">
            <div>
              <div class="company-title">HEAVY DUTY FABRICATION</div>
              <p class="company-subtitle">Industrial Custom Assembly & Frame Shop</p>
              <p class="company-address">1024 Industrial Parkway, Detroit, MI 48201</p>
            </div>
            <div class="invoice-meta">
              <h1 class="invoice-title">JOB ESTIMATE</h1>
              <div class="meta-item"><strong>Date Generated:</strong> ${new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' })}</div>
              <div class="meta-item"><strong>Job Associated:</strong> ${proj?.name || estimateName}</div>
              <div class="meta-item"><strong>Reference code:</strong> EST-${Date.now().toString().slice(-6)}</div>
            </div>
          </div>

          <div class="details-grid">
            <div class="details-col">
              <h4>Fabrication Hub</h4>
              <p><strong>Heavy Duty Fabrication Co.</strong></p>
              <p>1024 Industrial Parkway, Suite B</p>
              <p>Detroit, MI 48201</p>
              <p>estimates@heavydutyfab.com</p>
            </div>
            <div class="details-col">
              <h4>Estimated For</h4>
              <p><strong>${client?.name || 'Walk-In Customer'}</strong></p>
              <p>${client?.company || 'N/A'}</p>
              <p>${client?.email || 'N/A'}</p>
              <p>${client?.phone || 'N/A'}</p>
            </div>
          </div>

          <div class="section-title">Raw Material Cost Detail</div>
          <table>
            <thead>
              <tr>
                <th style="width: 5%; text-align: center;">#</th>
                <th style="width: 45%;">Material / Part Description</th>
                <th style="width: 15%; text-align: center;">Unit Type</th>
                <th style="width: 15%; text-align: right;">Unit Cost</th>
                <th style="width: 10%; text-align: center;">Qty</th>
                <th style="width: 15%; text-align: right;">Subtotal</th>
              </tr>
            </thead>
            <tbody>
              ${materialsHtml || '<tr><td colspan="6" style="text-align: center; color: #94a3b8; font-style: italic;">No raw materials entered.</td></tr>'}
            </tbody>
          </table>

          <div class="section-title">Labor & Machining Hours</div>
          <table>
            <thead>
              <tr>
                <th style="width: 5%; text-align: center;">#</th>
                <th style="width: 50%;">Professional Labor Task / Process</th>
                <th style="width: 20%; text-align: right;">Hourly Rate</th>
                <th style="width: 10%; text-align: center;">Hours</th>
                <th style="width: 15%; text-align: right;">Subtotal</th>
              </tr>
            </thead>
            <tbody>
              ${laborHtml || '<tr><td colspan="5" style="text-align: center; color: #94a3b8; font-style: italic;">No labor processes entered.</td></tr>'}
            </tbody>
          </table>

          <div class="footer-row">
            <div class="notes-box">
              <h5>Estimator Disclaimers & Notes</h5>
              <p>
                This document provides a materials and labor estimation for custom industrial assembly services. 
                Final project pricing may vary depending on design adjustments, sudden metallurgy supply shifts, or special weld validations. 
                Estimate remains valid for 45 calendar days from issue.
              </p>
            </div>
            <div class="totals-box">
              <div class="totals-line">
                <span>Materials Subtotal:</span>
                <span>$${rawMaterialsSubtotal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
              <div class="totals-line">
                <span>Labor Subtotal:</span>
                <span>$${rawLaborSubtotal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
              <div class="totals-line">
                <span>Consumables (${consumablesPct}%):</span>
                <span>$${consumablesCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
              <div class="totals-line">
                <span>Shop Overhead (${overheadPct}%):</span>
                <span>$${overheadCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
              <div class="totals-line">
                <span>Profit Margin (${markupPct}%):</span>
                <span>$${profitMarkupCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
              <div class="totals-line">
                <span>Taxes (${taxPct}%):</span>
                <span>$${taxCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
              <div class="totals-line grand-total">
                <span>ESTIMATED EXPENSES:</span>
                <span>$${grandTotal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
            </div>
          </div>

          <div class="footer-note">
            <p>Thank you for choosing Heavy Duty Fabrication. We lock alignment on every build.</p>
            <p>Heavy Duty Fabrication & Assembly Co. | Detroit Hub</p>
          </div>
        </div>
        <script>
          window.onload = function() {
            setTimeout(function() {
              window.print();
            }, 300);
          };
        </script>
      </body>
      </html>
    `;

    printWindow.document.open();
    printWindow.document.write(printContent);
    printWindow.document.close();
  };

  return (
    <div className="fixed inset-0 bg-black/85 flex items-center justify-center z-50 p-4 md:p-6 backdrop-blur-sm overflow-y-auto">
      <div className="bg-[#1a1a1b] border-2 border-outline-variant w-full max-w-5xl shadow-2xl relative flex flex-col my-8">
        <div className="metal-grain absolute inset-0 opacity-40"></div>
        
        {/* Header Block */}
        <div className="relative z-10 p-6 border-b border-outline-variant/60 flex justify-between items-center bg-[#212122]">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-orange-500/10 border border-orange-500/20 text-orange-400 rounded">
              <Calculator size={20} />
            </div>
            <div>
              <h3 className="text-xl font-bold uppercase tracking-wider text-primary font-narrow">
                MATERIAL & LABOR COST ESTIMATOR
              </h3>
              <p className="text-xs text-on-surface-variant font-medium">Estimate overall raw expenses, hours, and overhead multipliers</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="text-on-surface-variant hover:text-white cursor-pointer p-1 bg-background/50 hover:bg-background border border-outline-variant/30 rounded"
          >
            <X size={20} />
          </button>
        </div>

        {/* Dynamic Warning Alert on Success */}
        {draftSuccess && (
          <div className="relative z-10 m-6 mb-0 p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-xs flex items-center gap-3 text-emerald-400 animate-fade-in">
            <CheckCircle2 size={18} />
            <div className="text-xs font-mono uppercase tracking-wider font-bold">
              Success! Draft invoice added to the system database. Check the ledger view to view it.
            </div>
          </div>
        )}

        {/* Workspace Body */}
        <div className="relative z-10 p-6 overflow-y-auto max-h-[70vh] grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* LEFT: WORK SHEET INPUTS (8 Cols) */}
          <div className="lg:col-span-8 space-y-6">
            
            {/* Meta context association */}
            <div className="p-4 bg-background/50 border border-outline-variant/30 rounded-xs grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-[10px] font-mono uppercase tracking-wider text-on-surface-variant mb-1 font-bold">
                  Client Account
                </label>
                <select
                  value={selectedCustomerId}
                  onChange={(e) => setSelectedCustomerId(e.target.value)}
                  className="w-full bg-[#1b1b1c] border border-outline-variant/60 p-2 text-xs font-mono text-on-surface focus:outline-none focus:ring-1 focus:ring-primary"
                >
                  <option value="">-- Associate Customer --</option>
                  {clients.map(c => (
                    <option key={c.id} value={c.id}>{c.name} ({c.company || 'Private'})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-mono uppercase tracking-wider text-on-surface-variant mb-1 font-bold">
                  Active Project Ref
                </label>
                <select
                  value={selectedProjectId}
                  onChange={(e) => {
                    setSelectedProjectId(e.target.value);
                    const p = builds.find(b => b.id === e.target.value);
                    if (p) {
                      setEstimateName(p.name);
                    }
                  }}
                  className="w-full bg-[#1b1b1c] border border-outline-variant/60 p-2 text-xs font-mono text-on-surface focus:outline-none focus:ring-1 focus:ring-primary"
                >
                  <option value="">-- Link Project Pipeline --</option>
                  {builds.filter(b => !b.isArchived).map(b => (
                    <option key={b.id} value={b.id}>[{b.id}] {b.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-mono uppercase tracking-wider text-on-surface-variant mb-1 font-bold">
                  Custom Estimate Title
                </label>
                <input
                  type="text"
                  value={estimateName}
                  onChange={(e) => setEstimateName(e.target.value)}
                  placeholder="e.g. Rollcage Alignment"
                  className="w-full bg-[#1b1b1c] border border-outline-variant/60 p-2 text-xs font-mono text-on-surface focus:outline-none focus:ring-1 focus:ring-primary"
                />
              </div>
            </div>

            {/* RAW MATERIALS SECTION */}
            <div className="border border-outline-variant/40 bg-background/20 p-4">
              <div className="flex justify-between items-center mb-3">
                <h4 className="text-xs font-mono font-black uppercase tracking-wider text-primary flex items-center gap-2">
                  <Coins size={14} />
                  1. Raw Material Inputs
                </h4>
                <button
                  onClick={handleAddMaterial}
                  className="flex items-center gap-1 bg-[#2d2e33] hover:bg-[#3d3e43] text-[#cfd8dc] border border-[#78909c]/40 px-2.5 py-1 text-[10px] font-mono font-bold uppercase tracking-wider rounded-xs transition-colors cursor-pointer"
                >
                  <Plus size={12} />
                  ADD MATERIAL ROW
                </button>
              </div>

              {/* Materials Table list */}
              <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                {materials.map((item) => (
                  <div key={item.id} className="flex flex-col md:flex-row items-center gap-2 bg-[#212122] p-2 border border-outline-variant/20 rounded-xs relative group/row">
                    
                    {/* Material Preset drop-down helper */}
                    <div className="w-full md:w-44 shrink-0 relative">
                      <select
                        onChange={(e) => {
                          if (e.target.value !== "") {
                            handleApplyMaterialPreset(item.id, parseInt(e.target.value));
                            e.target.value = ""; // Reset dropdown selection
                          }
                        }}
                        className="w-full bg-background border border-outline-variant/60 p-1.5 text-[10px] font-mono text-on-surface-variant focus:outline-none"
                      >
                        <option value="">-- Apply Materials Preset --</option>
                        {MATERIAL_PRESETS.map((p, index) => (
                          <option key={index} value={index}>{p.name} (${p.unitCost}/{p.unitType})</option>
                        ))}
                      </select>
                    </div>

                    {/* Material Title input */}
                    <input
                      type="text"
                      placeholder="Material description..."
                      value={item.name}
                      onChange={(e) => handleUpdateMaterial(item.id, { name: e.target.value })}
                      className="w-full flex-1 bg-background border border-outline-variant/40 p-1.5 text-xs text-on-surface focus:outline-none"
                    />

                    {/* Unit Cost input */}
                    <div className="flex items-center w-full md:w-32">
                      <span className="bg-background border border-r-0 border-outline-variant/40 px-2 py-1.5 text-[10px] font-mono text-on-surface-variant">$</span>
                      <input
                        type="number"
                        placeholder="Cost"
                        value={item.unitCost || ''}
                        onChange={(e) => handleUpdateMaterial(item.id, { unitCost: parseFloat(e.target.value) || 0 })}
                        className="w-full bg-background border border-outline-variant/40 p-1.5 text-xs text-on-surface font-mono focus:outline-none"
                      />
                    </div>

                    {/* Quantity input */}
                    <div className="flex items-center w-full md:w-28">
                      <input
                        type="number"
                        placeholder="Qty"
                        value={item.quantity || ''}
                        onChange={(e) => handleUpdateMaterial(item.id, { quantity: parseFloat(e.target.value) || 0 })}
                        className="w-full bg-background border border-outline-variant/40 p-1.5 text-xs text-on-surface font-mono text-center focus:outline-none"
                      />
                      <span className="bg-background border border-l-0 border-outline-variant/40 px-2 py-1.5 text-[9px] font-mono text-on-surface-variant uppercase shrink-0 w-12 text-center truncate">
                        {item.unitType || 'pcs'}
                      </span>
                    </div>

                    {/* Total Material cost display */}
                    <div className="w-20 font-mono text-xs text-right font-bold text-on-surface shrink-0">
                      ${(item.unitCost * item.quantity).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </div>

                    {/* Delete material */}
                    <button
                      onClick={() => handleRemoveMaterial(item.id)}
                      className="text-on-surface-variant hover:text-red-400 p-1.5 hover:bg-red-500/10 rounded transition-all cursor-pointer shrink-0"
                      title="Remove Row"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                ))}

                {materials.length === 0 && (
                  <div className="text-center p-6 bg-background/30 border border-dashed border-outline-variant/30 text-on-surface-variant text-xs italic">
                    No raw materials defined. Use 'Add Material Row' or select a preset to populate.
                  </div>
                )}
              </div>
            </div>

            {/* LABOR RATES SECTION */}
            <div className="border border-outline-variant/40 bg-background/20 p-4">
              <div className="flex justify-between items-center mb-3">
                <h4 className="text-xs font-mono font-black uppercase tracking-wider text-primary flex items-center gap-2">
                  <Hammer size={14} />
                  2. Hourly Labor Processes
                </h4>
                <button
                  onClick={handleAddLabor}
                  className="flex items-center gap-1 bg-[#2d2e33] hover:bg-[#3d3e43] text-[#cfd8dc] border border-[#78909c]/40 px-2.5 py-1 text-[10px] font-mono font-bold uppercase tracking-wider rounded-xs transition-colors cursor-pointer"
                >
                  <Plus size={12} />
                  ADD LABOR ROW
                </button>
              </div>

              {/* Labor List */}
              <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                {labors.map((item) => (
                  <div key={item.id} className="flex flex-col md:flex-row items-center gap-2 bg-[#212122] p-2 border border-outline-variant/20 rounded-xs relative group/row">
                    
                    {/* Labor Preset drop-down */}
                    <div className="w-full md:w-44 shrink-0 relative">
                      <select
                        onChange={(e) => {
                          if (e.target.value !== "") {
                            handleApplyLaborPreset(item.id, parseInt(e.target.value));
                            e.target.value = "";
                          }
                        }}
                        className="w-full bg-background border border-outline-variant/60 p-1.5 text-[10px] font-mono text-on-surface-variant focus:outline-none"
                      >
                        <option value="">-- Apply Labor Preset --</option>
                        {LABOR_PRESETS.map((p, index) => (
                          <option key={index} value={index}>{p.role} (${p.hourlyRate}/hr)</option>
                        ))}
                      </select>
                    </div>

                    {/* Labor Role description */}
                    <input
                      type="text"
                      placeholder="Labor description..."
                      value={item.role}
                      onChange={(e) => handleUpdateLabor(item.id, { role: e.target.value })}
                      className="w-full flex-1 bg-background border border-outline-variant/40 p-1.5 text-xs text-on-surface focus:outline-none"
                    />

                    {/* Hourly rate */}
                    <div className="flex items-center w-full md:w-32">
                      <span className="bg-background border border-r-0 border-outline-variant/40 px-2 py-1.5 text-[10px] font-mono text-on-surface-variant">$</span>
                      <input
                        type="number"
                        placeholder="Rate/hr"
                        value={item.hourlyRate || ''}
                        onChange={(e) => handleUpdateLabor(item.id, { hourlyRate: parseFloat(e.target.value) || 0 })}
                        className="w-full bg-background border border-outline-variant/40 p-1.5 text-xs text-on-surface font-mono focus:outline-none"
                      />
                    </div>

                    {/* Hours */}
                    <div className="flex items-center w-full md:w-28">
                      <input
                        type="number"
                        placeholder="Hours"
                        value={item.hours || ''}
                        onChange={(e) => handleUpdateLabor(item.id, { hours: parseFloat(e.target.value) || 0 })}
                        className="w-full bg-background border border-outline-variant/40 p-1.5 text-xs text-on-surface font-mono text-center focus:outline-none"
                      />
                      <span className="bg-background border border-l-0 border-outline-variant/40 px-2 py-1.5 text-[9px] font-mono text-on-surface-variant uppercase shrink-0 w-12 text-center">
                        hrs
                      </span>
                    </div>

                    {/* Total labor cost */}
                    <div className="w-20 font-mono text-xs text-right font-bold text-on-surface shrink-0">
                      ${(item.hourlyRate * item.hours).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </div>

                    {/* Delete labor item */}
                    <button
                      onClick={() => handleRemoveLabor(item.id)}
                      className="text-on-surface-variant hover:text-red-400 p-1.5 hover:bg-red-500/10 rounded transition-all cursor-pointer shrink-0"
                      title="Remove Row"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                ))}

                {labors.length === 0 && (
                  <div className="text-center p-6 bg-background/30 border border-dashed border-outline-variant/30 text-on-surface-variant text-xs italic">
                    No labor services defined. Use 'Add Labor Row' or apply a preset.
                  </div>
                )}
              </div>
            </div>

            {/* OVERHEADS AND SURCHARGES MULTIPLIERS */}
            <div className="p-4 bg-background/40 border border-outline-variant/20 rounded-xs">
              <h4 className="text-xs font-mono font-black uppercase tracking-wider text-[#90a4ae] mb-4 flex items-center gap-2">
                <Percent size={14} className="text-primary-container" />
                3. Cost Multipliers & Overheads
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-wider text-on-surface-variant mb-1 font-bold">
                    Consumables Surcharge %
                  </label>
                  <div className="flex items-center">
                    <input
                      type="number"
                      value={consumablesPct}
                      onChange={(e) => setConsumablesPct(parseFloat(e.target.value) || 0)}
                      className="w-full bg-background border border-outline-variant/60 p-2 text-xs font-mono text-on-surface focus:outline-none"
                    />
                    <span className="bg-[#212122] border border-l-0 border-outline-variant/60 px-2 py-2 text-xs font-mono text-on-surface-variant">%</span>
                  </div>
                  <span className="text-[9px] text-on-surface-variant block mt-0.5 font-mono italic">Applied to raw material</span>
                </div>

                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-wider text-on-surface-variant mb-1 font-bold">
                    Shop Overhead %
                  </label>
                  <div className="flex items-center">
                    <input
                      type="number"
                      value={overheadPct}
                      onChange={(e) => setOverheadPct(parseFloat(e.target.value) || 0)}
                      className="w-full bg-background border border-outline-variant/60 p-2 text-xs font-mono text-on-surface focus:outline-none"
                    />
                    <span className="bg-[#212122] border border-l-0 border-outline-variant/60 px-2 py-2 text-xs font-mono text-on-surface-variant">%</span>
                  </div>
                  <span className="text-[9px] text-on-surface-variant block mt-0.5 font-mono italic">Applied to raw labor</span>
                </div>

                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-wider text-on-surface-variant mb-1 font-bold">
                    Profit Margin %
                  </label>
                  <div className="flex items-center">
                    <input
                      type="number"
                      value={markupPct}
                      onChange={(e) => setMarkupPct(parseFloat(e.target.value) || 0)}
                      className="w-full bg-background border border-outline-variant/60 p-2 text-xs font-mono text-on-surface focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                    <span className="bg-[#212122] border border-l-0 border-outline-variant/60 px-2 py-2 text-xs font-mono text-on-surface-variant">%</span>
                  </div>
                  <span className="text-[9px] text-on-surface-variant block mt-0.5 font-mono italic">Profit added to raw cost basis</span>
                </div>

                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-wider text-on-surface-variant mb-1 font-bold">
                    Tax Rate %
                  </label>
                  <div className="flex items-center">
                    <input
                      type="number"
                      value={taxPct}
                      onChange={(e) => setTaxPct(parseFloat(e.target.value) || 0)}
                      className="w-full bg-background border border-outline-variant/60 p-2 text-xs font-mono text-on-surface focus:outline-none"
                    />
                    <span className="bg-[#212122] border border-l-0 border-outline-variant/60 px-2 py-2 text-xs font-mono text-on-surface-variant">%</span>
                  </div>
                  <span className="text-[9px] text-on-surface-variant block mt-0.5 font-mono italic">Sales/Vat overall tax</span>
                </div>
              </div>
            </div>

          </div>

          {/* RIGHT: COST BREAKDOWN BOARD (4 Cols) */}
          <div className="lg:col-span-4 bg-[#212122] p-6 border-2 border-primary-container/20 flex flex-col justify-between relative overflow-hidden group">
            <div className="metal-grain absolute inset-0 opacity-10"></div>
            
            {/* Summary details */}
            <div className="relative z-10 space-y-6">
              
              <div className="text-center pb-4 border-b border-outline-variant/30">
                <span className="text-[9px] font-mono tracking-widest text-primary-container font-black uppercase flex items-center justify-center gap-1.5 mb-2">
                  <Sparkles size={11} className="text-amber-400" /> SUMMARY SHEET ESTIMATION
                </span>
                <p className="text-xs text-on-surface-variant truncate font-semibold uppercase">{estimateName || 'Custom Fabrication'}</p>
              </div>

              {/* Breakdown Ledger list */}
              <div className="space-y-3">
                <div className="flex justify-between text-xs text-on-surface-variant">
                  <span>Materials Cost subtotal:</span>
                  <span className="font-mono font-medium text-on-surface">
                    ${rawMaterialsSubtotal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>

                <div className="flex justify-between text-xs text-on-surface-variant">
                  <span>Labor Hours subtotal:</span>
                  <span className="font-mono font-medium text-on-surface">
                    ${rawLaborSubtotal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>

                <div className="flex justify-between text-xs text-on-surface-variant">
                  <span>Consumables ({consumablesPct}%):</span>
                  <span className="font-mono font-medium text-on-surface">
                    +${consumablesCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>

                <div className="flex justify-between text-xs text-on-surface-variant">
                  <span>Shop Overheads ({overheadPct}%):</span>
                  <span className="font-mono font-medium text-on-surface">
                    +${overheadCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>

                <div className="pt-2 border-t border-outline-variant/30 flex justify-between text-xs text-[#a0aab0] font-bold uppercase tracking-wider">
                  <span>Cost Basis (Net Expenses):</span>
                  <span className="font-mono">
                    ${costBasis.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>

                <div className="flex justify-between text-xs text-on-surface-variant">
                  <span>Profit Margin markup ({markupPct}%):</span>
                  <span className="font-mono font-medium text-on-surface">
                    +${profitMarkupCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>

                <div className="flex justify-between text-xs text-on-surface-variant">
                  <span>Taxes ({taxPct}%):</span>
                  <span className="font-mono font-medium text-on-surface">
                    +${taxCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
              </div>

              {/* Dynamic breakout visualizer chart (Ratio gauge) */}
              <div className="bg-background/80 p-4 border border-outline-variant/30">
                <div className="flex justify-between text-[10px] font-mono text-on-surface-variant uppercase tracking-wider mb-2 font-black">
                  <span>Raw Cost Allocation Ratio</span>
                  <span>(Mat : Lab : Markup)</span>
                </div>
                
                {/* Visual bar stack */}
                <div className="h-4 w-full bg-neutral-800 rounded-full flex overflow-hidden border border-black/40">
                  {grandTotal > 0 ? (
                    <>
                      <div 
                        style={{ width: `${Math.round((rawMaterialsSubtotal / grandTotal) * 100)}%` }} 
                        className="bg-orange-500 h-full transition-all"
                        title={`Materials: ${Math.round((rawMaterialsSubtotal / grandTotal) * 100)}%`}
                      />
                      <div 
                        style={{ width: `${Math.round((rawLaborSubtotal / grandTotal) * 100)}%` }} 
                        className="bg-sky-500 h-full transition-all"
                        title={`Labor: ${Math.round((rawLaborSubtotal / grandTotal) * 100)}%`}
                      />
                      <div 
                        style={{ width: `${Math.round(((consumablesCost + overheadCost + profitMarkupCost + taxCost) / grandTotal) * 100)}%` }} 
                        className="bg-amber-500 h-full transition-all"
                        title={`Overhead & Markups: ${Math.round(((consumablesCost + overheadCost + profitMarkupCost + taxCost) / grandTotal) * 100)}%`}
                      />
                    </>
                  ) : (
                    <div className="w-full h-full bg-[#2a2a2b]" />
                  )}
                </div>

                <div className="flex justify-between text-[8px] font-mono mt-1.5 uppercase tracking-wider text-on-surface-variant">
                  <span className="flex items-center gap-1 font-bold text-orange-400">
                    <span className="h-1.5 w-1.5 bg-orange-500 rounded-full" />
                    Mat ({grandTotal > 0 ? Math.round((rawMaterialsSubtotal / grandTotal) * 100) : 0}%)
                  </span>
                  <span className="flex items-center gap-1 font-bold text-sky-400">
                    <span className="h-1.5 w-1.5 bg-sky-500 rounded-full" />
                    Lab ({grandTotal > 0 ? Math.round((rawLaborSubtotal / grandTotal) * 100) : 0}%)
                  </span>
                  <span className="flex items-center gap-1 font-bold text-amber-400">
                    <span className="h-1.5 w-1.5 bg-amber-500 rounded-full" />
                    Overhead ({grandTotal > 0 ? Math.round(((consumablesCost + overheadCost + profitMarkupCost + taxCost) / grandTotal) * 100) : 0}%)
                  </span>
                </div>
              </div>

              {/* GRAND TOTAL EXPENSES BOX */}
              <div className="bg-background border-2 border-primary/20 p-4 text-center">
                <span className="text-[10px] font-mono tracking-widest text-[#94a3b8] font-bold uppercase block mb-1">
                  GRAND ESTIMATED EXPENSES
                </span>
                <p className="text-4xl font-extrabold tracking-tight text-primary font-narrow leading-none">
                  ${grandTotal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
                <span className="text-[9px] text-[#475569] font-mono block mt-2 uppercase tracking-wide">
                  Calculations Verified Real-time
                </span>
              </div>

            </div>

            {/* ACTION TRIGGERS BUTTONS */}
            <div className="relative z-10 space-y-3 mt-8">
              
              <button
                onClick={handlePrintEstimate}
                className="w-full flex items-center justify-center gap-2 border-2 border-outline-variant hover:bg-[#2d2e33] text-on-surface font-mono text-[11px] font-black uppercase tracking-wider py-3 rounded-xs transition-all cursor-pointer"
              >
                <Printer size={15} />
                PRINT ESTIMATED QUOTE
              </button>

              <button
                onClick={handleDraftInvoice}
                disabled={!selectedCustomerId}
                className={`w-full flex items-center justify-center gap-2 font-mono text-[11px] font-black uppercase tracking-wider py-3.5 rounded-xs transition-all cursor-pointer ${
                  selectedCustomerId 
                    ? 'bg-primary hover:bg-orange-600 text-white shadow-lg shadow-primary/20' 
                    : 'bg-background border border-outline-variant/40 text-on-surface-variant/40 cursor-not-allowed'
                }`}
              >
                <FilePlus size={15} />
                DRAFT INVOICE FROM ESTIMATE
              </button>

              {!selectedCustomerId && (
                <p className="text-center text-[10px] text-red-400/80 font-mono italic">
                  * Link a Client Account above to generate dynamic invoices.
                </p>
              )}
            </div>

          </div>

        </div>

        {/* Footer info lock line */}
        <div className="relative z-10 p-4 bg-[#141415] border-t border-outline-variant/40 text-center select-none">
          <p className="text-[10px] font-mono text-on-surface-variant/50 uppercase tracking-widest">
            ESTIMATION LEDGER SYSTEM v1.0.4 • DETROIT FABRICATION TERMINAL
          </p>
        </div>

      </div>
    </div>
  );
};
