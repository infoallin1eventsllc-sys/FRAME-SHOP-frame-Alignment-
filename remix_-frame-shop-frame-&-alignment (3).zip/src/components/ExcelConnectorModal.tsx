import React, { useState, useRef } from 'react';
import { FileSpreadsheet, Upload, Download, X, Check, AlertCircle, RefreshCw, FileText, Table, Layers, ArrowRight } from 'lucide-react';
import { useAppState } from '../StateContext';
import { parseExcelFile, exportInvoicesToExcel, exportClientsToExcel, exportInventoryToExcel, exportBuildsToExcel, exportFullWorkbook } from '../lib/excel';
import * as XLSX from 'xlsx';

interface ExcelConnectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultTab?: 'import' | 'export';
}

type TargetEntity = 'invoices' | 'clients' | 'inventory' | 'builds';

export const ExcelConnectorModal: React.FC<ExcelConnectorModalProps> = ({
  isOpen,
  onClose,
  defaultTab = 'import'
}) => {
  const {
    invoices,
    clients,
    builds,
    inventory,
    addInvoice,
    addClient,
    addInventoryItem,
    addBuild
  } = useAppState();

  const [activeTab, setActiveTab] = useState<'import' | 'export'>(defaultTab);
  const [targetEntity, setTargetEntity] = useState<TargetEntity>('invoices');
  
  // File import state
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [parsedRows, setParsedRows] = useState<Record<string, any>[]>([]);
  const [sheetNames, setSheetNames] = useState<string[]>([]);
  const [loadingFile, setLoadingFile] = useState(false);
  const [importSuccess, setImportSuccess] = useState<string | null>(null);
  const [importError, setImportError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    setLoadingFile(true);
    setImportError(null);
    setImportSuccess(null);

    try {
      const result = await parseExcelFile(file);
      setSheetNames(result.sheetNames);
      setParsedRows(result.data);
    } catch (err: any) {
      setImportError(err.message || 'Failed to parse Excel spreadsheet');
      setParsedRows([]);
    } finally {
      setLoadingFile(false);
    }
  };

  const handleDownloadSampleTemplate = () => {
    let sampleData: Record<string, any>[] = [];
    let filename = '';

    if (targetEntity === 'invoices') {
      filename = 'ForgeFlow_Invoices_Sample_Template.xlsx';
      sampleData = [
        {
          'Date': '2026-08-01',
          'Client Name': 'Titan Metalworks LLC',
          'Project Name': 'Structural Steel Canopy Fabrication',
          'Amount': 8500,
          'Status': 'PENDING',
          'Client Email': 'accounting@titanmetal.com'
        },
        {
          'Date': '2026-08-05',
          'Client Name': 'AeroCorp Industries',
          'Project Name': 'CNC Milling & Anodized Brackets',
          'Amount': 4200,
          'Status': 'PAID',
          'Client Email': 'billing@aerocorp.com'
        }
      ];
    } else if (targetEntity === 'clients') {
      filename = 'ForgeFlow_Clients_Sample_Template.xlsx';
      sampleData = [
        {
          'Name': 'Marcus Vance',
          'Company': 'Vance Steel Fabrication',
          'Email': 'marcus@vancesteel.com',
          'Phone': '(555) 234-5678',
          'Status': 'ACTIVE',
          'Notes': 'High-volume structural tubing client'
        }
      ];
    } else if (targetEntity === 'inventory') {
      filename = 'ForgeFlow_Inventory_Sample_Template.xlsx';
      sampleData = [
        {
          'Material Name': 'Chrome-Moly Tubing 1.5 inch',
          'Unit Type': 'meters',
          'Stock': 50
        }
      ];
    } else if (targetEntity === 'builds') {
      filename = 'ForgeFlow_Builds_Sample_Template.xlsx';
      sampleData = [
        {
          'Project Name': 'Custom Off-Road Roll Cage',
          'Client Name': 'Apex Motorsports',
          'Fabrication Type': 'TIG Welding',
          'Status': 'IN PROGRESS',
          'Start Date': '2026-08-01',
          'Estimated Cost': 6500,
          'Fabrication Notes': 'Use 4130 chromoly tubing with gussets.'
        }
      ];
    }

    const worksheet = XLSX.utils.json_to_sheet(sampleData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Import Template');
    XLSX.writeFile(workbook, filename);
  };

  const handleExecuteImport = async () => {
    if (parsedRows.length === 0) {
      setImportError('No records available to import. Upload an Excel spreadsheet first.');
      return;
    }

    let importedCount = 0;

    try {
      for (const row of parsedRows) {
        if (targetEntity === 'invoices') {
          const clientName = row['Client Name'] || row['Customer Name'] || row['Client'] || 'Imported Client';
          const project = row['Project Name'] || row['Project'] || row['Order'] || 'Custom Fabrication';
          const amount = Number(row['Amount'] || row['Amount ($)'] || row['Total'] || 0);
          const rawStatus = (row['Status'] || 'PENDING').toString().toUpperCase();
          const status = ['PAID', 'PENDING', 'OVERDUE', 'PARTS WAIT'].includes(rawStatus) ? rawStatus : 'PENDING';
          const date = row['Date'] || new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
          const clientEmail = row['Client Email'] || row['Email'] || '';

          // Find or match client
          const matchingClient = clients.find(c => c.name.toLowerCase() === clientName.toLowerCase());
          const customerId = matchingClient ? matchingClient.id : `cli-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;

          await addInvoice({
            date,
            customerId,
            customerName: clientName,
            project,
            projectId: `prj-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
            amount,
            status: status as any,
            clientEmail
          });
          importedCount++;

        } else if (targetEntity === 'clients') {
          const name = row['Name'] || row['Client Name'] || row['Contact'] || 'New Client';
          const email = row['Email'] || row['Client Email'] || row['Email Address'] || 'client@example.com';
          const phone = row['Phone'] || row['Phone Number'] || '(555) 000-0000';
          const company = row['Company'] || row['Organization'] || '';
          const notes = row['Notes'] || row['Memo'] || 'Imported via Excel Connector';

          await addClient({
            name,
            email,
            phone,
            company,
            avatar: '',
            notes,
            status: 'ACTIVE'
          });
          importedCount++;

        } else if (targetEntity === 'inventory') {
          const name = row['Material Name'] || row['Material Description'] || row['Name'] || row['Description'] || 'Raw Stock Item';
          const unitType = row['Unit Type'] || row['Unit'] || 'units';
          const stock = Number(row['Stock'] || row['Stock Quantity'] || row['Quantity'] || 0);

          addInventoryItem(name, unitType, stock);
          importedCount++;

        } else if (targetEntity === 'builds') {
          const name = row['Project Name'] || row['Build Name'] || row['Name'] || 'Custom Build';
          const clientName = row['Client Name'] || row['Customer'] || 'Valued Customer';
          const type = row['Fabrication Type'] || row['Type'] || 'General Machining';
          const rawStatus = (row['Status'] || 'QUEUED').toString().toUpperCase();
          const status = ['QUEUED', 'IN PROGRESS', 'PARTS WAIT', 'COMPLETED', 'DELIVERED'].includes(rawStatus) ? rawStatus : 'QUEUED';
          const estimatedCost = Number(row['Estimated Cost'] || row['Cost'] || row['Estimate'] || 0);
          const startDate = row['Start Date'] || new Date().toISOString().split('T')[0];
          const fabricationNotes = row['Fabrication Notes'] || row['Specs'] || 'Imported via Excel';

          await addBuild({
            name,
            customerId: `cli-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
            customerName: clientName,
            type,
            description: `Imported build order: ${name}`,
            status: status as any,
            startDate,
            estimatedCost,
            fabricationNotes
          });
          importedCount++;
        }
      }

      setImportSuccess(`Successfully imported ${importedCount} ${targetEntity} records from Excel spreadsheet!`);
      setParsedRows([]);
      setFileName(null);
    } catch (err: any) {
      setImportError(`Import interrupted: ${err.message}`);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/85 flex items-center justify-center p-4 backdrop-blur-xs">
      <div className="bg-surface border-2 border-outline-variant w-full max-w-4xl shadow-2xl relative rounded-xs font-sans overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[90vh]">
        
        {/* Modal Header */}
        <div className="bg-slate-900 text-slate-100 p-5 border-b border-outline-variant flex justify-between items-center relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald-500/20 border border-emerald-500/40 rounded-xs flex items-center justify-center text-emerald-400">
              <FileSpreadsheet size={22} />
            </div>
            <div>
              <h3 className="text-lg font-bold uppercase tracking-wider font-narrow flex items-center gap-2">
                EXCEL SPREADSHEET INTEGRATION HUB
              </h3>
              <p className="text-[11px] text-slate-400 font-mono">
                Import & Export Native .xlsx / .xls / .csv spreadsheets across all modules
              </p>
            </div>
          </div>
          <button
            id="btn-close-excel-modal"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xs transition-colors cursor-pointer"
          >
            <X size={20} />
          </button>
        </div>

        {/* Tab Toggle Bar */}
        <div className="bg-slate-950 border-b border-outline-variant/60 p-2 flex gap-2">
          <button
            id="tab-excel-import"
            type="button"
            onClick={() => { setActiveTab('import'); setImportSuccess(null); setImportError(null); }}
            className={`flex-1 py-2.5 px-4 font-mono text-xs font-bold uppercase tracking-wider rounded-xs flex items-center justify-center gap-2 cursor-pointer transition-all ${
              activeTab === 'import'
                ? 'bg-primary text-white shadow-sm'
                : 'bg-surface-container text-on-surface-variant hover:text-on-surface hover:bg-surface-container-high'
            }`}
          >
            <Upload size={14} />
            <span>IMPORT SPREADSHEETS (.XLSX)</span>
          </button>

          <button
            id="tab-excel-export"
            type="button"
            onClick={() => { setActiveTab('export'); setImportSuccess(null); setImportError(null); }}
            className={`flex-1 py-2.5 px-4 font-mono text-xs font-bold uppercase tracking-wider rounded-xs flex items-center justify-center gap-2 cursor-pointer transition-all ${
              activeTab === 'export'
                ? 'bg-primary text-white shadow-sm'
                : 'bg-surface-container text-on-surface-variant hover:text-on-surface hover:bg-surface-container-high'
            }`}
          >
            <Download size={14} />
            <span>EXPORT ENTERPRISE WORKBOOKS</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1 text-xs relative z-10 bg-surface">
          
          {activeTab === 'import' ? (
            <div className="space-y-5">
              
              {/* Target Entity Selection */}
              <div>
                <label className="block text-[10px] font-mono font-bold text-on-surface-variant uppercase tracking-wider mb-2">
                  1. SELECT TARGET DATABASE MODULE FOR EXCEL IMPORT
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { id: 'invoices', label: 'INVOICES', count: invoices.length },
                    { id: 'clients', label: 'CLIENTS', count: clients.length },
                    { id: 'inventory', label: 'RAW INVENTORY', count: inventory.length },
                    { id: 'builds', label: 'PROJECT BUILDS', count: builds.length },
                  ].map((ent) => (
                    <button
                      key={ent.id}
                      type="button"
                      onClick={() => setTargetEntity(ent.id as TargetEntity)}
                      className={`p-3 text-left border rounded-xs font-mono transition-all cursor-pointer ${
                        targetEntity === ent.id
                          ? 'border-primary bg-primary/10 text-primary font-bold'
                          : 'border-outline-variant bg-surface-container text-on-surface hover:bg-surface-container-high'
                      }`}
                    >
                      <p className="text-xs uppercase font-narrow font-extrabold">{ent.label}</p>
                      <p className="text-[10px] text-on-surface-variant mt-0.5">{ent.count} existing records</p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Download Sample Template Banner */}
              <div className="bg-emerald-500/10 border border-emerald-500/30 p-3.5 rounded-xs flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <Table size={18} className="text-emerald-400 shrink-0" />
                  <div>
                    <p className="font-mono text-xs font-bold text-emerald-400 uppercase">
                      NEED A FORMATTED EXCEL SPREADSHEET TEMPLATE?
                    </p>
                    <p className="text-[11px] text-slate-300 mt-0.5">
                      Download our pre-styled .xlsx template populated with correct column headers for {targetEntity.toUpperCase()}.
                    </p>
                  </div>
                </div>
                <button
                  id="btn-download-sample-excel-template"
                  type="button"
                  onClick={handleDownloadSampleTemplate}
                  className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-bold uppercase tracking-wider rounded-xs cursor-pointer shrink-0 flex items-center gap-1.5 transition-colors"
                >
                  <Download size={12} />
                  <span>DOWNLOAD TEMPLATE</span>
                </button>
              </div>

              {/* Upload Dropzone */}
              <div>
                <label className="block text-[10px] font-mono font-bold text-on-surface-variant uppercase tracking-wider mb-2">
                  2. UPLOAD EXCEL SPREADSHEET FILE (.XLSX, .XLS, .CSV)
                </label>
                
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept=".xlsx, .xls, .csv"
                  className="hidden"
                />

                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-outline-variant hover:border-primary p-8 text-center rounded-xs bg-surface-container hover:bg-surface-container-high cursor-pointer transition-all flex flex-col items-center justify-center gap-2"
                >
                  <FileSpreadsheet size={36} className="text-emerald-400 animate-bounce" />
                  <p className="font-mono text-xs font-bold text-on-surface uppercase">
                    {fileName ? fileName : 'CLICK TO BROWSE OR DRAG EXCEL FILE HERE'}
                  </p>
                  <p className="text-[11px] text-on-surface-variant">
                    Supports Microsoft Excel (.xlsx, .xls) and Comma-Separated Values (.csv)
                  </p>
                </div>
              </div>

              {/* Status messages */}
              {importSuccess && (
                <div className="p-3.5 bg-emerald-500/10 border border-emerald-500/40 text-emerald-400 rounded-xs flex items-center gap-2.5 font-mono text-xs">
                  <Check size={16} />
                  <span>{importSuccess}</span>
                </div>
              )}

              {importError && (
                <div className="p-3.5 bg-rose-500/10 border border-rose-500/40 text-rose-400 rounded-xs flex items-center gap-2.5 font-mono text-xs">
                  <AlertCircle size={16} />
                  <span>{importError}</span>
                </div>
              )}

              {/* Parsed Rows Preview Table */}
              {parsedRows.length > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <p className="font-mono text-xs font-bold text-on-surface uppercase flex items-center gap-2">
                      <Table size={14} className="text-primary" />
                      PARSED SPREADSHEET PREVIEW ({parsedRows.length} ROWS FOUND)
                    </p>
                    <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 border border-emerald-500/30 rounded-xs">
                      READY FOR IMPORT
                    </span>
                  </div>

                  <div className="max-h-56 overflow-auto border border-outline-variant rounded-xs">
                    <table className="w-full text-left font-mono text-[11px]">
                      <thead className="bg-slate-900 text-slate-200 sticky top-0 border-b border-outline-variant">
                        <tr>
                          {Object.keys(parsedRows[0]).map((colKey) => (
                            <th key={colKey} className="px-3 py-2 font-bold uppercase tracking-wider whitespace-nowrap">
                              {colKey}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-outline-variant/40 bg-slate-950 text-slate-300">
                        {parsedRows.slice(0, 8).map((row, idx) => (
                          <tr key={idx} className="hover:bg-slate-900/60">
                            {Object.keys(parsedRows[0]).map((colKey) => (
                              <td key={colKey} className="px-3 py-1.5 whitespace-nowrap truncate max-w-[200px]">
                                {String(row[colKey] ?? '')}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  <div className="flex justify-end gap-3 pt-2">
                    <button
                      id="btn-cancel-excel-preview"
                      type="button"
                      onClick={() => { setParsedRows([]); setFileName(null); }}
                      className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-xs uppercase rounded-xs border border-outline-variant/40 cursor-pointer"
                    >
                      CLEAR FILE
                    </button>

                    <button
                      id="btn-execute-excel-import"
                      type="button"
                      onClick={handleExecuteImport}
                      className="px-6 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-bold uppercase tracking-wider rounded-xs cursor-pointer shadow-md flex items-center gap-2"
                    >
                      <Upload size={14} />
                      <span>IMPORT {parsedRows.length} {targetEntity.toUpperCase()} RECORDS</span>
                    </button>
                  </div>
                </div>
              )}

            </div>
          ) : (
            /* Export Tab */
            <div className="space-y-6">
              
              <div className="bg-slate-900 p-5 border border-outline-variant rounded-xs space-y-2">
                <div className="flex items-center gap-2.5 text-primary">
                  <Layers size={20} />
                  <h4 className="font-narrow text-base font-bold uppercase tracking-wider">
                    MASTER CONSOLIDATED ENTERPRISE WORKBOOK
                  </h4>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed font-mono">
                  Export all active modules (Invoices, Clients, Projects, Raw Inventory) into a multi-sheet Microsoft Excel (.xlsx) workbook for financial reporting and offline auditing.
                </p>
                <div className="pt-2">
                  <button
                    id="btn-export-full-master-excel-workbook"
                    type="button"
                    onClick={() => exportFullWorkbook(invoices, clients, builds, inventory)}
                    className="px-6 py-3 bg-primary hover:bg-blue-700 text-white font-mono text-xs font-bold uppercase tracking-widest rounded-xs cursor-pointer shadow-lg flex items-center gap-2 border border-primary/20 transition-all hover:scale-[1.01]"
                  >
                    <Download size={16} />
                    <span>EXPORT MASTER ENTERPRISE WORKBOOK (.XLSX)</span>
                  </button>
                </div>
              </div>

              <div>
                <p className="font-mono text-xs font-bold text-on-surface uppercase mb-3">
                  INDIVIDUAL MODULE EXCEL SPREADSHEETS
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  
                  {/* Invoices */}
                  <div className="bg-surface-container border border-outline-variant p-4 rounded-xs flex justify-between items-center">
                    <div>
                      <p className="font-narrow font-extrabold text-sm uppercase text-on-surface">INVOICES LEDGER</p>
                      <p className="text-[11px] font-mono text-on-surface-variant">{invoices.length} billing records</p>
                    </div>
                    <button
                      id="btn-export-invoices-excel-single"
                      type="button"
                      onClick={() => exportInvoicesToExcel(invoices)}
                      className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-bold uppercase rounded-xs cursor-pointer flex items-center gap-1.5"
                    >
                      <Download size={12} />
                      <span>EXCEL</span>
                    </button>
                  </div>

                  {/* Clients */}
                  <div className="bg-surface-container border border-outline-variant p-4 rounded-xs flex justify-between items-center">
                    <div>
                      <p className="font-narrow font-extrabold text-sm uppercase text-on-surface">CLIENT DIRECTORY</p>
                      <p className="text-[11px] font-mono text-on-surface-variant">{clients.length} customer profiles</p>
                    </div>
                    <button
                      id="btn-export-clients-excel-single"
                      type="button"
                      onClick={() => exportClientsToExcel(clients)}
                      className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-bold uppercase rounded-xs cursor-pointer flex items-center gap-1.5"
                    >
                      <Download size={12} />
                      <span>EXCEL</span>
                    </button>
                  </div>

                  {/* Inventory */}
                  <div className="bg-surface-container border border-outline-variant p-4 rounded-xs flex justify-between items-center">
                    <div>
                      <p className="font-narrow font-extrabold text-sm uppercase text-on-surface">RAW MATERIALS INVENTORY</p>
                      <p className="text-[11px] font-mono text-on-surface-variant">{inventory.length} stock catalog items</p>
                    </div>
                    <button
                      id="btn-export-inventory-excel-single"
                      type="button"
                      onClick={() => exportInventoryToExcel(inventory)}
                      className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-bold uppercase rounded-xs cursor-pointer flex items-center gap-1.5"
                    >
                      <Download size={12} />
                      <span>EXCEL</span>
                    </button>
                  </div>

                  {/* Projects */}
                  <div className="bg-surface-container border border-outline-variant p-4 rounded-xs flex justify-between items-center">
                    <div>
                      <p className="font-narrow font-extrabold text-sm uppercase text-on-surface">PROJECT BUILDS PIPELINE</p>
                      <p className="text-[11px] font-mono text-on-surface-variant">{builds.length} active & archived builds</p>
                    </div>
                    <button
                      id="btn-export-builds-excel-single"
                      type="button"
                      onClick={() => exportBuildsToExcel(builds)}
                      className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-bold uppercase rounded-xs cursor-pointer flex items-center gap-1.5"
                    >
                      <Download size={12} />
                      <span>EXCEL</span>
                    </button>
                  </div>

                </div>
              </div>

            </div>
          )}

        </div>

      </div>
    </div>
  );
};
