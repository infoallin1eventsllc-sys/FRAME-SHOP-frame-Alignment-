/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useEffect, useState } from 'react';
import * as d3 from 'd3';
import { Build } from '../types';
import { Calendar, CheckCircle2, AlertCircle, Hourglass, Info } from 'lucide-react';

interface BuildTimelineProps {
  build: Build;
}

interface ProcessedMilestone {
  index: number;
  name: string;
  dateStr: string;
  description: string;
  status: 'COMPLETED' | 'IN_PROGRESS' | 'BLOCKED' | 'PENDING';
}

export const BuildTimeline: React.FC<BuildTimelineProps> = ({ build }) => {
  const svgRef = useRef<SVGSVGElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [selectedMilestone, setSelectedMilestone] = useState<ProcessedMilestone | null>(null);
  const [hoveredMilestone, setHoveredMilestone] = useState<ProcessedMilestone | null>(null);

  // Helper to parse date strings (e.g. "Oct 12, 2023" or "10/12/2023")
  const parseBuildDate = (dateStr: string | undefined): Date => {
    if (!dateStr) return new Date();
    const parsed = Date.parse(dateStr);
    if (!isNaN(parsed)) {
      return new Date(parsed);
    }
    return new Date();
  };

  const formatDate = (date: Date): string => {
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  // Generate milestone list based on fabrication/build type
  const getMilestones = (): ProcessedMilestone[] => {
    const start = parseBuildDate(build.startDate);
    const lowercaseType = (build.type || '').toLowerCase();

    let templates = [
      { name: 'Planning', days: 0, description: 'Initial order details, specs, and material clearance approved.' },
      { name: 'Tooling Setup', days: 3, description: 'Bending dies selected, jig fixtures aligned, and machine tolerances dialed.' },
      { name: 'Primary Fab', days: 7, description: 'Raw material stock (tubing/sheets) cut, coped, and tack welded.' },
      { name: 'Assembly Weld', days: 11, description: 'Heliarc TIG welding or CNC precision assembly executed.' },
      { name: 'Inspection', days: 14, description: 'Metrology measurement checks, dye penetrant weld inspection, and finishing.' },
      { name: 'Delivery Finish', days: 16, description: 'Corrosion inhibitor applied, and final project delivered to client.' }
    ];

    if (lowercaseType.includes('tig') || lowercaseType.includes('weld')) {
      templates = [
        { name: 'Order Queued', days: 0, description: 'Work order received and scheduled in the welding bay.' },
        { name: 'CAD & Design', days: 2, description: 'Joint prep specs, bevel angles, and purge plans finalized.' },
        { name: 'Prep & Tack', days: 5, description: 'Tubing sliced, deburred, prepped to bright metal, and tacked in fixtures.' },
        { name: 'TIG Welding', days: 9, description: 'Final Heliarc TIG welding with active argon back-purging.' },
        { name: 'Weld Check', days: 12, description: 'Visual inspection of bead width and penetration with finishing polish.' },
        { name: 'Delivery', days: 14, description: 'Fabricated exhaust/brackets delivered to client.' }
      ];
    } else if (lowercaseType.includes('machine') || lowercaseType.includes('cnc')) {
      templates = [
        { name: 'Model Checked', days: 0, description: 'Solidworks/CAD file verified for clearance fits and tolerances.' },
        { name: 'G-Code Path', days: 2, description: 'Mastercam G-code program simulated and feeds/speeds checked.' },
        { name: 'Rough Milling', days: 5, description: 'Billet block mounted in machine vise and high-speed rough cuts complete.' },
        { name: 'Finish Boring', days: 8, description: 'Precision bored fork sleeves and tapers milled to final spec.' },
        { name: 'Anodizing Bath', days: 11, description: 'Bead blasted to matte finish and submerged in sulfuric anodizing bath.' },
        { name: 'Metrology Sig', days: 13, description: 'Verified tolerances within +/- 0.02mm and packaged.' }
      ];
    } else if (lowercaseType.includes('frame') || lowercaseType.includes('fab') || lowercaseType.includes('hardtail')) {
      templates = [
        { name: 'Frame Check', days: 0, description: 'Stock frame measured on table for centerline drift and tube gauge.' },
        { name: 'Jig Mounting', days: 3, description: 'Frame locked in rigid metal fabrication fixture jig.' },
        { name: 'Section Cut', days: 6, description: 'Rear triangle severed at exact blueprint offsets.' },
        { name: 'Heliarc Join', days: 10, description: 'TIG joints welded with ER70S-2 high-strength rod.' },
        { name: 'Alignment Sig', days: 14, description: 'Axle plates aligned using laser alignment tools to perfect tolerance.' },
        { name: 'Delivery Finish', days: 16, description: 'Protective metal sealer wiped and frame released.' }
      ];
    }

    // Determine status of each milestone based on build status
    const status = build.status;
    let currentIdx = 0;

    if (status === 'QUEUED') {
      currentIdx = 0; // only start is done
    } else if (status === 'IN PROGRESS') {
      currentIdx = 2; // CAD and Prep complete, welding/boring is next
    } else if (status === 'PARTS WAIT') {
      currentIdx = 2; // blocked at third step
    } else if (status === 'COMPLETED') {
      currentIdx = 4; // final QC/inspect done, delivery pending
    } else if (status === 'DELIVERED') {
      currentIdx = 5; // everything done
    }

    return templates.map((t, idx) => {
      // Calculate date
      const mDate = new Date(start);
      mDate.setDate(mDate.getDate() + t.days);
      
      // Override final date if completed/delivered and actual completionDate exists
      let dateStr = formatDate(mDate);
      if (idx === templates.length - 1 && build.completionDate) {
        dateStr = build.completionDate;
      }

      let mStatus: ProcessedMilestone['status'] = 'PENDING';
      if (idx < currentIdx) {
        mStatus = 'COMPLETED';
      } else if (idx === currentIdx) {
        if (status === 'PARTS WAIT') {
          mStatus = 'BLOCKED';
        } else if (status === 'COMPLETED' || status === 'DELIVERED') {
          mStatus = 'COMPLETED';
        } else {
          mStatus = 'IN_PROGRESS';
        }
      } else if (status === 'COMPLETED' && idx < 5) {
        mStatus = 'COMPLETED';
      } else if (status === 'DELIVERED') {
        mStatus = 'COMPLETED';
      }

      return {
        index: idx,
        name: t.name,
        dateStr,
        description: t.description,
        status: mStatus
      };
    });
  };

  const milestones = getMilestones();

  // Pick default selected or hovered milestone for display
  const activeDisplayMilestone = hoveredMilestone || selectedMilestone || milestones.find(m => m.status === 'IN_PROGRESS' || m.status === 'BLOCKED') || milestones[0];

  useEffect(() => {
    if (!svgRef.current || !containerRef.current) return;

    // Clear previous SVG contents
    d3.select(svgRef.current).selectAll('*').remove();

    const margin = { top: 35, right: 40, bottom: 35, left: 40 };
    const containerWidth = containerRef.current.clientWidth || 500;
    const height = 110;
    const width = containerWidth - margin.left - margin.right;

    const svg = d3.select(svgRef.current)
      .attr('width', containerWidth)
      .attr('height', height)
      .append('g')
      .attr('transform', `translate(${margin.left}, ${margin.top})`);

    // X Scale based on index
    const xScale = d3.scaleLinear()
      .domain([0, milestones.length - 1])
      .range([0, width]);

    const yPos = 15; // Vertical position of timeline line

    // Draw background underlay line
    svg.append('line')
      .attr('x1', 0)
      .attr('y1', yPos)
      .attr('x2', width)
      .attr('y2', yPos)
      .attr('stroke', '#374151') // Gray-700
      .attr('stroke-width', 3)
      .attr('stroke-linecap', 'round');

    // Calculate completed path length
    const completedIndices = milestones.filter(m => m.status === 'COMPLETED').map(m => m.index);
    const maxCompletedIdx = completedIndices.length > 0 ? d3.max(completedIndices)! : -1;
    
    let activeIdx = milestones.findIndex(m => m.status === 'IN_PROGRESS' || m.status === 'BLOCKED');
    if (activeIdx === -1 && build.status === 'DELIVERED') {
      activeIdx = milestones.length - 1;
    }

    // Determine the progress end position
    let progressEndX = 0;
    if (maxCompletedIdx >= 0) {
      if (activeIdx > maxCompletedIdx) {
        // If there's an active step in progress, fill halfway to it
        progressEndX = xScale(maxCompletedIdx) + (xScale(activeIdx) - xScale(maxCompletedIdx)) * 0.5;
      } else {
        progressEndX = xScale(maxCompletedIdx);
      }
    }

    // Draw progress overlay line
    if (progressEndX > 0) {
      svg.append('line')
        .attr('x1', 0)
        .attr('y1', yPos)
        .attr('x2', progressEndX)
        .attr('y2', yPos)
        .attr('stroke', '#f97316') // Primary theme Orange-500
        .attr('stroke-width', 4)
        .attr('stroke-linecap', 'round')
        .attr('class', 'timeline-progress-line');
    }

    // Render Milestone Nodes (groups)
    const nodes = svg.selectAll('.milestone-node')
      .data(milestones)
      .enter()
      .append('g')
      .attr('class', 'milestone-node')
      .attr('transform', (d: any) => `translate(${xScale(d.index)}, ${yPos})`)
      .style('cursor', 'pointer');

    // Append outer glow/pulse for active/blocked steps
    nodes.filter((d: any) => d.status === 'IN_PROGRESS' || d.status === 'BLOCKED')
      .append('circle')
      .attr('r', 11)
      .attr('fill', (d: any) => d.status === 'BLOCKED' ? 'rgba(239, 68, 68, 0.2)' : 'rgba(249, 115, 22, 0.2)')
      .attr('stroke', (d: any) => d.status === 'BLOCKED' ? '#ef4444' : '#f97316')
      .attr('stroke-width', 1)
      .attr('class', 'animate-pulse');

    // Append primary circles
    nodes.append('circle')
      .attr('r', (d: any) => (d.status === 'IN_PROGRESS' || d.status === 'BLOCKED') ? 7 : 6)
      .attr('fill', (d: any) => {
        if (d.status === 'COMPLETED') return '#f97316'; // Orange-500
        if (d.status === 'BLOCKED') return '#ef4444'; // Red-500
        if (d.status === 'IN_PROGRESS') return '#111827'; // Dark BG
        return '#1f2937'; // Gray-800
      })
      .attr('stroke', (d: any) => {
        if (d.status === 'COMPLETED') return '#f97316';
        if (d.status === 'BLOCKED') return '#ef4444';
        if (d.status === 'IN_PROGRESS') return '#f97316';
        return '#374151'; // Gray-700
      })
      .attr('stroke-width', 2.5)
      .attr('class', 'transition-all duration-200');

    // Draw mini inner dot for in-progress
    nodes.filter((d: any) => d.status === 'IN_PROGRESS')
      .append('circle')
      .attr('r', 2)
      .attr('fill', '#f97316');

    // Draw little checkmark for completed steps
    nodes.filter((d: any) => d.status === 'COMPLETED')
      .append('path')
      .attr('d', 'M -2.5,0.2 L -0.8,1.8 L 2.2,-1.5')
      .attr('fill', 'none')
      .attr('stroke', '#111827')
      .attr('stroke-width', 1.2)
      .attr('stroke-linecap', 'round')
      .attr('stroke-linejoin', 'round');

    // Add alternate text labels to prevent overlap
    nodes.append('text')
      .attr('text-anchor', 'middle')
      .attr('y', (d: any, i) => i % 2 === 0 ? -20 : 25) // Odd nodes top, even nodes bottom
      .attr('fill', (d: any) => {
        if (d.status === 'COMPLETED') return '#ffffff';
        if (d.status === 'BLOCKED') return '#ef4444';
        if (d.status === 'IN_PROGRESS') return '#f97316';
        return '#9ca3af'; // Gray-400
      })
      .attr('font-size', '9px')
      .attr('font-family', 'JetBrains Mono, monospace')
      .attr('font-weight', (d: any) => (d.status === 'IN_PROGRESS' || d.status === 'BLOCKED') ? 'bold' : 'normal')
      .text((d: any) => d.name);

    // Add tiny date below/above names
    nodes.append('text')
      .attr('text-anchor', 'middle')
      .attr('y', (d: any, i) => i % 2 === 0 ? -31 : 35)
      .attr('fill', '#6b7280') // Gray-500
      .attr('font-size', '8px')
      .attr('font-family', 'ui-monospace, monospace')
      .text((d: any) => d.dateStr.split(',')[0]); // Just month and day, e.g. "Oct 12"

    // Set up interactive mouse listeners on the nodes
    nodes.on('mouseenter', function (event, d: any) {
      setHoveredMilestone(d);
      
      // Animate the hovered circle
      d3.select(this).select('circle:not(.animate-pulse)')
        .transition()
        .duration(150)
        .attr('r', 9);
    })
    .on('mouseleave', function (event, d: any) {
      setHoveredMilestone(null);
      
      // Restore normal radius
      d3.select(this).select('circle:not(.animate-pulse)')
        .transition()
        .duration(150)
        .attr('r', (d: any) => (d.status === 'IN_PROGRESS' || d.status === 'BLOCKED') ? 7 : 6);
    })
    .on('click', function (event, d: any) {
      setSelectedMilestone(d);
    });

  }, [build.id, build.status, build.startDate, build.completionDate]);

  // Handle window resizing
  useEffect(() => {
    const handleResize = () => {
      // Trigger SVG redraw
      setSelectedMilestone(prev => prev);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div className="bg-background/40 border border-outline-variant/30 p-5 rounded-sm space-y-4">
      {/* Header Info */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
        <h4 className="text-[11px] font-mono uppercase tracking-widest text-primary font-bold flex items-center gap-1.5">
          <Calendar size={13} className="text-primary" />
          PROJECT ROADMAP & MILESTONES (D3)
        </h4>
        <div className="flex items-center gap-4 text-[10px] font-mono text-on-surface-variant">
          <div className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full bg-primary inline-block"></span>
            <span>Completed</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full bg-[#111827] border border-primary inline-block"></span>
            <span>Active</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 inline-block animate-pulse"></span>
            <span>Blocked / Wait</span>
          </div>
        </div>
      </div>

      {/* SVG Container */}
      <div ref={containerRef} className="w-full overflow-x-auto select-none py-1 scrollbar-thin">
        <svg ref={svgRef} className="mx-auto block min-w-[500px]" />
      </div>

      {/* Focus Details Area */}
      {activeDisplayMilestone && (
        <div className="bg-background/60 border-l-2 border-primary/60 p-4 flex gap-3 items-start transition-all duration-150 rounded-r-sm">
          {activeDisplayMilestone.status === 'COMPLETED' ? (
            <CheckCircle2 size={16} className="text-primary mt-0.5 shrink-0" />
          ) : activeDisplayMilestone.status === 'BLOCKED' ? (
            <AlertCircle size={16} className="text-red-500 mt-0.5 shrink-0 animate-pulse" />
          ) : activeDisplayMilestone.status === 'IN_PROGRESS' ? (
            <Hourglass size={16} className="text-primary mt-0.5 shrink-0 animate-spin" style={{ animationDuration: '4s' }} />
          ) : (
            <Info size={16} className="text-on-surface-variant mt-0.5 shrink-0" />
          )}
          
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-white uppercase tracking-wider">
                Step {activeDisplayMilestone.index + 1}: {activeDisplayMilestone.name}
              </span>
              <span className={`text-[9px] font-mono px-1.5 py-0.2 rounded-xs border uppercase tracking-wider ${
                activeDisplayMilestone.status === 'COMPLETED'
                  ? 'bg-primary/10 text-primary border-primary/20'
                  : activeDisplayMilestone.status === 'BLOCKED'
                  ? 'bg-red-500/10 text-red-400 border-red-500/20'
                  : activeDisplayMilestone.status === 'IN_PROGRESS'
                  ? 'bg-orange-500/10 text-orange-400 border-orange-500/20'
                  : 'bg-white/5 text-on-surface-variant border-outline-variant/30'
              }`}>
                {activeDisplayMilestone.status === 'BLOCKED' ? 'BLOCKED' : activeDisplayMilestone.status.replace('_', ' ')}
              </span>
              <span className="text-[10px] font-mono text-on-surface-variant">
                — Target Date: {activeDisplayMilestone.dateStr}
              </span>
            </div>
            <p className="text-xs text-on-surface-variant leading-relaxed">
              {activeDisplayMilestone.description}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
