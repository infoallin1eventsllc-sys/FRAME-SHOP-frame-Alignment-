/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from 'react';
import { useAppState } from '../StateContext';
import { Build, BuildStatus } from '../types';
import { BuildTimeline } from './BuildTimeline';
import { 
  Hammer, 
  Search, 
  Plus, 
  Clock, 
  FileText, 
  DollarSign, 
  ChevronRight, 
  MessageSquareCode,
  CheckCircle2,
  AlertTriangle,
  Play,
  RotateCcw,
  X,
  Trash2,
  Download,
  Clipboard,
  Edit,
  Save,
  Archive,
  ArchiveRestore,
  History,
  FileSpreadsheet
} from 'lucide-react';
import { exportBuildsToExcel } from '../lib/excel';
import { ExcelConnectorModal } from './ExcelConnectorModal';

export const BuildsView: React.FC = () => {
  const { 
    builds, 
    clients, 
    addBuild, 
    updateBuildStatus, 
    updateBuildFabricationNotes, 
    archiveBuild,
    addBuildNote, 
    deleteBuild, 
    globalSearchQuery, 
    setGlobalSearchQuery 
  } = useAppState();

  const summaryStats = useMemo(() => {
    let active = 0;
    let completed = 0;
    let partsWait = 0;
    let totalHours = 0;

    builds.forEach(b => {
      const baseHours = b.status === 'QUEUED' ? 2 
                      : b.status === 'IN PROGRESS' ? 18 
                      : b.status === 'PARTS WAIT' ? 10 
                      : 45;
      const notesHours = (b.greaseMonkeyNotes?.length || 0) * 6;
      const scaleHours = Math.round((b.estimatedCost || 0) * 0.005);
      const hours = baseHours + notesHours + scaleHours;
      totalHours += hours;

      if (b.status === 'COMPLETED' || b.status === 'DELIVERED') {
        completed++;
      } else {
        active++;
        if (b.status === 'PARTS WAIT') {
          partsWait++;
        }
      }
    });

    return {
      active,
      completed,
      partsWait,
      totalHours
    };
  }, [builds]);

  const [searchTerm, setSearchTerm] = useState('');
  const [showArchived, setShowArchived] = useState(false);
  const [statusFilter, setStatusFilter] = useState<BuildStatus | 'ALL'>('ALL');
  const [selectedBuildId, setSelectedBuildId] = useState<string | null>(builds[0]?.id || null);
  const [isExcelModalOpen, setIsExcelModalOpen] = useState(false);

  // New Note state
  const [newNoteText, setNewNoteText] = useState('');

  // Rich-text Fabrication Notes editing states
  const [isEditingSpecs, setIsEditingSpecs] = useState(false);
  const [specsText, setSpecsText] = useState('');

  // Add Build Modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [buildName, setBuildName] = useState('');
  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [buildType, setBuildType] = useState('Frame Modification');
  const [buildDescription, setBuildDescription] = useState('');
  const [estimatedCost, setEstimatedCost] = useState('');

  const filteredBuilds = useMemo(() => {
    const localQuery = searchTerm.toLowerCase().trim();
    const globalQuery = globalSearchQuery.toLowerCase().trim();
    return builds.filter(b => {
      const matchesLocal = !localQuery ||
        b.id.toLowerCase().includes(localQuery) ||
        b.name.toLowerCase().includes(localQuery) ||
        b.customerName.toLowerCase().includes(localQuery) ||
        b.type.toLowerCase().includes(localQuery) ||
        (b.description && b.description.toLowerCase().includes(localQuery));

      const matchesGlobal = !globalQuery ||
        b.id.toLowerCase().includes(globalQuery) ||
        b.name.toLowerCase().includes(globalQuery) ||
        b.customerName.toLowerCase().includes(globalQuery) ||
        b.type.toLowerCase().includes(globalQuery) ||
        (b.description && b.description.toLowerCase().includes(globalQuery));

      const matchesStatus = statusFilter === 'ALL' || b.status === statusFilter;

      const matchesArchive = showArchived ? !!b.isArchived : !b.isArchived;

      return matchesLocal && matchesGlobal && matchesStatus && matchesArchive;
    });
  }, [builds, searchTerm, globalSearchQuery, statusFilter, showArchived]);

  const activeBuild = useMemo(() => {
    return builds.find(b => b.id === selectedBuildId) || filteredBuilds[0] || null;
  }, [selectedBuildId, builds, filteredBuilds]);

  // Synchronize local specs editing state with selected build
  useEffect(() => {
    if (activeBuild) {
      setSpecsText(activeBuild.fabricationNotes || '');
      setIsEditingSpecs(false);
    }
  }, [activeBuild?.id, activeBuild?.fabricationNotes]);

  // Insert formatting tag (e.g. bold, italic, list) around current selection or at cursor
  const insertFormatting = (tag: string) => {
    const textarea = document.getElementById('fabrication-notes-textarea') as HTMLTextAreaElement;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = textarea.value;
    const selected = text.substring(start, end);

    let replacement = '';
    if (tag === '**' || tag === '*') {
      replacement = tag + (selected || 'text') + tag;
    } else {
      replacement = tag + selected;
    }

    const updatedValue = text.substring(0, start) + replacement + text.substring(end);
    setSpecsText(updatedValue);

    // Reset cursor/focus
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start + tag.length, start + tag.length + (selected || 'text').length);
    }, 0);
  };

  // Insert specifications templates
  const insertPreset = (presetText: string) => {
    setSpecsText(prev => {
      const spacing = prev ? '\n\n' : '';
      return prev + spacing + presetText;
    });
    setTimeout(() => {
      const textarea = document.getElementById('fabrication-notes-textarea') as HTMLTextAreaElement;
      if (textarea) textarea.focus();
    }, 0);
  };

  // Helper parser for markdown-like elements in fabrication notes
  const renderRichText = (rawText: string) => {
    if (!rawText) {
      return (
        <div className="text-on-surface-variant italic text-xs py-8 text-center bg-background/20 rounded-sm border border-dashed border-outline-variant/30">
          No custom fabrication requirements or material callouts recorded for this build. Click "EDIT SPECS" above to add some.
        </div>
      );
    }

    const lines = rawText.split('\n');
    return (
      <div className="space-y-3 text-xs leading-relaxed text-on-surface">
        {lines.map((line, index) => {
          const trimmed = line.trim();
          
          // Render callouts / warning spec blocks
          if (trimmed.startsWith('>')) {
            const content = trimmed.substring(1).trim();
            return (
              <div key={index} className="bg-orange-500/5 border-l-4 border-primary p-3 my-3 font-mono text-[11px] text-[#ffd0b0]">
                <span className="font-bold text-primary uppercase tracking-wider block mb-1 text-[9px]">Material Callout / Spec:</span>
                {parseInlineMarkdown(content)}
              </div>
            );
          }

          // Render sub-headings
          if (trimmed.startsWith('###')) {
            return (
              <h5 key={index} className="text-xs font-mono font-bold text-primary uppercase tracking-wider mt-5 mb-2 border-b border-outline-variant/30 pb-1 flex items-center gap-1.5">
                <Clipboard size={12} className="text-primary" />
                {parseInlineMarkdown(trimmed.substring(3).trim())}
              </h5>
            );
          }

          // Render bullet lists
          if (trimmed.startsWith('-') || trimmed.startsWith('*')) {
            return (
              <div key={index} className="flex items-start gap-2 pl-2 my-1">
                <span className="text-primary mt-1">•</span>
                <span className="flex-1 text-[#e5e2e3]">{parseInlineMarkdown(trimmed.substring(1).trim())}</span>
              </div>
            );
          }

          // Empty line
          if (trimmed === '') {
            return <div key={index} className="h-2" />;
          }

          // Standard paragraph
          return (
            <p key={index} className="text-[#e5e2e3] pl-1">
              {parseInlineMarkdown(line)}
            </p>
          );
        })}
      </div>
    );
  };

  // Inline markdown bold/italic/code parser
  const parseInlineMarkdown = (text: string): React.ReactNode => {
    const codeRegex = /`([^`]+)`/g;
    const matches = [...text.matchAll(codeRegex)];
    if (matches.length > 0) {
      let lastIdx = 0;
      const elements: React.ReactNode[] = [];
      text.replace(codeRegex, (match, p1, offset) => {
        if (offset > lastIdx) {
          elements.push(parseBoldItalic(text.substring(lastIdx, offset)));
        }
        elements.push(<code key={offset} className="font-mono bg-black/45 border border-outline-variant/30 px-1 py-0.5 rounded text-orange-400 text-[10px]">{p1}</code>);
        lastIdx = offset + match.length;
        return match;
      });
      if (lastIdx < text.length) {
        elements.push(parseBoldItalic(text.substring(lastIdx)));
      }
      return <>{elements}</>;
    }

    return parseBoldItalic(text);
  };

  const parseBoldItalic = (text: string): React.ReactNode => {
    const boldRegex = /\*\*([^*]+)\*\*/g;
    let parts: React.ReactNode[] = [];
    let lastIdx = 0;
    text.replace(boldRegex, (match, p1, offset) => {
      if (offset > lastIdx) {
        parts.push(parseItalicOnly(text.substring(lastIdx, offset)));
      }
      parts.push(<strong key={offset} className="font-bold text-white">{p1}</strong>);
      lastIdx = offset + match.length;
      return match;
    });
    if (lastIdx < text.length) {
      parts.push(parseItalicOnly(text.substring(lastIdx)));
    }
    return <>{parts}</>;
  };

  const parseItalicOnly = (text: string): React.ReactNode => {
    const italicRegex = /\*([^*]+)\*/g;
    let parts: React.ReactNode[] = [];
    let lastIdx = 0;
    text.replace(italicRegex, (match, p1, offset) => {
      if (offset > lastIdx) {
        parts.push(text.substring(lastIdx, offset));
      }
      parts.push(<em key={offset} className="italic text-slate-300">{p1}</em>);
      lastIdx = offset + match.length;
      return match;
    });
    if (lastIdx < text.length) {
      parts.push(text.substring(lastIdx));
    }
    return <>{parts}</>;
  };

  const handleAddNewBuild = (e: React.FormEvent) => {
    e.preventDefault();
    if (!buildName || !selectedCustomerId || !estimatedCost) return;

    const chosenClient = clients.find(c => c.id === selectedCustomerId);
    if (!chosenClient) return;

    addBuild({
      name: buildName,
      customerId: chosenClient.id,
      customerName: chosenClient.name,
      type: buildType,
      description: buildDescription,
      status: 'QUEUED',
      startDate: new Date().toLocaleDateString('en-US', {
        month: 'short',
        day: '2-digit',
        year: 'numeric'
      }),
      estimatedCost: parseFloat(estimatedCost)
    });

    setBuildName('');
    setSelectedCustomerId('');
    setBuildType('Frame Modification');
    setBuildDescription('');
    setEstimatedCost('');
    setIsModalOpen(false);
  };

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNoteText.trim() || !activeBuild) return;

    addBuildNote(activeBuild.id, newNoteText.trim());
    setNewNoteText('');
  };

  const handleExportCSV = () => {
    if (!activeBuild) return;
    
    // Define headers
    const headers = ['Log Index', 'Project ID', 'Project Name', 'Customer Name', 'Type', 'Status', 'Date Logged / Start Date', 'Log Entry'];
    
    // Map existing grease monkey notes, fallback if none
    const rows = activeBuild.greaseMonkeyNotes.length > 0 
      ? activeBuild.greaseMonkeyNotes.map((note, index) => [
          String(index + 1),
          activeBuild.id,
          activeBuild.name,
          activeBuild.customerName,
          activeBuild.type,
          activeBuild.status,
          activeBuild.startDate,
          note
        ])
      : [[
          "N/A",
          activeBuild.id,
          activeBuild.name,
          activeBuild.customerName,
          activeBuild.type,
          activeBuild.status,
          activeBuild.startDate,
          "No logged notes or inspections recorded."
        ]];

    // Format content with proper double-quote escaping for robustness
    const csvContent = [
      headers.map(h => `"${h.replace(/"/g, '""')}"`).join(','),
      ...rows.map(row => row.map(val => `"${val.replace(/"/g, '""')}"`).join(','))
    ].join('\n');

    // Generate blob and trigger browser-side download
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `build_log_${activeBuild.id.replace(/[^a-zA-Z0-9]/g, '_')}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    deleteBuild(id);
    if (selectedBuildId === id) {
      setSelectedBuildId(builds[0]?.id || null);
    }
  };

  return (
    <div className="relative z-10 font-sans">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 mb-10">
        <div>
          <h2 className="text-4xl md:text-5xl font-bold uppercase tracking-tight text-on-surface font-narrow">
            Work Orders & Custom Builds
          </h2>
          <p className="text-base text-on-surface-variant font-medium mt-1">
            Active fabrication queues and metallurgy tolerances
          </p>
        </div>
        <div className="flex items-center gap-3 w-full md:w-auto">
          <button 
            id="btn-excel-builds"
            onClick={() => setIsExcelModalOpen(true)}
            className="flex-1 md:flex-none bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-5 py-3 font-semibold text-xs tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-all cursor-pointer rounded-sm"
          >
            <FileSpreadsheet size={16} />
            EXCEL HUB
          </button>
          <button 
            id="btn-export-builds-excel"
            onClick={() => exportBuildsToExcel(builds)}
            className="flex-1 md:flex-none border border-outline-variant hover:bg-surface-container-highest text-on-surface px-5 py-3 font-semibold text-xs tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-all cursor-pointer rounded-sm"
            title="Export Work Orders & Builds to Excel file"
          >
            <Download size={16} />
            EXPORT EXCEL
          </button>
          <button 
            id="btn-add-build"
            onClick={() => setIsModalOpen(true)}
            className="flex-1 md:flex-none bg-primary-container hover:opacity-90 text-white px-6 py-3 font-semibold text-xs tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-all cursor-pointer rounded-sm"
          >
            <Plus size={16} />
            INITIATE BUILD
          </button>
        </div>
      </div>

      {/* Shop Manager Summary Dashboard Header */}
      <div id="shop-manager-dashboard-header" className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        {/* Card 1: Active Queue */}
        <div className="bg-surface-container border border-outline-variant p-5 relative overflow-hidden rounded-xs group hover:border-primary/40 transition-all duration-300">
          <div className="metal-grain absolute inset-0 opacity-20 pointer-events-none" />
          <div className="relative z-10 flex items-center justify-between">
            <div className="space-y-1">
              <span className="font-mono text-[10px] text-on-surface-variant uppercase tracking-widest block font-bold">
                ACTIVE QUEUE
              </span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl md:text-4xl font-extrabold font-narrow tracking-tight text-on-surface">
                  {summaryStats.active}
                </span>
                <span className="text-xs font-mono font-medium text-primary">
                  Builds Active
                </span>
              </div>
              <div className="flex items-center gap-3 mt-2 text-[10px] font-mono text-on-surface-variant">
                <span className="flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-blue-500 rounded-full inline-block animate-pulse" />
                  In Prog: {builds.filter(b => b.status === 'IN PROGRESS').length}
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-amber-500 rounded-full inline-block" />
                  Parts Wait: {summaryStats.partsWait}
                </span>
              </div>
            </div>
            <div className="p-3 bg-primary/10 border border-primary/20 text-primary rounded-sm group-hover:scale-110 transition-transform duration-300">
              <Hammer size={24} />
            </div>
          </div>
        </div>

        {/* Card 2: Completed / Delivered */}
        <div className="bg-surface-container border border-outline-variant p-5 relative overflow-hidden rounded-xs group hover:border-emerald-500/40 transition-all duration-300">
          <div className="metal-grain absolute inset-0 opacity-20 pointer-events-none" />
          <div className="relative z-10 flex items-center justify-between">
            <div className="space-y-1">
              <span className="font-mono text-[10px] text-on-surface-variant uppercase tracking-widest block font-bold">
                COMPLETED & DELIVERED
              </span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl md:text-4xl font-extrabold font-narrow tracking-tight text-on-surface">
                  {summaryStats.completed}
                </span>
                <span className="text-xs font-mono font-medium text-emerald-600">
                  Total Finalized
                </span>
              </div>
              <div className="mt-2.5 max-w-xs">
                <div className="w-36 bg-slate-200 h-1 rounded-full overflow-hidden border border-slate-300/40">
                  <div 
                    style={{ 
                      width: `${builds.length > 0 ? (summaryStats.completed / builds.length) * 100 : 0}%` 
                    }}
                    className="h-full rounded-full bg-emerald-500 transition-all duration-500"
                  />
                </div>
              </div>
            </div>
            <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 rounded-sm group-hover:scale-110 transition-transform duration-300">
              <CheckCircle2 size={24} />
            </div>
          </div>
        </div>

        {/* Card 3: Total Hours Logged */}
        <div className="bg-surface-container border border-outline-variant p-5 relative overflow-hidden rounded-xs group hover:border-amber-500/40 transition-all duration-300">
          <div className="metal-grain absolute inset-0 opacity-20 pointer-events-none" />
          <div className="relative z-10 flex items-center justify-between">
            <div className="space-y-1">
              <span className="font-mono text-[10px] text-on-surface-variant uppercase tracking-widest block font-bold">
                SHOP OPERATIONAL HOURS
              </span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl md:text-4xl font-extrabold font-narrow tracking-tight text-on-surface">
                  {summaryStats.totalHours}
                </span>
                <span className="text-xs font-mono font-medium text-amber-600">
                  Hrs Logged
                </span>
              </div>
              <p className="text-[10px] font-mono text-on-surface-variant mt-2 leading-none">
                Based on specs & grease-monkey entries
              </p>
            </div>
            <div className="p-3 bg-amber-500/10 border border-amber-500/20 text-amber-600 rounded-sm group-hover:scale-110 transition-transform duration-300">
              <Clock size={24} />
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left: Active Builds queue list */}
        <div className="lg:col-span-5 bg-surface-container border border-outline-variant p-4">
          {/* Toggle Tabs: Active vs. Archive */}
          <div className="flex border-b border-outline-variant/60 mb-4">
            <button
              onClick={() => {
                setShowArchived(false);
                setSelectedBuildId(null);
              }}
              className={`flex-1 pb-3 text-center text-xs font-mono font-bold tracking-wider uppercase transition-all border-b-2 cursor-pointer ${
                !showArchived
                  ? 'border-primary text-primary'
                  : 'border-transparent text-on-surface-variant hover:text-on-surface'
              }`}
            >
              Active Queue ({builds.filter(b => !b.isArchived).length})
            </button>
            <button
              onClick={() => {
                setShowArchived(true);
                setSelectedBuildId(null);
              }}
              className={`flex-1 pb-3 text-center text-xs font-mono font-bold tracking-wider uppercase transition-all border-b-2 cursor-pointer flex items-center justify-center gap-1.5 ${
                showArchived
                  ? 'border-primary text-primary'
                  : 'border-transparent text-on-surface-variant hover:text-on-surface'
              }`}
            >
              <History size={12} />
              Historical Archive ({builds.filter(b => b.isArchived).length})
            </button>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant" size={15} />
              <input 
                type="text"
                placeholder="Search queues..."
                className="w-full bg-background border-none focus:outline-none focus:ring-1 focus:ring-primary-container text-on-surface pl-9 pr-3 py-2 text-xs"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <select
              className="bg-background border-none text-on-surface-variant text-[11px] font-bold uppercase tracking-wider px-3 py-2 cursor-pointer focus:outline-none"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
            >
              <option value="ALL">ALL STATUS</option>
              <option value="QUEUED">QUEUED</option>
              <option value="IN PROGRESS">IN PROGRESS</option>
              <option value="PARTS WAIT">PARTS WAIT</option>
              <option value="COMPLETED">COMPLETED</option>
              <option value="DELIVERED">DELIVERED</option>
            </select>
          </div>

          {globalSearchQuery && (
            <div className="mb-4 px-3 py-2 bg-primary/10 border border-primary/20 text-primary rounded-sm flex items-center justify-between text-[11px] font-mono">
              <span className="truncate">Top Filter: "{globalSearchQuery}"</span>
              <button 
                onClick={() => setGlobalSearchQuery('')}
                className="text-red-400 hover:text-red-300 font-bold uppercase tracking-wider ml-2 cursor-pointer transition-colors"
              >
                Clear
              </button>
            </div>
          )}

          <div className="space-y-2 max-h-[500px] overflow-y-auto custom-scrollbar pr-1">
            {filteredBuilds.length > 0 ? (
              filteredBuilds.map((b) => (
                <div
                  key={b.id}
                  onClick={() => setSelectedBuildId(b.id)}
                  className={`p-4 border transition-all cursor-pointer relative group ${
                    activeBuild?.id === b.id 
                      ? 'bg-primary/10 border-primary' 
                      : 'bg-surface border-outline-variant/40 hover:border-outline-variant'
                  }`}
                >
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-[10px] font-mono text-primary font-bold">
                      [{b.id}] {b.type}
                    </span>
                    <button
                      onClick={(e) => handleDelete(b.id, e)}
                      className="text-on-surface-variant hover:text-red-400 opacity-0 group-hover:opacity-100 p-0.5 rounded hover:bg-black/20 transition-all"
                      title="Abort Build Order"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                  <h4 className="text-sm font-semibold text-on-surface group-hover:text-primary transition-colors">
                    {b.name}
                  </h4>
                  <p className="text-xs text-on-surface-variant mt-1 truncate">
                    For: {b.customerName}
                  </p>

                  <div className="flex justify-between items-center mt-4 pt-3 border-t border-outline-variant/30">
                    <span className={`text-[9px] font-mono font-bold px-2.5 py-0.5 rounded-sm uppercase tracking-wider border ${
                      b.status === 'QUEUED'
                        ? 'bg-slate-500/10 text-slate-400 border-slate-500/30'
                        : b.status === 'IN PROGRESS'
                        ? 'bg-blue-500/15 text-blue-400 border-blue-500/30'
                        : b.status === 'PARTS WAIT'
                        ? 'bg-amber-500/15 text-amber-400 border-amber-500/30'
                        : b.status === 'COMPLETED'
                        ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                        : 'bg-indigo-500/15 text-indigo-400 border-indigo-500/30' // DELIVERED
                    }`}>
                      {b.status === 'PARTS WAIT' ? 'BLOCKED / PARTS' : b.status}
                    </span>
                    <span className="text-xs font-mono text-on-surface-variant label-md">
                      Est: ${b.estimatedCost}
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-xs text-on-surface-variant py-8 text-center italic">
                {showArchived 
                  ? "No archived historical projects found." 
                  : "No active workorders registered."}
              </p>
            )}
          </div>
        </div>

        {/* Right: Project engineering blueprint & logs */}
        <div className="lg:col-span-7 bg-surface-container border border-outline-variant relative min-h-[580px] flex flex-col justify-between">
          <div className="metal-grain absolute inset-0"></div>

          {activeBuild ? (
            <div className="relative z-10 p-6 md:p-8 flex-1 flex flex-col justify-between">
              <div>
                {/* Header specifications */}
                <div className="flex flex-col sm:flex-row justify-between items-start border-b border-outline-variant pb-6 gap-4">
                  <div>
                    <span className="text-xs font-mono text-primary font-bold uppercase tracking-widest block mb-1">
                      {activeBuild.type} BLUEPRINT
                    </span>
                    <h3 className="text-2xl font-bold text-on-surface">{activeBuild.name}</h3>
                    <p className="text-xs text-on-surface-variant mt-1.5 font-semibold">
                      Account Owner: <span className="text-[#e5e2e3] font-mono">{activeBuild.customerName}</span>
                    </p>
                  </div>
                  <div className="flex flex-row sm:flex-col gap-2 items-start sm:items-end font-mono">
                    <span className={`px-3 py-1 font-bold text-[10px] tracking-widest uppercase rounded-sm border ${
                      activeBuild.status === 'QUEUED'
                        ? 'bg-slate-500/10 text-slate-400 border-slate-500/30'
                        : activeBuild.status === 'IN PROGRESS'
                        ? 'bg-blue-500/15 text-blue-400 border-blue-500/30'
                        : activeBuild.status === 'PARTS WAIT'
                        ? 'bg-amber-500/15 text-amber-400 border-amber-500/30'
                        : activeBuild.status === 'COMPLETED'
                        ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                        : 'bg-indigo-500/15 text-indigo-400 border-indigo-500/30' // DELIVERED
                    }`}>
                      {activeBuild.status === 'PARTS WAIT' ? 'BLOCKED / PARTS' : activeBuild.status}
                    </span>
                    <span className="text-[10px] text-on-surface-variant tracking-wider uppercase block mt-1">
                      START: {activeBuild.startDate}
                    </span>
                  </div>
                </div>

                {/* Archive / Restore Banner Alerts */}
                {activeBuild.isArchived ? (
                  <div className="mt-4 p-3 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-sm flex flex-col sm:flex-row justify-between items-center gap-3 relative z-10">
                    <div className="flex items-center gap-2">
                      <History size={16} />
                      <span className="text-xs font-mono uppercase font-bold tracking-wider">This project is in the Historical Archive</span>
                    </div>
                    <button
                      onClick={() => archiveBuild(activeBuild.id, false)}
                      className="w-full sm:w-auto flex items-center justify-center gap-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 px-3 py-1.5 text-[10px] font-mono font-bold uppercase tracking-wider rounded-sm transition-all cursor-pointer"
                    >
                      <ArchiveRestore size={12} />
                      Restore to Active Queue
                    </button>
                  </div>
                ) : (activeBuild.status === 'COMPLETED' || activeBuild.status === 'DELIVERED') ? (
                  <div className="mt-4 p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-sm flex flex-col sm:flex-row justify-between items-center gap-3 relative z-10">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 size={16} />
                      <span className="text-xs font-mono uppercase font-bold tracking-wider">Project Completed & Ready for Storage</span>
                    </div>
                    <button
                      onClick={() => archiveBuild(activeBuild.id, true)}
                      className="w-full sm:w-auto flex items-center justify-center gap-1.5 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 px-3 py-1.5 text-[10px] font-mono font-bold uppercase tracking-wider rounded-sm transition-all cursor-pointer"
                    >
                      <Archive size={12} />
                      Archive Work Order
                    </button>
                  </div>
                ) : null}

                {/* Sub specifications metadata */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 my-6">
                  <div className="bg-background/40 border border-outline-variant/30 p-4">
                    <div className="flex items-center gap-1.5 text-on-surface-variant text-[10px] font-mono mb-1.5 uppercase font-semibold">
                      <FileText size={12} className="text-primary" /> WORK ORDER INTENT
                    </div>
                    <p className="text-xs text-[#e5e2e3] leading-relaxed">
                      {activeBuild.description}
                    </p>
                  </div>
                  <div className="bg-background/40 border border-outline-variant/30 p-4 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-1.5 text-on-surface-variant text-[10px] font-mono mb-1 uppercase font-semibold">
                        <DollarSign size={12} className="text-primary" /> FINANCIAL SUMMARY
                      </div>
                      <p className="text-lg font-bold font-narrow text-on-surface">
                        Est. Cost: <span className="text-primary">${activeBuild.estimatedCost}</span>
                      </p>
                      {activeBuild.actualCost && (
                        <p className="text-xs font-mono text-emerald-400 mt-1">
                          Settled / Invoiced: ${activeBuild.actualCost}
                        </p>
                      )}
                    </div>
                    {activeBuild.completionDate && (
                      <p className="text-[10px] font-mono text-on-surface-variant uppercase tracking-wider block mt-2">
                        COMPLETED: {activeBuild.completionDate}
                      </p>
                    )}
                  </div>
                </div>

                {/* Interactive Project Roadmap / Timeline */}
                <div className="my-6">
                  <BuildTimeline build={activeBuild} />
                </div>

                {/* Fabrication Requirements & Material Callouts */}
                <div className="bg-background/25 border border-outline-variant/30 p-5 my-6 space-y-4">
                  <div className="flex justify-between items-center">
                    <h4 className="text-xs font-mono uppercase tracking-widest text-primary font-bold flex items-center gap-1.5">
                      <Clipboard size={13} className="text-primary" />
                      FABRICATION REQUIREMENTS & MATERIAL CALLOUTS
                    </h4>
                    {!isEditingSpecs ? (
                      <button
                        onClick={() => {
                          setSpecsText(activeBuild.fabricationNotes || '');
                          setIsEditingSpecs(true);
                        }}
                        className="flex items-center gap-1 border border-primary/20 hover:bg-primary/10 text-primary text-[10px] font-mono font-bold uppercase tracking-wider px-2.5 py-1 rounded-xs cursor-pointer transition-colors"
                        title="Edit fabrication specs and notes"
                      >
                        <Edit size={11} />
                        EDIT SPECS
                      </button>
                    ) : (
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={async () => {
                            await updateBuildFabricationNotes(activeBuild.id, specsText);
                            setIsEditingSpecs(false);
                          }}
                          className="flex items-center gap-1 bg-primary hover:bg-orange-600 text-white text-[10px] font-mono font-bold uppercase tracking-wider px-2.5 py-1 rounded-xs cursor-pointer transition-colors shadow-sm"
                        >
                          <Save size={11} />
                          SAVE SPECS
                        </button>
                        <button
                          onClick={() => {
                            setIsEditingSpecs(false);
                          }}
                          className="flex items-center gap-1 border border-outline-variant hover:bg-white/5 text-on-surface-variant text-[10px] font-mono font-bold uppercase tracking-wider px-2.5 py-1 rounded-xs cursor-pointer transition-colors"
                        >
                          CANCEL
                        </button>
                      </div>
                    )}
                  </div>

                  {!isEditingSpecs ? (
                    <div className="bg-background/50 border border-outline-variant/20 p-4 max-h-[300px] overflow-y-auto custom-scrollbar">
                      {renderRichText(activeBuild.fabricationNotes || '')}
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {/* Rich Formatting Toolbar */}
                      <div className="flex flex-wrap gap-1 bg-background/80 border border-outline-variant/40 p-1.5 rounded-sm">
                        <button
                          type="button"
                          onClick={() => insertFormatting('**')}
                          className="px-2 py-1 text-[10px] font-mono font-bold bg-surface-container-highest/60 hover:bg-surface-container-highest text-on-surface border border-outline-variant/30 rounded-xs cursor-pointer"
                          title="Bold"
                        >
                          B
                        </button>
                        <button
                          type="button"
                          onClick={() => insertFormatting('*')}
                          className="px-2 py-1 text-[10px] font-mono italic bg-surface-container-highest/60 hover:bg-surface-container-highest text-on-surface border border-outline-variant/30 rounded-xs cursor-pointer"
                          title="Italic"
                        >
                          I
                        </button>
                        <button
                          type="button"
                          onClick={() => insertFormatting('### ')}
                          className="px-2 py-1 text-[10px] font-mono bg-surface-container-highest/60 hover:bg-surface-container-highest text-on-surface border border-outline-variant/30 rounded-xs cursor-pointer"
                          title="Heading"
                        >
                          H3
                        </button>
                        <button
                          type="button"
                          onClick={() => insertFormatting('- ')}
                          className="px-2 py-1 text-[10px] font-mono bg-surface-container-highest/60 hover:bg-surface-container-highest text-on-surface border border-outline-variant/30 rounded-xs cursor-pointer"
                          title="Bullet List"
                        >
                          • List
                        </button>
                        <button
                          type="button"
                          onClick={() => insertFormatting('> ')}
                          className="px-2 py-1 text-[10px] font-mono bg-surface-container-highest/60 hover:bg-surface-container-highest text-on-surface border border-outline-variant/30 rounded-xs cursor-pointer"
                          title="Material Callout"
                        >
                          &gt; Callout
                        </button>
                        
                        <div className="h-4 w-px bg-outline-variant/40 mx-1 align-self-center"></div>

                        {/* Presets dropdown / pill buttons */}
                        <span className="text-[9px] font-mono text-on-surface-variant font-bold uppercase tracking-wide flex items-center mr-1">
                          SPECS PRESETS:
                        </span>
                        <button
                          type="button"
                          onClick={() => insertPreset('### MATERIAL REQUIREMENT\n> Chromoly Tubing (Grade 4130) with seamless finish\n- Diameter: 1.25 inches\n- Wall Thickness: 0.083 inches')}
                          className="px-2 py-1 text-[9px] font-mono bg-orange-500/10 hover:bg-orange-500/20 text-orange-400 border border-orange-500/30 rounded-xs cursor-pointer"
                        >
                          + Chromoly 4130
                        </button>
                        <button
                          type="button"
                          onClick={() => insertPreset('### WELDING PROTOCOL\n> Pure argon shieldgas gas flow, back-purge required.\n- Process: Heliarc TIG Welding\n- Filler Material: ER70S-2 (1/16" rod)\n- Preheating Temp: None required for < 0.120" wall thickness')}
                          className="px-2 py-1 text-[9px] font-mono bg-orange-500/10 hover:bg-orange-500/20 text-orange-400 border border-orange-500/30 rounded-xs cursor-pointer"
                        >
                          + TIG Weld Spec
                        </button>
                        <button
                          type="button"
                          onClick={() => insertPreset('### CNC / MACHINING SPEC\n> Target clearance micro-tolerance fits.\n- General Machining Tolerance: +/- 0.02 mm\n- Keyways alignment check to within 0.01 degree')}
                          className="px-2 py-1 text-[9px] font-mono bg-orange-500/10 hover:bg-orange-500/20 text-orange-400 border border-orange-500/30 rounded-xs cursor-pointer"
                        >
                          + CNC Specs
                        </button>
                      </div>

                      <textarea
                        id="fabrication-notes-textarea"
                        value={specsText}
                        onChange={(e) => setSpecsText(e.target.value)}
                        placeholder="Document the design requirements, tube specs, heat treating callouts, or TIG rod selection..."
                        className="w-full h-48 bg-background border border-outline-variant focus:outline-none focus:ring-1 focus:ring-primary-container text-xs text-on-surface p-3 font-mono custom-scrollbar"
                      />
                      <p className="text-[10px] font-mono text-on-surface-variant italic">
                        {"Formatting Tips: Use **bold**, *italics*, `### Heading` on a new line, `- lists` on a new line, or `>` on a new line for orange Material Callout blocks."}
                      </p>
                    </div>
                  )}
                </div>

                {/* Update build status buttons */}
                <div className="border-t border-b border-outline-variant/60 py-5 my-6">
                  <h4 className="text-[11px] font-mono uppercase tracking-widest font-bold text-on-surface-variant mb-3">
                    FABRICATOR WORK COMMAND CONTROLS
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {(['QUEUED', 'IN PROGRESS', 'PARTS WAIT', 'COMPLETED', 'DELIVERED'] as BuildStatus[]).map((st) => (
                      <button
                        key={st}
                        onClick={() => updateBuildStatus(activeBuild.id, st)}
                        className={`px-3 py-1.5 text-[9px] font-mono font-extrabold tracking-widest uppercase transition-all rounded-xs border cursor-pointer ${
                          activeBuild.status === st 
                            ? 'bg-primary border-primary text-white' 
                            : 'bg-background hover:bg-surface-container-highest border-outline-variant/80 text-on-surface-variant'
                        }`}
                      >
                        {st}
                      </button>
                    ))}

                    {/* Archive / Restore Action */}
                    <button
                      onClick={() => archiveBuild(activeBuild.id, !activeBuild.isArchived)}
                      className={`px-3 py-1.5 text-[9px] font-mono font-extrabold tracking-widest uppercase transition-all rounded-xs border cursor-pointer flex items-center gap-1.5 ${
                        activeBuild.isArchived
                          ? 'bg-amber-500/15 border-amber-500/30 text-amber-400 hover:bg-amber-500/25'
                          : 'bg-slate-500/10 border-slate-500/30 text-slate-400 hover:bg-slate-500/15'
                      }`}
                      title={activeBuild.isArchived ? "Restore to active queue" : "Archive finished project"}
                    >
                      {activeBuild.isArchived ? <ArchiveRestore size={12} /> : <Archive size={12} />}
                      {activeBuild.isArchived ? 'RESTORE PROJECT' : 'ARCHIVE PROJECT'}
                    </button>
                  </div>
                </div>

                {/* Live Engineering logs (Grease-monkey logs) */}
                <div className="space-y-4">
                  <div className="flex justify-between items-center flex-wrap gap-2">
                    <h4 className="text-xs font-mono uppercase tracking-widest text-primary font-bold flex items-center gap-1.5">
                      <MessageSquareCode size={13} />
                      GREASE-MONKEY ENGINEER QUALITY LOGS ({activeBuild.greaseMonkeyNotes.length})
                    </h4>
                    <button
                      id="export-csv-btn"
                      type="button"
                      onClick={handleExportCSV}
                      className="flex items-center gap-1 bg-primary/10 hover:bg-primary/20 border border-primary/30 text-primary text-[10px] font-mono font-bold uppercase tracking-wider px-2.5 py-1 rounded-sm cursor-pointer transition-colors"
                      title="Export build logs to CSV"
                    >
                      <Download size={11} />
                      EXPORT LOGS (CSV)
                    </button>
                  </div>
                  <div className="bg-background/60 border border-outline-variant/20 p-4 max-h-[160px] overflow-y-auto custom-scrollbar font-mono text-xs text-on-surface-variant space-y-2.5">
                    {activeBuild.greaseMonkeyNotes.length > 0 ? (
                      activeBuild.greaseMonkeyNotes.map((note, index) => (
                        <p key={index} className="leading-relaxed border-l-2 border-primary-container/65 pl-2">
                          {note}
                        </p>
                      ))
                    ) : (
                      <p className="text-center italic py-4">No logged notes or inspections recorded.</p>
                    )}
                  </div>
                </div>
              </div>

              {/* Add Note text-area fields */}
              <form onSubmit={handleAddNote} className="mt-6 pt-4 border-t border-outline-variant/40">
                <div className="flex gap-2">
                  <input 
                    type="text"
                    required
                    placeholder="Input real-time alignment checks, welding specs, or parts statuses..."
                    className="flex-1 bg-background border border-outline-variant focus:outline-none focus:ring-1 focus:ring-primary-container text-xs text-on-surface p-3"
                    value={newNoteText}
                    onChange={(e) => setNewNoteText(e.target.value)}
                  />
                  <button 
                  id="btn-note-submit"
                    type="submit"
                    className="bg-primary hover:opacity-90 text-white px-4 py-3 font-semibold text-[11px] tracking-wider uppercase cursor-pointer"
                  >
                    LOG NOTE
                  </button>
                </div>
              </form>
            </div>
          ) : (
            <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-on-surface-variant">
              <Hammer size={32} className="stroke-1 mb-2 animate-bounce" />
              <p className="text-sm italic">Queue empty or no active fabrication swap.</p>
            </div>
          )}
        </div>
      </div>

      {/* Build Add Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4 backdrop-blur-xs">
          <div className="bg-surface border-2 border-outline w-full max-w-lg shadow-2xl relative">
            <div className="metal-grain absolute inset-0"></div>
            
            <div className="relative z-10 p-6">
              {/* Header */}
              <div className="flex justify-between items-center border-b border-outline-variant pb-4 mb-6">
                <h3 className="text-xl font-bold uppercase tracking-wider text-primary font-narrow">
                  INITIATE WORK ORDER / CUSTOM BUILD
                </h3>
                <button 
                  onClick={() => setIsModalOpen(false)}
                  className="text-on-surface-variant hover:text-on-surface cursor-pointer"
                >
                  <X size={20} />
                </button>
              </div>

              {/* Form */}
              <form onSubmit={handleAddNewBuild} className="space-y-4">
                {/* Build Name */}
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-on-surface-variant mb-1 ml-0.5">
                    Build Name / Designation
                  </label>
                  <input
                    id="build-name"
                    type="text"
                    required
                    placeholder="e.g. '74 Ironhead Frame Modification"
                    className="w-full bg-background border border-outline-variant text-[#e5e2e3] focus:ring-1 focus:ring-primary-container p-3 text-sm focus:outline-none"
                    value={buildName}
                    onChange={(e) => setBuildName(e.target.value)}
                  />
                </div>

                {/* Customer selection */}
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-on-surface-variant mb-1 ml-0.5">
                    Account Owner / Client
                  </label>
                  <select
                    id="build-customer-select"
                    className="w-full bg-background border border-outline-variant text-[#e5e2e3] focus:ring-1 focus:ring-primary-container p-3 text-sm focus:outline-none"
                    value={selectedCustomerId}
                    onChange={(e) => setSelectedCustomerId(e.target.value)}
                    required
                  >
                    <option value="">-- Associate Customer account --</option>
                    {clients.map(c => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.company || 'Private'})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Grid Type & Estimated cost */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-mono uppercase tracking-wider text-on-surface-variant mb-1 ml-0.5">
                      Fabrication Class / Type
                    </label>
                    <select
                      className="w-full bg-background border border-outline-variant text-[#e5e2e3] focus:ring-1 focus:ring-primary-container p-3 text-sm focus:outline-none font-semibold"
                      value={buildType}
                      onChange={(e) => setBuildType(e.target.value)}
                    >
                      <option value="Frame Modification">Frame Modification</option>
                      <option value="TIG Welding">TIG Welding</option>
                      <option value="CNC Machined">CNC Machined</option>
                      <option value="Production Run">Production Run</option>
                      <option value="Restoration">Restoration</option>
                      <option value="Chassis Rig Setup">Chassis Rig Setup</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-mono uppercase tracking-wider text-on-surface-variant mb-1 ml-0.5">
                      Estimated Cost ($)
                    </label>
                    <input
                      id="build-cost-input"
                      type="number"
                      required
                      min="0"
                      placeholder="e.g. 5000"
                      className="w-full bg-background border border-outline-variant text-[#e5e2e3] focus:ring-1 focus:ring-primary-container p-3 text-sm focus:outline-none font-mono"
                      value={estimatedCost}
                      onChange={(e) => setEstimatedCost(e.target.value)}
                    />
                  </div>
                </div>

                {/* Description */}
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-on-surface-variant mb-1 ml-0.5">
                    Structural Specifications & Quality Goal
                  </label>
                  <textarea
                    id="build-description"
                    placeholder="Detail tubing dimensions, segment cuts, rake clearances, and metallurgy tolerances requested."
                    className="w-full bg-background border border-outline-variant text-[#e5e2e3] focus:ring-1 focus:ring-primary-container p-3 text-sm focus:outline-none h-24 resize-none"
                    value={buildDescription}
                    onChange={(e) => setBuildDescription(e.target.value)}
                  />
                </div>

                {/* Submit */}
                <div className="pt-4 border-t border-outline flex gap-3">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="flex-1 py-3 text-xs tracking-wider border border-outline text-on-surface font-semibold hover:bg-surface-container-highest transition-all"
                  >
                    CANCEL
                  </button>
                  <button
                    id="btn-build-submit"
                    type="submit"
                    className="flex-1 py-3 text-xs tracking-wider bg-primary-container text-white hover:opacity-90 font-bold transition-all"
                  >
                    AUTHORIZE DISPATCH
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Excel Connector Hub Modal */}
      <ExcelConnectorModal
        isOpen={isExcelModalOpen}
        onClose={() => setIsExcelModalOpen(false)}
        defaultTab="export"
      />
    </div>
  );
};
