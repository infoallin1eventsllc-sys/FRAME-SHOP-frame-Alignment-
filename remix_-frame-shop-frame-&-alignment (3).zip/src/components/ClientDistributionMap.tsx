import React, { useState, useMemo } from 'react';
import { useAppState } from '../StateContext.tsx';
import { Client } from '../types.ts';
import { 
  Globe, 
  MapPin, 
  Layers, 
  TrendingUp, 
  CheckCircle2, 
  Wrench,
  DollarSign
} from 'lucide-react';

interface ClientDistributionMapProps {
  onSelectClient: (client: Client) => void;
  selectedClientId?: string;
}

interface MapRegion {
  id: string;
  name: string;
  states: string;
  color: string;
  dotColor: string;
}

// 6 Zones with their descriptive names
const REGIONS: MapRegion[] = [
  { id: 'west', name: 'West Coast Zone', states: 'WA, OR, CA, NV', color: 'stroke-amber-500 fill-amber-500/5 hover:fill-amber-500/10', dotColor: 'bg-amber-400' },
  { id: 'mountain', name: 'Mountain & Desert', states: 'CO, UT, AZ, NM, ID, WY', color: 'stroke-orange-500 fill-orange-500/5 hover:fill-orange-500/10', dotColor: 'bg-orange-400' },
  { id: 'midwest', name: 'Midwest Metallurgy Hub', states: 'IL, IN, MI, OH, WI, MN, IA', color: 'stroke-blue-500 fill-blue-500/5 hover:fill-blue-500/10', dotColor: 'bg-blue-400' },
  { id: 'south', name: 'Gulf & Southern Choppers', states: 'TX, FL, GA, TN, LA, AL', color: 'stroke-emerald-500 fill-emerald-500/5 hover:fill-emerald-500/10', dotColor: 'bg-emerald-400' },
  { id: 'northeast', name: 'Northeast Precision Corridor', states: 'NY, MA, PA, NJ, CT, MD', color: 'stroke-purple-500 fill-purple-500/5 hover:fill-purple-500/10', dotColor: 'bg-purple-400' },
  { id: 'international', name: 'International / Export Inset', states: 'Canada, Europe, UK, Australia', color: 'stroke-slate-500 fill-slate-500/5 hover:fill-slate-500/10', dotColor: 'bg-slate-400' }
];

export const getClientRegion = (client: Client): string => {
  // Hardcoded mappings for initial seed clients
  if (client.id === 'C-001') return 'midwest';
  if (client.id === 'C-002') return 'west';
  if (client.id === 'C-003') return 'northeast';
  if (client.id === 'C-004') return 'south';
  if (client.id === 'C-005') return 'mountain';
  if (client.id === 'C-006') return 'west';

  // Extract from notes if there is a region string, e.g. "[Region: West Coast]"
  const notesLower = client.notes.toLowerCase();
  if (notesLower.includes('west coast') || notesLower.includes('pacific') || notesLower.includes('california') || notesLower.includes('seattle')) return 'west';
  if (notesLower.includes('mountain') || notesLower.includes('desert') || notesLower.includes('denver') || notesLower.includes('arizona')) return 'mountain';
  if (notesLower.includes('midwest') || notesLower.includes('chicago') || notesLower.includes('great lakes') || notesLower.includes('michigan')) return 'midwest';
  if (notesLower.includes('south') || notesLower.includes('texas') || notesLower.includes('florida') || notesLower.includes('austin')) return 'south';
  if (notesLower.includes('northeast') || notesLower.includes('boston') || notesLower.includes('new york') || notesLower.includes('east coast')) return 'northeast';
  if (notesLower.includes('international') || notesLower.includes('canada') || notesLower.includes('export') || notesLower.includes('europe')) return 'international';

  // Fallback to deterministic hash
  const regions = ['west', 'mountain', 'midwest', 'south', 'northeast', 'international'];
  let charSum = 0;
  for (let i = 0; i < client.id.length; i++) {
    charSum += client.id.charCodeAt(i);
  }
  return regions[charSum % regions.length];
};

// Map coordinates for client cities in an 800x420 canvas
const CITY_COORDINATES: Record<string, { x: number; y: number; city: string; state: string }> = {
  'C-001': { x: 480, y: 150, city: 'Chicago', state: 'IL' },
  'C-002': { x: 100, y: 80, city: 'Seattle', state: 'WA' },
  'C-003': { x: 670, y: 120, city: 'Boston', state: 'MA' },
  'C-004': { x: 380, y: 340, city: 'Austin', state: 'TX' },
  'C-005': { x: 290, y: 195, city: 'Denver', state: 'CO' },
  'C-006': { x: 95, y: 190, city: 'San Francisco', state: 'CA' },
};

export const ClientDistributionMap: React.FC<ClientDistributionMapProps> = ({
  onSelectClient,
  selectedClientId
}) => {
  const { clients, builds } = useAppState();
  const [activeRegionId, setActiveRegionId] = useState<string | null>(null);
  const [hoveredClient, setHoveredClient] = useState<Client | null>(null);
  const [hoveredRegion, setHoveredRegion] = useState<MapRegion | null>(null);

  // Map clients to their computed regions
  const clientsWithRegions = useMemo(() => {
    return clients.map(client => ({
      ...client,
      regionId: getClientRegion(client)
    }));
  }, [clients]);

  // Aggregate stats per region
  const regionStats = useMemo(() => {
    const stats: Record<string, { 
      clientCount: number; 
      activeBuilds: number; 
      totalSpend: number; 
      outstandingBal: number;
      clients: Client[];
    }> = {};

    REGIONS.forEach(r => {
      stats[r.id] = { clientCount: 0, activeBuilds: 0, totalSpend: 0, outstandingBal: 0, clients: [] };
    });

    clientsWithRegions.forEach(c => {
      const rId = c.regionId;
      if (!stats[rId]) {
        stats[rId] = { clientCount: 0, activeBuilds: 0, totalSpend: 0, outstandingBal: 0, clients: [] };
      }
      stats[rId].clientCount += 1;
      stats[rId].totalSpend += c.lifetimeSpend || 0;
      stats[rId].outstandingBal += c.outstandingBalance || 0;
      stats[rId].clients.push(c);

      // Find active builds
      const clientBuilds = builds.filter(b => b.customerId === c.id && b.status !== 'COMPLETED' && b.status !== 'DELIVERED');
      stats[rId].activeBuilds += clientBuilds.length;
    });

    return stats;
  }, [clientsWithRegions, builds]);

  // Calculate coordinates for dynamic nodes (including newly added clients)
  const clientNodes = useMemo(() => {
    return clientsWithRegions.map(c => {
      // If we have hardcoded coordinates, use them
      if (CITY_COORDINATES[c.id]) {
        return {
          ...c,
          ...CITY_COORDINATES[c.id]
        };
      }

      // Otherwise, assign coordinates based on their region
      const rId = c.regionId;
      let baseCoord = { x: 400, y: 200, city: 'Domestic', state: 'US' };

      if (rId === 'west') {
        baseCoord = { x: 120, y: 230, city: 'Los Angeles', state: 'CA' };
      } else if (rId === 'mountain') {
        baseCoord = { x: 230, y: 250, city: 'Phoenix', state: 'AZ' };
      } else if (rId === 'midwest') {
        baseCoord = { x: 450, y: 110, city: 'Minneapolis', state: 'MN' };
      } else if (rId === 'south') {
        baseCoord = { x: 570, y: 320, city: 'Atlanta', state: 'GA' };
      } else if (rId === 'northeast') {
        baseCoord = { x: 630, y: 150, city: 'Philadelphia', state: 'PA' };
      } else if (rId === 'international') {
        baseCoord = { x: 740, y: 350, city: 'Overseas Hub', state: 'INTL' };
      }

      // Add a slight random offset to prevent exact overlap
      const seed = c.id.charCodeAt(c.id.length - 1) || 0;
      const offsetX = ((seed % 7) - 3) * 15;
      const offsetY = (((seed >> 1) % 7) - 3) * 15;

      return {
        ...c,
        x: baseCoord.x + offsetX,
        y: baseCoord.y + offsetY,
        city: baseCoord.city,
        state: baseCoord.state
      };
    });
  }, [clientsWithRegions]);

  // Selected region or fallback to hovered region info
  const displayRegionInfo = hoveredRegion || (activeRegionId ? REGIONS.find(r => r.id === activeRegionId) : null);
  const displayRegionStats = displayRegionInfo ? regionStats[displayRegionInfo.id] : null;

  return (
    <div id="client-distribution-map-card" className="mt-12 bg-surface-container border border-outline-variant p-6 relative overflow-hidden">
      <div className="metal-grain absolute inset-0 opacity-40 pointer-events-none" />
      
      {/* Visual Accent Headers */}
      <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6 border-b border-outline-variant/60 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Globe size={18} className="text-primary animate-pulse" />
            <h3 className="text-lg font-bold uppercase tracking-wider text-on-surface font-narrow">
              Client Distribution & Logistics Map
            </h3>
          </div>
          <p className="text-xs text-on-surface-variant font-mono uppercase tracking-widest mt-0.5">
            Region Registry • ACTIVE METALLURGY EXPORTS
          </p>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap gap-3 font-mono text-[10px]">
          {REGIONS.map(r => {
            const isActive = activeRegionId === r.id;
            const count = regionStats[r.id]?.clientCount || 0;
            return (
              <button
                key={r.id}
                onClick={() => setActiveRegionId(activeRegionId === r.id ? null : r.id)}
                className={`px-2 py-1 flex items-center gap-1.5 border transition-all cursor-pointer rounded-xs ${
                  isActive 
                    ? 'bg-primary/20 border-primary text-white font-bold shadow-xs' 
                    : 'bg-surface/50 border-outline-variant/40 text-slate-400 hover:text-white hover:border-outline-variant'
                }`}
              >
                <span className={`w-2 h-2 rounded-full ${r.dotColor.replace('bg-', 'bg-')}`} />
                <span className="uppercase tracking-wider">{r.id} ({count})</span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Interactive SVG Map Container */}
        <div className="lg:col-span-8 bg-slate-950/80 border border-outline-variant/40 relative overflow-hidden rounded-xs p-2 shadow-inner">
          
          {/* Subtle Grid overlay representing blueprint lines */}
          <div className="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none" />
          
          {/* Coordinates Legend */}
          <div className="absolute top-2 left-2 font-mono text-[9px] text-slate-500 pointer-events-none">
            LAT: 37.0902° N / LON: 95.7129° W
          </div>
          <div className="absolute bottom-2 right-2 font-mono text-[9px] text-slate-500 pointer-events-none">
            FRAME-SHOP LOGISTICS CORE v2.8
          </div>

          <svg 
            viewBox="0 0 800 420" 
            className="w-full h-auto select-none"
            id="distribution-svg-map"
          >
            {/* Background Map Shapes (Stylized USA Regions) */}
            <g id="map-regions-layer">
              {/* Region 1: West Coast */}
              <polygon 
                points="70,60 170,60 180,180 160,260 130,300 80,240 70,180" 
                className={`transition-all duration-300 stroke-1 cursor-pointer ${
                  activeRegionId === 'west' 
                    ? 'stroke-amber-400 fill-amber-500/20' 
                    : hoveredRegion?.id === 'west'
                      ? 'stroke-amber-500/70 fill-amber-500/10'
                      : 'stroke-amber-500/20 fill-amber-500/2'
                }`}
                onClick={() => setActiveRegionId(activeRegionId === 'west' ? null : 'west')}
                onMouseEnter={() => setHoveredRegion(REGIONS[0])}
                onMouseLeave={() => setHoveredRegion(null)}
              />

              {/* Region 2: Mountain & Desert */}
              <polygon 
                points="170,60 300,70 290,260 250,330 130,300 160,260 180,180" 
                className={`transition-all duration-300 stroke-1 cursor-pointer ${
                  activeRegionId === 'mountain' 
                    ? 'stroke-orange-400 fill-orange-500/20' 
                    : hoveredRegion?.id === 'mountain'
                      ? 'stroke-orange-500/70 fill-orange-500/10'
                      : 'stroke-orange-500/20 fill-orange-500/2'
                }`}
                onClick={() => setActiveRegionId(activeRegionId === 'mountain' ? null : 'mountain')}
                onMouseEnter={() => setHoveredRegion(REGIONS[1])}
                onMouseLeave={() => setHoveredRegion(null)}
              />

              {/* Region 3: Midwest metallurgy Hub */}
              <polygon 
                points="300,70 540,70 540,200 390,220 290,260" 
                className={`transition-all duration-300 stroke-1 cursor-pointer ${
                  activeRegionId === 'midwest' 
                    ? 'stroke-blue-400 fill-blue-500/20' 
                    : hoveredRegion?.id === 'midwest'
                      ? 'stroke-blue-500/70 fill-blue-500/10'
                      : 'stroke-blue-500/20 fill-blue-500/2'
                }`}
                onClick={() => setActiveRegionId(activeRegionId === 'midwest' ? null : 'midwest')}
                onMouseEnter={() => setHoveredRegion(REGIONS[2])}
                onMouseLeave={() => setHoveredRegion(null)}
              />

              {/* Region 4: Gulf & Southern Choppers */}
              <polygon 
                points="290,260 390,220 540,200 580,260 620,380 570,410 460,330 380,350 250,330" 
                className={`transition-all duration-300 stroke-1 cursor-pointer ${
                  activeRegionId === 'south' 
                    ? 'stroke-emerald-400 fill-emerald-500/20' 
                    : hoveredRegion?.id === 'south'
                      ? 'stroke-emerald-500/70 fill-emerald-500/10'
                      : 'stroke-emerald-500/20 fill-emerald-500/2'
                }`}
                onClick={() => setActiveRegionId(activeRegionId === 'south' ? null : 'south')}
                onMouseEnter={() => setHoveredRegion(REGIONS[3])}
                onMouseLeave={() => setHoveredRegion(null)}
              />

              {/* Region 5: Northeast Precision Corridor */}
              <polygon 
                points="540,70 690,70 710,120 630,220 540,200" 
                className={`transition-all duration-300 stroke-1 cursor-pointer ${
                  activeRegionId === 'northeast' 
                    ? 'stroke-purple-400 fill-purple-500/20' 
                    : hoveredRegion?.id === 'northeast'
                      ? 'stroke-purple-500/70 fill-purple-500/10'
                      : 'stroke-purple-500/20 fill-purple-500/2'
                }`}
                onClick={() => setActiveRegionId(activeRegionId === 'northeast' ? null : 'northeast')}
                onMouseEnter={() => setHoveredRegion(REGIONS[4])}
                onMouseLeave={() => setHoveredRegion(null)}
              />

              {/* Region 6: International Export Inset Circle */}
              <circle 
                cx="730" 
                cy="310" 
                r="45" 
                className={`transition-all duration-300 stroke-1 cursor-pointer ${
                  activeRegionId === 'international' 
                    ? 'stroke-slate-300 fill-slate-500/20' 
                    : hoveredRegion?.id === 'international'
                      ? 'stroke-slate-400 fill-slate-500/10'
                      : 'stroke-slate-500/20 fill-slate-500/2'
                }`}
                onClick={() => setActiveRegionId(activeRegionId === 'international' ? null : 'international')}
                onMouseEnter={() => setHoveredRegion(REGIONS[5])}
                onMouseLeave={() => setHoveredRegion(null)}
              />
            </g>

            {/* Grid Coordinates Reference Lines */}
            <g id="blueprint-decorations" className="stroke-slate-800 stroke-1" strokeDasharray="4 6">
              <line x1="180" y1="10" x2="180" y2="410" />
              <line x1="310" y1="10" x2="310" y2="410" />
              <line x1="530" y1="10" x2="530" y2="410" />
              <line x1="10" y1="200" x2="790" y2="200" />
            </g>

            {/* Region Label Insets */}
            <g id="region-tags" className="fill-slate-500 font-mono text-[9px] pointer-events-none select-none uppercase tracking-wider font-semibold">
              <text x="100" y="50">Zone 1 [PACIFIC]</text>
              <text x="200" y="270">Zone 2 [MOUNTAIN]</text>
              <text x="350" y="90">Zone 3 [MIDWEST]</text>
              <text x="400" y="300">Zone 4 [GULF & SOUTH]</text>
              <text x="590" y="90">Zone 5 [NORTHEAST]</text>
              <text x="690" y="375" textAnchor="middle">EXPORT [INTL]</text>
            </g>

            {/* Active Client Nodes */}
            <g id="client-nodes-layer">
              {clientNodes.map((node) => {
                const isSelected = selectedClientId === node.id;
                const isRegionActive = activeRegionId === node.regionId || activeRegionId === null;
                const isHovered = hoveredClient?.id === node.id;
                const region = REGIONS.find(r => r.id === node.regionId);

                // Nodes of inactive regions fade out slightly
                const opacityClass = isRegionActive ? 'opacity-100' : 'opacity-25';

                return (
                  <g 
                    key={node.id}
                    className={`cursor-pointer transition-all duration-300 ${opacityClass}`}
                    onClick={() => {
                      onSelectClient(node);
                      // Clear map filter when specific client clicked to allow view focus
                    }}
                    onMouseEnter={() => setHoveredClient(node)}
                    onMouseLeave={() => setHoveredClient(null)}
                  >
                    {/* Ripple/Glow Circle */}
                    <circle
                      cx={node.x}
                      cy={node.y}
                      r={isSelected || isHovered ? 16 : 8}
                      className={`fill-primary/20 stroke-primary/30 stroke-1 transition-all duration-300 ${
                        isSelected ? 'animate-pulse fill-primary/30' : ''
                      }`}
                    />

                    {/* Small outer pulsing circle */}
                    {(isSelected || isHovered) && (
                      <circle
                        cx={node.x}
                        cy={node.y}
                        r={24}
                        className="fill-none stroke-primary/20 stroke-1 animate-ping"
                      />
                    )}

                    {/* Core Solid Dot */}
                    <circle
                      cx={node.x}
                      cy={node.y}
                      r={isSelected || isHovered ? 6 : 4}
                      className={`transition-all duration-300 ${
                        node.regionId === 'west' 
                          ? 'fill-amber-400' 
                          : node.regionId === 'mountain'
                            ? 'fill-orange-400'
                            : node.regionId === 'midwest'
                              ? 'fill-blue-400'
                              : node.regionId === 'south'
                                ? 'fill-emerald-400'
                                : node.regionId === 'northeast'
                                  ? 'fill-purple-400'
                                  : 'fill-slate-300'
                      }`}
                    />

                    {/* Simple Label for Selected or Hovered Node */}
                    {(isSelected || isHovered) && (
                      <g className="pointer-events-none select-none">
                        {/* Label Background */}
                        <rect
                          x={node.x + 10}
                          y={node.y - 12}
                          width={node.name.length * 6 + 12}
                          height={18}
                          className="fill-slate-900/90 stroke-slate-700 stroke-1 rounded-sm"
                        />
                        <text
                          x={node.x + 16}
                          y={node.y}
                          className="fill-white font-mono text-[9px] font-bold"
                        >
                          {node.name.replace(/"/g, '')}
                        </text>
                      </g>
                    )}
                  </g>
                );
              })}
            </g>
          </svg>
        </div>

        {/* Region Statistics Panel */}
        <div className="lg:col-span-4 bg-surface-container-highest/30 border border-outline-variant p-4 flex flex-col justify-between rounded-xs">
          <div>
            <div className="flex items-center justify-between border-b border-outline-variant pb-2 mb-4">
              <span className="font-mono text-xs font-black tracking-widest text-slate-400 uppercase">
                {displayRegionInfo ? displayRegionInfo.name : 'All Territory Registry'}
              </span>
              <Layers size={14} className="text-slate-400" />
            </div>

            {displayRegionInfo && displayRegionStats ? (
              <div className="space-y-4">
                <div>
                  <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Jurisdiction States</span>
                  <span className="text-xs font-bold text-slate-200 mt-0.5 block">{displayRegionInfo.states}</span>
                </div>

                <div className="grid grid-cols-2 gap-3 pt-2">
                  <div className="bg-slate-900/40 border border-outline-variant/30 p-2.5 rounded-xs">
                    <span className="text-[9px] font-mono text-slate-400 uppercase">Active Clients</span>
                    <span className="text-lg font-narrow font-bold text-primary block mt-0.5">
                      {displayRegionStats.clientCount}
                    </span>
                  </div>
                  <div className="bg-slate-900/40 border border-outline-variant/30 p-2.5 rounded-xs">
                    <span className="text-[9px] font-mono text-slate-400 uppercase">Active Projects</span>
                    <span className="text-lg font-narrow font-bold text-amber-500 block mt-0.5">
                      {displayRegionStats.activeBuilds}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-slate-900/40 border border-outline-variant/30 p-2.5 rounded-xs">
                    <span className="text-[9px] font-mono text-slate-400 uppercase">Region Spend</span>
                    <span className="text-xs font-mono font-bold text-emerald-400 block mt-1">
                      ${displayRegionStats.totalSpend.toLocaleString('en-US', { maximumFractionDigits: 0 })}
                    </span>
                  </div>
                  <div className="bg-slate-900/40 border border-outline-variant/30 p-2.5 rounded-xs">
                    <span className="text-[9px] font-mono text-slate-400 uppercase">Outstanding Bal.</span>
                    <span className="text-xs font-mono font-bold text-red-400 block mt-1">
                      ${displayRegionStats.outstandingBal.toLocaleString('en-US', { maximumFractionDigits: 0 })}
                    </span>
                  </div>
                </div>

                {/* List of Clients in this active region */}
                <div className="pt-2">
                  <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block mb-2">Registered Accounts in Region</span>
                  <div className="space-y-1.5 max-h-[140px] overflow-y-auto custom-scrollbar pr-1">
                    {displayRegionStats.clients.map((c) => (
                      <button
                        key={c.id}
                        onClick={() => onSelectClient(c)}
                        className={`w-full text-left p-2 border flex items-center justify-between text-xs transition-all cursor-pointer ${
                          selectedClientId === c.id 
                            ? 'bg-primary/10 border-primary text-white font-semibold' 
                            : 'bg-slate-900/20 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-900/40'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span className="w-5 h-5 rounded-xs bg-primary/20 flex items-center justify-center text-[9px] font-bold text-primary font-mono">
                            {c.avatar}
                          </span>
                          <span className="truncate">{c.name}</span>
                        </div>
                        <span className="font-mono text-[10px] text-slate-500">{c.id}</span>
                      </button>
                    ))}
                    {displayRegionStats.clients.length === 0 && (
                      <p className="text-[11px] text-slate-500 italic py-2">No regional client accounts logged yet.</p>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              // All Territory Summary
              <div className="space-y-4">
                <div className="flex items-center gap-1 text-slate-300">
                  <TrendingUp size={14} className="text-primary" />
                  <span className="text-xs font-semibold">Total Territory Statistics</span>
                </div>

                <div className="space-y-2.5">
                  <div className="flex justify-between items-center text-xs border-b border-outline-variant/30 pb-1.5">
                    <span className="text-slate-400">Total Registered Clients:</span>
                    <span className="font-bold text-slate-200 font-mono">{clients.length} Accounts</span>
                  </div>
                  <div className="flex justify-between items-center text-xs border-b border-outline-variant/30 pb-1.5">
                    <span className="text-slate-400">Domestic Active Regions:</span>
                    <span className="font-bold text-slate-200 font-mono">5 Zones</span>
                  </div>
                  <div className="flex justify-between items-center text-xs border-b border-outline-variant/30 pb-1.5">
                    <span className="text-slate-400">International Hubs:</span>
                    <span className="font-bold text-slate-200 font-mono">1 Active</span>
                  </div>
                  <div className="flex justify-between items-center text-xs border-b border-outline-variant/30 pb-1.5">
                    <span className="text-slate-400">Outstanding Invoices:</span>
                    <span className="font-bold text-red-400 font-mono">
                      ${clients.reduce((acc, c) => acc + (c.outstandingBalance || 0), 0).toLocaleString('en-US', { maximumFractionDigits: 0 })}
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-400">Total Workshop Valuation:</span>
                    <span className="font-bold text-emerald-400 font-mono">
                      ${clients.reduce((acc, c) => acc + (c.lifetimeSpend || 0), 0).toLocaleString('en-US', { maximumFractionDigits: 0 })}
                    </span>
                  </div>
                </div>

                <div className="pt-2 text-[11px] text-slate-400 leading-relaxed bg-slate-950/40 p-3 border border-outline-variant/30 rounded-xs">
                  <p className="flex items-start gap-1.5">
                    <Wrench size={12} className="text-primary mt-0.5 flex-shrink-0" />
                    <span>
                      Interactive logistics view. Hover over regions or click legend elements to reveal zone statistics, outstanding balances, and localized client lists.
                    </span>
                  </p>
                </div>
              </div>
            )}
          </div>

          <div className="border-t border-outline-variant/60 pt-4 mt-6">
            {hoveredClient ? (
              <div className="p-2.5 bg-primary/10 border border-primary/30 rounded-xs flex flex-col justify-between">
                <div>
                  <p className="text-xs font-bold text-primary flex items-center gap-1.5">
                    <MapPin size={12} />
                    {hoveredClient.name}
                  </p>
                  <p className="text-[10px] font-mono text-slate-400 mt-1 uppercase">
                    {hoveredClient.company || 'Private Builder'}
                  </p>
                </div>
                <div className="flex justify-between items-center mt-2.5 border-t border-outline-variant/30 pt-1.5">
                  <span className="text-[10px] font-mono text-slate-400">Spend: <span className="text-emerald-400">${hoveredClient.lifetimeSpend?.toLocaleString()}</span></span>
                  <span className="text-[10px] font-mono text-slate-400">Bal: <span className="text-red-400">${hoveredClient.outstandingBalance?.toLocaleString()}</span></span>
                </div>
              </div>
            ) : (
              <div className="text-[10px] text-slate-500 font-mono text-center py-2 uppercase tracking-wider">
                Hover over client nodes to preview
              </div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};
