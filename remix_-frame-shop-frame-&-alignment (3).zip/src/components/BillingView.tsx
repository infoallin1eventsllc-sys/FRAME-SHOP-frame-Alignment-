/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { useAppState } from '../StateContext';
import { InvoiceStatus, Invoice } from '../types';
import { 
  Search, 
  Plus, 
  Download, 
  ChevronLeft, 
  ChevronRight, 
  Wallet, 
  AlertCircle, 
  CheckCircle, 
  Filter, 
  Calendar, 
  TrendingUp,
  X,
  Trash2,
  Eye,
  FileText,
  Printer,
  Calculator,
  Mail,
  FileSpreadsheet,
  CreditCard,
  Receipt
} from 'lucide-react';
import { MaterialCostCalculator } from './MaterialCostCalculator';
import { SendInvoiceEmailModal } from './SendInvoiceEmailModal';
import { ExcelConnectorModal } from './ExcelConnectorModal';
import { CardTransactionModal } from './CardTransactionModal';
import { CardTransactionsLedgerModal } from './CardTransactionsLedgerModal';

export const BillingView: React.FC = () => {
  const { invoices, clients, builds, addInvoice, deleteInvoice, globalSearchQuery, setGlobalSearchQuery } = useAppState();

  // Card Transaction Terminal & Ledger state
  const [isCardTerminalOpen, setIsCardTerminalOpen] = useState(false);
  const [isCardLedgerOpen, setIsCardLedgerOpen] = useState(false);
  const [terminalCustomerId, setTerminalCustomerId] = useState('');
  const [terminalInvoiceId, setTerminalInvoiceId] = useState('');
  const [terminalAmount, setTerminalAmount] = useState<number | undefined>(undefined);

  // Search & Filter state
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<InvoiceStatus | 'ALL'>('ALL');
  const [dateRangeFilter, setDateRangeFilter] = useState<'ALL' | 'OCTOBER' | 'NOVEMBER' | 'DECEMBER' | 'JANUARY'>('ALL');
  const [isFilterDropdownOpen, setIsFilterDropdownOpen] = useState(false);
  const [isDateDropdownOpen, setIsDateDropdownOpen] = useState(false);

  // Selected invoices for bulk operations
  const [selectedInvoiceIds, setSelectedInvoiceIds] = useState<string[]>([]);

  // Cost Estimator state
  const [isEstimatorOpen, setIsEstimatorOpen] = useState(false);

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  // New Invoice Modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [selectedProjectId, setSelectedProjectId] = useState('');
  const [invoiceAmount, setInvoiceAmount] = useState('');
  const [invoiceStatus, setInvoiceStatus] = useState<InvoiceStatus>('PENDING');

  // Preview Invoice Modal state
  const [selectedPreviewInvoice, setSelectedPreviewInvoice] = useState<Invoice | null>(null);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);

  // Email Invoice Modal state
  const [selectedEmailInvoice, setSelectedEmailInvoice] = useState<Invoice | null>(null);
  const [isEmailModalOpen, setIsEmailModalOpen] = useState(false);

  // Excel Spreadsheet Connector Modal state
  const [isExcelModalOpen, setIsExcelModalOpen] = useState(false);

  // Project Invoice Generator State
  const [isProjectPdfOpen, setIsProjectPdfOpen] = useState(false);
  const [selectedGeneratorProjectId, setSelectedGeneratorProjectId] = useState('');
  const [generatorAmountBasis, setGeneratorAmountBasis] = useState<'estimated' | 'actual' | 'custom'>('estimated');
  const [generatorCustomAmount, setGeneratorCustomAmount] = useState('');
  const [generatorInvoiceStatus, setGeneratorInvoiceStatus] = useState<InvoiceStatus>('PENDING');
  const [generatorInvoiceDate, setGeneratorInvoiceDate] = useState(() => {
    return new Date().toLocaleDateString('en-US', {
      month: 'short',
      day: '2-digit',
      year: 'numeric'
    });
  });
  const [generatorInvoiceTerms, setGeneratorInvoiceTerms] = useState('Net 30');
  const [generatorSuccessMessage, setGeneratorSuccessMessage] = useState('');

  const selectedProject = useMemo(() => {
    return builds.find(b => b.id === selectedGeneratorProjectId) || null;
  }, [builds, selectedGeneratorProjectId]);

  const selectedProjectClient = useMemo(() => {
    if (!selectedProject) return null;
    return clients.find(c => c.id === selectedProject.customerId) || null;
  }, [clients, selectedProject]);

  const computedInvoiceAmount = useMemo(() => {
    if (!selectedProject) return 0;
    if (generatorAmountBasis === 'estimated') {
      return selectedProject.estimatedCost;
    } else if (generatorAmountBasis === 'actual') {
      return selectedProject.actualCost || selectedProject.estimatedCost;
    } else {
      return parseFloat(generatorCustomAmount) || 0;
    }
  }, [selectedProject, generatorAmountBasis, generatorCustomAmount]);

  const computedEngineeringCost = computedInvoiceAmount * 0.15;
  const computedMaterialsCost = computedInvoiceAmount * 0.45;
  const computedMachiningCost = computedInvoiceAmount * 0.30;
  const computedQcCost = computedInvoiceAmount * 0.10;

  const transientInvoice = useMemo(() => {
    if (!selectedProject) return null;
    return {
      id: `TEMP-${selectedProject.id}`,
      date: generatorInvoiceDate,
      customerId: selectedProject.customerId,
      customerName: selectedProject.customerName,
      project: selectedProject.name,
      projectId: selectedProject.id,
      amount: computedInvoiceAmount,
      status: generatorInvoiceStatus
    } as Invoice;
  }, [selectedProject, generatorInvoiceDate, computedInvoiceAmount, generatorInvoiceStatus]);

  const handleSaveGeneratorInvoiceToLedger = () => {
    if (!transientInvoice || !selectedProject) return;
    
    addInvoice({
      date: transientInvoice.date,
      customerId: transientInvoice.customerId,
      customerName: transientInvoice.customerName,
      project: transientInvoice.project,
      projectId: transientInvoice.projectId,
      amount: transientInvoice.amount,
      status: transientInvoice.status
    });

    setGeneratorSuccessMessage('Invoice successfully logged in system ledger!');
    setTimeout(() => {
      setGeneratorSuccessMessage('');
      setIsProjectPdfOpen(false);
    }, 2000);
  };

  // Calculations for Bento Cards
  const stats = useMemo(() => {
    // Basic sums
    let totalBilled = 0;
    let outstanding = 0;
    let collectedRef = 0;
    let overdueCount = 0;

    invoices.forEach(inv => {
      // Calculate active aggregates
      if (inv.status === 'PAID') {
        collectedRef += inv.amount;
      } else {
        outstanding += inv.amount;
        if (inv.status === 'OVERDUE') {
          overdueCount++;
        }
      }
      totalBilled += inv.amount;
    });

    const collectionRate = totalBilled > 0 ? Math.round((collectedRef / totalBilled) * 100) : 0;

    return {
      totalBilled,
      outstanding,
      collectedRef,
      overdueCount,
      collectionRate
    };
  }, [invoices]);

  // Filtering Logic
  const filteredInvoices = useMemo(() => {
    const localQuery = searchTerm.toLowerCase().trim();
    const globalQuery = globalSearchQuery.toLowerCase().trim();
    return invoices.filter(inv => {
      // Local Search
      const matchesSearch = !localQuery ||
        inv.id.toLowerCase().includes(localQuery) ||
        inv.customerName.toLowerCase().includes(localQuery) ||
        inv.project.toLowerCase().includes(localQuery);

      // Global Search
      const matchesGlobal = !globalQuery ||
        inv.id.toLowerCase().includes(globalQuery) ||
        inv.customerName.toLowerCase().includes(globalQuery) ||
        inv.project.toLowerCase().includes(globalQuery);
      
      // Status
      const matchesStatus = statusFilter === 'ALL' || inv.status === statusFilter;

      // Simple Date filter
      let matchesDate = true;
      if (dateRangeFilter !== 'ALL') {
        matchesDate = inv.date.toUpperCase().includes(dateRangeFilter);
      }

      return matchesSearch && matchesGlobal && matchesStatus && matchesDate;
    });
  }, [invoices, searchTerm, globalSearchQuery, statusFilter, dateRangeFilter]);

  // Pagination Logic
  const totalPages = Math.ceil(filteredInvoices.length / itemsPerPage) || 1;
  const paginatedInvoices = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredInvoices.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredInvoices, currentPage]);

  const handlePageChange = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  // Create Invoice Submission
  const handleAddNewInvoice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCustomerId || !selectedProjectId || !invoiceAmount) return;

    const chosenClient = clients.find(c => c.id === selectedCustomerId);
    const chosenBuild = builds.find(b => b.id === selectedProjectId);

    if (chosenClient && chosenBuild) {
      addInvoice({
        date: new Date().toLocaleDateString('en-US', {
          month: 'short',
          day: '2-digit',
          year: 'numeric'
        }),
        customerId: chosenClient.id,
        customerName: chosenClient.name,
        project: chosenBuild.name,
        projectId: chosenBuild.id,
        amount: parseFloat(invoiceAmount),
        status: invoiceStatus
      });

      // Reset Form and Close
      setSelectedCustomerId('');
      setSelectedProjectId('');
      setInvoiceAmount('');
      setInvoiceStatus('PENDING');
      setIsModalOpen(false);
      setCurrentPage(1); // Reset to first page to see new one
    }
  };

  // Export CSV Helper (Optimized for robust Microsoft Excel compatibility)
  const handleExportCSV = () => {
    const headers = ['Invoice ID', 'Date', 'Customer Name', 'Project', 'Amount', 'Status'];
    const rows = invoices.map(inv => [
      inv.id,
      inv.date,
      (inv.customerName || '').replace(/"/g, '""'),
      (inv.project || '').replace(/"/g, '""'),
      inv.amount.toFixed(2),
      inv.status
    ]);

    const csvString = [
      headers.join(','),
      ...rows.map(e => e.map(val => `"${val}"`).join(','))
    ].join('\r\n');

    // Prepend UTF-8 BOM so Excel opens special characters correctly instantly
    const bom = new Uint8Array([0xEF, 0xBB, 0xBF]);
    const blob = new Blob([bom, csvString], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `Frame_Shop_Ledger_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handlePreviewInvoice = (inv: Invoice) => {
    setSelectedPreviewInvoice(inv);
    setIsPreviewOpen(true);
  };

  const handleDownloadPDF = (inv: Invoice) => {
    const clientDetails = clients.find(c => c.id === inv.customerId);
    const buildDetails = builds.find(b => b.id === inv.projectId);
    
    const issueDate = inv.date;
    let dueDate = 'Net 30';
    try {
      const d = new Date(inv.date);
      if (!isNaN(d.getTime())) {
        d.setDate(d.getDate() + 30);
        dueDate = d.toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
      }
    } catch (e) {}

    const engineeringCost = inv.amount * 0.15;
    const materialsCost = inv.amount * 0.45;
    const machiningCost = inv.amount * 0.30;
    const qcCost = inv.amount * 0.10;

    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('Please allow popups to download the invoice PDF.');
      return;
    }

    const printContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Invoice ${inv.id}</title>
        <style>
          body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            color: #1e293b;
            margin: 0;
            padding: 40px;
            background-color: #ffffff;
          }
          .invoice-container {
            max-width: 800px;
            margin: 0 auto;
            border: 1px solid #e2e8f0;
            padding: 40px;
            border-radius: 4px;
          }
          .header-row {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            border-bottom: 2px solid #0f172a;
            padding-bottom: 20px;
            margin-bottom: 30px;
          }
          .company-title {
            font-size: 20px;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: #0f172a;
          }
          .invoice-title {
            font-size: 28px;
            font-weight: 900;
            text-align: right;
            color: #f97316;
            margin: 0 0 5px 0;
          }
          .meta-text {
            font-size: 11px;
            color: #64748b;
            text-align: right;
            margin: 2px 0;
          }
          .details-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
            margin-bottom: 40px;
          }
          .details-col h4 {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.1em;
            color: #64748b;
            margin: 0 0 8px 0;
            border-bottom: 1px solid #cbd5e1;
            padding-bottom: 4px;
          }
          .details-col p {
            font-size: 13px;
            margin: 4px 0;
            line-height: 1.4;
          }
          .project-badge {
            background-color: #f1f5f9;
            padding: 12px;
            border-left: 4px solid #f97316;
            margin-bottom: 30px;
          }
          .project-badge h5 {
            margin: 0 0 4px 0;
            font-size: 11px;
            text-transform: uppercase;
            color: #475569;
          }
          .project-badge p {
            margin: 0;
            font-size: 14px;
            font-weight: 600;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
          }
          th {
            background-color: #0f172a;
            color: #ffffff;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            padding: 10px;
            text-align: left;
          }
          td {
            padding: 12px 10px;
            font-size: 13px;
            border-bottom: 1px solid #e2e8f0;
          }
          .text-right {
            text-align: right;
          }
          .totals-row {
            display: flex;
            justify-content: flex-end;
            margin-top: 20px;
          }
          .totals-box {
            width: 250px;
            margin-left: auto;
          }
          .totals-line {
            display: flex;
            justify-content: space-between;
            padding: 6px 0;
            font-size: 13px;
          }
          .grand-total {
            border-top: 2px solid #0f172a;
            font-size: 18px;
            font-weight: 800;
            padding-top: 10px;
            color: #0f172a;
          }
          .status-stamp {
            border: 3px solid;
            padding: 6px 12px;
            font-size: 14px;
            font-weight: 800;
            text-transform: uppercase;
            display: inline-block;
            margin-top: 15px;
            transform: rotate(-3deg);
            border-radius: 4px;
          }
          .status-paid {
            color: #16a34a;
            border-color: #16a34a;
            background-color: #f0fdf4;
          }
          .status-pending {
            color: #d97706;
            border-color: #d97706;
            background-color: #fffbeb;
          }
          .status-overdue {
            color: #dc2626;
            border-color: #dc2626;
            background-color: #fef2f2;
          }
          .status-parts {
            color: #4b5563;
            border-color: #4b5563;
            background-color: #f9fafb;
          }
          .footer-note {
            margin-top: 50px;
            text-align: center;
            font-size: 11px;
            color: #94a3b8;
            border-top: 1px solid #e2e8f0;
            padding-top: 20px;
          }
          @media print {
            body {
              padding: 0;
            }
            .invoice-container {
              border: none;
              padding: 0;
            }
          }
        </style>
      </head>
      <body>
        <div class="invoice-container">
          <div class="header-row">
            <div>
              <div class="company-title">HEAVY DUTY FABRICATION</div>
              <p style="font-size: 12px; color: #475569; margin: 4px 0 0 0;">Industrial Custom Assembly & Frame Shop</p>
            </div>
            <div>
              <h1 class="invoice-title">INVOICE</h1>
              <div class="meta-text"><strong>Invoice ID:</strong> ${inv.id}</div>
              <div class="meta-text"><strong>Issue Date:</strong> ${issueDate}</div>
              <div class="meta-text"><strong>Due Date:</strong> ${dueDate} (Net 30)</div>
            </div>
          </div>

          <div class="details-grid">
            <div class="details-col">
              <h4>Billed By</h4>
              <p><strong>Heavy Duty Fabrication Co.</strong></p>
              <p>1024 Industrial Parkway, Suite B</p>
              <p>Detroit, MI 48201</p>
              <p>billing@heavydutyfab.com</p>
              <p>+1 (313) 555-0190</p>
            </div>
            <div class="details-col">
              <h4>Billed To</h4>
              <p><strong>${clientDetails?.name || inv.customerName}</strong></p>
              <p>${clientDetails?.company || 'Private Client'}</p>
              <p>${clientDetails?.email || 'N/A'}</p>
              <p>${clientDetails?.phone || 'N/A'}</p>
            </div>
          </div>

          <div class="project-badge">
            <h5>Referenced Project Pipeline</h5>
            <p>[${inv.projectId}] ${inv.project} (${buildDetails?.type || 'Custom Fabrication'})</p>
          </div>

          <table>
            <thead>
              <tr>
                <th style="width: 5%">#</th>
                <th style="width: 55%">Description of Materials & Services</th>
                <th style="width: 10%" class="text-right">Qty</th>
                <th style="width: 15%" class="text-right">Rate</th>
                <th style="width: 15%" class="text-right">Total</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>1</td>
                <td><strong>Structural Engineering & CAD Drafting</strong><br><span style="font-size: 11px; color: #64748b;">Design review, stress-simulation modeling & Blueprint validation</span></td>
                <td class="text-right">1</td>
                <td class="text-right">$${engineeringCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                <td class="text-right">$${engineeringCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
              </tr>
              <tr>
                <td>2</td>
                <td><strong>Heavy Steel & Raw Component Sourcing</strong><br><span style="font-size: 11px; color: #64748b;">Spec-grade structural metals, fasteners, custom laser plates</span></td>
                <td class="text-right">1</td>
                <td class="text-right">$${materialsCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                <td class="text-right">$${materialsCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
              </tr>
              <tr>
                <td>3</td>
                <td><strong>Precision Machining, Welding & Bench Assembly</strong><br><span style="font-size: 11px; color: #64748b;">MIG/TIG welding, manual fitting, sandblasting & primer coat</span></td>
                <td class="text-right">1</td>
                <td class="text-right">$${machiningCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                <td class="text-right">$${machiningCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
              </tr>
              <tr>
                <td>4</td>
                <td><strong>Quality Control, Dial Calibration & Testing</strong><br><span style="font-size: 11px; color: #64748b;">Deflection checks, weld integrity scan & micro-tolerance logs</span></td>
                <td class="text-right">1</td>
                <td class="text-right">$${qcCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                <td class="text-right">$${qcCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
              </tr>
            </tbody>
          </table>

          <div style="display: flex; justify-content: space-between; align-items: flex-start;">
            <div>
              <div class="status-stamp ${
                inv.status === 'PAID' ? 'status-paid' :
                inv.status === 'PENDING' ? 'status-pending' :
                inv.status === 'OVERDUE' ? 'status-overdue' : 'status-parts'
              }">
                ${inv.status === 'PARTS WAIT' ? 'BLOCKED' : inv.status}
              </div>
            </div>
            <div class="totals-box">
              <div class="totals-line">
                <span>Subtotal:</span>
                <span>$${inv.amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
              <div class="totals-line">
                <span>Tax (0%):</span>
                <span>$0.00</span>
              </div>
              <div class="totals-line grand-total">
                <span>Grand Total:</span>
                <span>$${inv.amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
            </div>
          </div>

          <div class="footer-note">
            <p>Thank you for your business. Terms: Net 30 days from date of issue.</p>
            <p>Heavy Duty Fabrication & Assembly Co. | Detroit Hub</p>
          </div>
        </div>
        <script>
          window.onload = function() {
            window.print();
          };
        </script>
      </body>
      </html>
    `;

    printWindow.document.open();
    printWindow.document.write(printContent);
    printWindow.document.close();
  };

  const printInvoices = (invList: Invoice[]) => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('Please allow popups to print invoices.');
      return;
    }

    const pagesHtml = invList.map((inv) => {
      const clientDetails = clients.find(c => c.id === inv.customerId);
      const buildDetails = builds.find(b => b.id === inv.projectId);
      
      const issueDate = inv.date;
      let dueDate = 'Net 30';
      try {
        const d = new Date(inv.date);
        if (!isNaN(d.getTime())) {
          d.setDate(d.getDate() + 30);
          dueDate = d.toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
        }
      } catch (e) {}

      const engineeringCost = inv.amount * 0.15;
      const materialsCost = inv.amount * 0.45;
      const machiningCost = inv.amount * 0.30;
      const qcCost = inv.amount * 0.10;

      return `
        <div class="print-page">
          <div class="header-row">
            <div>
              <div class="company-title">HEAVY DUTY FABRICATION</div>
              <p class="company-subtitle">Industrial Custom Assembly & Frame Shop</p>
              <p class="company-address">1024 Industrial Parkway, Detroit, MI 48201</p>
            </div>
            <div class="invoice-meta">
              <h1 class="invoice-title">INVOICE</h1>
              <div class="meta-item"><strong>Invoice ID:</strong> \${inv.id}</div>
              <div class="meta-item"><strong>Issue Date:</strong> \${issueDate}</div>
              <div class="meta-item"><strong>Due Date:</strong> \${dueDate}</div>
            </div>
          </div>

          <div class="details-grid">
            <div class="details-col">
              <h4>Billed By</h4>
              <p><strong>Heavy Duty Fabrication Co.</strong></p>
              <p>1024 Industrial Parkway, Suite B</p>
              <p>Detroit, MI 48201</p>
              <p>billing@heavydutyfab.com</p>
              <p>+1 (313) 555-0190</p>
            </div>
            <div class="details-col">
              <h4>Billed To</h4>
              <p><strong>\${clientDetails?.name || inv.customerName}</strong></p>
              <p>\${clientDetails?.company || 'Private Client'}</p>
              <p>\${clientDetails?.email || 'N/A'}</p>
              <p>\${clientDetails?.phone || 'N/A'}</p>
            </div>
          </div>

          <div class="project-badge">
            <h5>Referenced Project Pipeline</h5>
            <p><strong>[\${inv.projectId}] \${inv.project}</strong> (\${buildDetails?.type || 'Custom Fabrication'})</p>
          </div>

          <table>
            <thead>
              <tr>
                <th style="width: 5%">#</th>
                <th style="width: 55%">Description of Materials & Services</th>
                <th style="width: 10%" class="text-right">Qty</th>
                <th style="width: 15%" class="text-right">Rate</th>
                <th style="width: 15%" class="text-right">Total</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td class="text-center">1</td>
                <td>
                  <strong>Structural Engineering & CAD Drafting</strong><br>
                  <span class="sub-text">Design review, stress-simulation modeling & Blueprint validation</span>
                </td>
                <td class="text-center">1</td>
                <td class="text-right">\$\${engineeringCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                <td class="text-right">\$\${engineeringCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
              </tr>
              <tr>
                <td class="text-center">2</td>
                <td>
                  <strong>Heavy Steel & Raw Component Sourcing</strong><br>
                  <span class="sub-text">Spec-grade structural metals, fasteners, custom laser plates</span>
                </td>
                <td class="text-center">1</td>
                <td class="text-right">\$\${materialsCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                <td class="text-right">\$\${materialsCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
              </tr>
              <tr>
                <td class="text-center">3</td>
                <td>
                  <strong>Precision Machining, Welding & Bench Assembly</strong><br>
                  <span class="sub-text">MIG/TIG welding, manual fitting, sandblasting & primer coat</span>
                </td>
                <td class="text-center">1</td>
                <td class="text-right">\$\${machiningCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                <td class="text-right">\$\${machiningCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
              </tr>
              <tr>
                <td class="text-center">4</td>
                <td>
                  <strong>Quality Control, Dial Calibration & Testing</strong><br>
                  <span class="sub-text">Deflection checks, weld integrity scan & micro-tolerance logs</span>
                </td>
                <td class="text-center">1</td>
                <td class="text-right">\$\${qcCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                <td class="text-right">\$\${qcCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
              </tr>
            </tbody>
          </table>

          <div class="footer-row">
            <div class="status-box">
              <span class="status-stamp stamp-\${inv.status.toLowerCase().replace(' ', '-')}">
                \${inv.status === 'PARTS WAIT' ? 'BLOCKED' : inv.status}
              </span>
            </div>
            <div class="totals-box">
              <div class="totals-line">
                <span>Subtotal:</span>
                <span>\$\${inv.amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
              <div class="totals-line">
                <span>Tax (0%):</span>
                <span>$0.00</span>
              </div>
              <div class="totals-line grand-total">
                <span>Grand Total:</span>
                <span>\$\${inv.amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
            </div>
          </div>

          <div class="footer-note">
            <p>Thank you for your business. Terms: Net 30 days from date of issue.</p>
            <p>Heavy Duty Fabrication & Assembly Co. | Detroit Hub</p>
          </div>
        </div>
      `;
    }).join('\n');

    const printContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Print Invoices</title>
        <style>
          @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
          
          body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            color: #0f172a;
            margin: 0;
            padding: 0;
            background-color: #ffffff;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }
          
          .print-page {
            max-width: 850px;
            margin: 40px auto;
            padding: 40px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            background: #ffffff;
            position: relative;
            box-sizing: border-box;
          }
          
          .header-row {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            border-bottom: 2px solid #0f172a;
            padding-bottom: 24px;
            margin-bottom: 30px;
          }
          
          .company-title {
            font-size: 24px;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: #0f172a;
          }
          
          .company-subtitle {
            font-size: 12px;
            color: #475569;
            margin: 4px 0 0 0;
            font-weight: 500;
          }

          .company-address {
            font-size: 11px;
            color: #64748b;
            margin: 4px 0 0 0;
          }
          
          .invoice-title {
            font-size: 32px;
            font-weight: 900;
            text-align: right;
            color: #f97316;
            margin: 0 0 8px 0;
            letter-spacing: -0.02em;
          }
          
          .invoice-meta {
            text-align: right;
          }

          .meta-item {
            font-size: 12px;
            color: #334155;
            margin: 3px 0;
          }
          
          .details-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
            margin-bottom: 35px;
          }
          
          .details-col h4 {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.1em;
            color: #64748b;
            margin: 0 0 10px 0;
            border-bottom: 1px solid #cbd5e1;
            padding-bottom: 6px;
            font-weight: 700;
          }
          
          .details-col p {
            font-size: 13px;
            margin: 4px 0;
            line-height: 1.5;
            color: #1e293b;
          }
          
          .project-badge {
            background-color: #f8fafc;
            padding: 16px;
            border-left: 4px solid #f97316;
            margin-bottom: 35px;
            border-radius: 0 4px 4px 0;
          }
          
          .project-badge h5 {
            margin: 0 0 4px 0;
            font-size: 10px;
            text-transform: uppercase;
            color: #64748b;
            letter-spacing: 0.05em;
            font-weight: 700;
          }
          
          .project-badge p {
            margin: 0;
            font-size: 14px;
            color: #0f172a;
          }
          
          table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 35px;
          }
          
          th {
            background-color: #0f172a;
            color: #ffffff;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            padding: 12px;
            text-align: left;
            font-weight: 600;
          }
          
          td {
            padding: 14px 12px;
            font-size: 13px;
            border-bottom: 1px solid #e2e8f0;
            color: #334155;
            vertical-align: top;
          }

          .sub-text {
            font-size: 11px;
            color: #64748b;
            display: inline-block;
            margin-top: 3px;
          }
          
          .text-right {
            text-align: right;
          }

          .text-center {
            text-align: center;
          }
          
          .footer-row {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-top: 25px;
          }
          
          .totals-box {
            width: 280px;
          }
          
          .totals-line {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            font-size: 13px;
            color: #475569;
          }
          
          .grand-total {
            border-top: 2px solid #0f172a;
            font-size: 18px;
            font-weight: 800;
            padding-top: 12px;
            color: #0f172a;
          }
          
          .status-box {
            display: flex;
            align-items: center;
          }

          .status-stamp {
            border: 3px solid;
            padding: 8px 16px;
            font-size: 14px;
            font-weight: 900;
            text-transform: uppercase;
            display: inline-block;
            transform: rotate(-3deg);
            border-radius: 6px;
            letter-spacing: 0.05em;
          }
          
          .stamp-paid {
            color: #16a34a;
            border-color: #16a34a;
            background-color: #f0fdf4;
          }
          
          .stamp-pending {
            color: #d97706;
            border-color: #d97706;
            background-color: #fffbeb;
          }
          
          .stamp-overdue {
            color: #dc2626;
            border-color: #dc2626;
            background-color: #fef2f2;
          }
          
          .stamp-parts-wait, .stamp-parts_wait {
            color: #4b5563;
            border-color: #4b5563;
            background-color: #f9fafb;
          }
          
          .footer-note {
            margin-top: 60px;
            text-align: center;
            font-size: 11px;
            color: #94a3b8;
            border-top: 1px solid #e2e8f0;
            padding-top: 24px;
          }
          
          @media print {
            body {
              background-color: #ffffff;
              color: #000000;
              padding: 0;
              margin: 0;
            }
            .print-page {
              max-width: 100%;
              border: none;
              border-radius: 0;
              margin: 0;
              padding: 15mm;
              page-break-after: always;
              page-break-inside: avoid;
            }
            .print-page:last-child {
              page-break-after: avoid;
            }
          }
        </style>
      </head>
      <body>
        ${pagesHtml}
        <script>
          window.onload = function() {
            setTimeout(function() {
              window.print();
            }, 300);
          };
        </script>
      </body>
      </html>
    `;

    printWindow.document.open();
    printWindow.document.write(printContent);
    printWindow.document.close();
  };

  return (
    <div className="relative z-10 font-sans">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 mb-12">
        <div>
          <h2 className="text-4xl md:text-5xl font-bold uppercase tracking-tight text-on-surface font-narrow">
            Financial Overview
          </h2>
          <p className="text-base text-on-surface-variant font-medium mt-1">
            Real-time ledger for fabrication operations
          </p>
        </div>
        <div className="flex flex-wrap gap-3 w-full md:w-auto">
          <button 
            id="btn-card-terminal"
            onClick={() => {
              setTerminalCustomerId('');
              setTerminalInvoiceId('');
              setTerminalAmount(undefined);
              setIsCardTerminalOpen(true);
            }}
            className="flex-1 md:flex-none bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-6 py-3 text-xs tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-all cursor-pointer rounded-sm shadow-md"
          >
            <CreditCard size={16} />
            CARD TERMINAL
          </button>

          <button 
            id="btn-card-ledger"
            onClick={() => setIsCardLedgerOpen(true)}
            className="flex-1 md:flex-none bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/40 px-6 py-3 font-semibold text-xs tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-all cursor-pointer rounded-sm"
          >
            <Receipt size={16} />
            CARD TRANSACTIONS
          </button>

          <button 
            id="btn-cost-estimator"
            onClick={() => setIsEstimatorOpen(true)}
            className="flex-1 md:flex-none bg-orange-500/10 hover:bg-orange-500/20 text-orange-400 border border-orange-500/30 px-6 py-3 font-semibold text-xs tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-all cursor-pointer rounded-sm"
          >
            <Calculator size={16} />
            COST ESTIMATOR
          </button>
          <button 
            id="btn-project-invoice-pdf"
            onClick={() => {
              setIsProjectPdfOpen(true);
              if (builds.length > 0 && !selectedGeneratorProjectId) {
                setSelectedGeneratorProjectId(builds[0].id);
              }
            }}
            className="flex-1 md:flex-none bg-primary/10 hover:bg-primary/20 text-primary border border-primary/30 px-6 py-3 font-semibold text-xs tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-all cursor-pointer rounded-sm"
          >
            <Printer size={16} />
            PROJECT PDF PREVIEW
          </button>
          <button 
            id="btn-new-invoice"
            onClick={() => setIsModalOpen(true)}
            className="flex-1 md:flex-none bg-primary-container hover:bg-orange-600 text-on-background px-6 py-3 font-semibold text-xs tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-all cursor-pointer rounded-sm"
          >
            <Plus size={16} />
            NEW INVOICE
          </button>
          <button 
            id="btn-excel-connector-hub"
            onClick={() => setIsExcelModalOpen(true)}
            className="flex-1 md:flex-none bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-6 py-3 font-semibold text-xs tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-all cursor-pointer rounded-sm"
          >
            <FileSpreadsheet size={16} />
            EXCEL SPREADSHEETS
          </button>
          <button 
            id="btn-export-csv"
            onClick={handleExportCSV}
            className="flex-1 md:flex-none border-2 border-outline-variant hover:bg-surface-container-highest text-on-surface px-6 py-3 font-semibold text-xs tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer rounded-sm"
          >
            <Download size={16} />
            EXPORT CSV
          </button>
        </div>
      </div>

      {/* Bento Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        {/* Card 1: Total Billed */}
        <div className="bg-surface-container border border-outline-variant p-6 relative overflow-hidden group">
          <div className="metal-grain absolute inset-0"></div>
          <div className="relative z-10">
            <div className="flex justify-between items-start mb-4">
              <span className="text-xs font-mono tracking-wider text-on-surface-variant uppercase">
                TOTAL BILLED (MTD)
              </span>
              <Wallet className="text-primary-container" size={20} />
            </div>
            <p className="text-4xl md:text-5xl font-bold tracking-tight text-on-surface font-narrow breathing-glow">
              ${stats.totalBilled.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
            <div className="mt-4 flex items-center gap-1.5 text-primary">
              <TrendingUp size={14} />
              <span className="text-xs font-mono tracking-wider uppercase">
                +12.4% FROM LAST MONTH
              </span>
            </div>
          </div>
        </div>

        {/* Card 2: Outstanding Balance */}
        <div className="bg-surface-container border border-outline-variant p-6 relative overflow-hidden group">
          <div className="metal-grain absolute inset-0"></div>
          <div className="relative z-10">
            <div className="flex justify-between items-start mb-4">
              <span className="text-xs font-mono tracking-wider text-on-surface-variant uppercase">
                OUTSTANDING BAL.
              </span>
              <AlertCircle className="text-amber-500" size={20} />
            </div>
            <p className="text-4xl md:text-5xl font-bold tracking-tight text-on-surface font-narrow breathing-glow">
              ${stats.outstanding.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
            <div className="mt-4 flex items-center gap-1.5 text-error">
              <AlertCircle size={14} className="animate-bounce" />
              <span className="text-xs font-mono tracking-wider uppercase">
                {stats.overdueCount} OVERDUE INVOICES
              </span>
            </div>
          </div>
        </div>

        {/* Card 3: Collected Revenue */}
        <div className="bg-surface-container border border-outline-variant p-6 relative overflow-hidden group">
          <div className="metal-grain absolute inset-0"></div>
          <div className="relative z-10">
            <div className="flex justify-between items-start mb-4">
              <span className="text-xs font-mono tracking-wider text-on-surface-variant uppercase">
                COLLECTED REVENUE
              </span>
              <CheckCircle className="text-emerald-500" size={20} />
            </div>
            <p className="text-4xl md:text-5xl font-bold tracking-tight text-on-surface font-narrow">
              ${stats.collectedRef.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
            <div className="mt-5 h-2 bg-surface-container-highest rounded-full overflow-hidden">
              <div 
                className="h-full bg-primary-container transition-all duration-500" 
                style={{ width: `${stats.collectionRate}%` }}
              ></div>
            </div>
            <p className="mt-2 text-xs font-mono tracking-wider text-on-surface-variant uppercase">
              {stats.collectionRate}% COLLECTION RATE
            </p>
          </div>
        </div>
      </div>

      {/* Table Controls */}
      <div className="bg-surface-container border border-outline-variant p-4 mb-2 flex flex-col md:flex-row gap-4 items-center justify-between">
        {/* Search */}
        <div className="relative w-full md:w-96">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant" size={18} />
          <input 
            type="text"
            className="w-full bg-background border-none focus:outline-none focus:ring-1 focus:ring-primary-container text-on-surface pl-12 pr-4 py-2.5 text-sm"
            placeholder="Search by customer, invoice ID, project..."
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setCurrentPage(1);
            }}
          />
        </div>

        {/* Filters */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-end">
          {/* Status Filter */}
          <div className="relative">
            <button 
              id="filter-status-select"
              onClick={() => {
                setIsFilterDropdownOpen(!isFilterDropdownOpen);
                setIsDateDropdownOpen(false);
              }}
              className="flex items-center gap-2 bg-background px-4 py-2.5 border border-outline-variant cursor-pointer hover:border-primary-container transition-colors text-xs font-bold tracking-wider uppercase text-on-background"
            >
              <Filter size={14} />
              STATUS: {statusFilter}
            </button>
            {isFilterDropdownOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-surface-container border border-outline-variant z-20 shadow-xl rounded-sm">
                <button 
                  onClick={() => { setStatusFilter('ALL'); setCurrentPage(1); setIsFilterDropdownOpen(false); }}
                  className="w-full text-left px-4 py-2.5 text-xs font-semibold hover:bg-surface-container-highest transition-colors text-on-surface block"
                >
                  ALL STATUSES
                </button>
                <button 
                  onClick={() => { setStatusFilter('PAID'); setCurrentPage(1); setIsFilterDropdownOpen(false); }}
                  className="w-full text-left px-4 py-2.5 text-xs font-semibold hover:bg-surface-container-highest transition-colors text-emerald-400 block"
                >
                  PAID
                </button>
                <button 
                  onClick={() => { setStatusFilter('PENDING'); setCurrentPage(1); setIsFilterDropdownOpen(false); }}
                  className="w-full text-left px-4 py-2.5 text-xs font-semibold hover:bg-surface-container-highest transition-colors text-orange-400 block"
                >
                  PENDING
                </button>
                <button 
                  onClick={() => { setStatusFilter('OVERDUE'); setCurrentPage(1); setIsFilterDropdownOpen(false); }}
                  className="w-full text-left px-4 py-2.5 text-xs font-semibold hover:bg-surface-container-highest transition-colors text-rose-400 block"
                >
                  OVERDUE
                </button>
                <button 
                  onClick={() => { setStatusFilter('PARTS WAIT'); setCurrentPage(1); setIsFilterDropdownOpen(false); }}
                  className="w-full text-left px-4 py-2.5 text-xs font-semibold hover:bg-surface-container-highest transition-colors text-on-surface-variant block"
                >
                  PARTS WAIT
                </button>
              </div>
            )}
          </div>

          {/* Date Filter */}
          <div className="relative">
            <button 
              id="filter-date-select"
              onClick={() => {
                setIsDateDropdownOpen(!isDateDropdownOpen);
                setIsFilterDropdownOpen(false);
              }}
              className="flex items-center gap-2 bg-background px-4 py-2.5 border border-outline-variant cursor-pointer hover:border-primary-container transition-colors text-xs font-bold tracking-wider uppercase text-on-background"
            >
              <Calendar size={14} />
              DATE: {dateRangeFilter === 'ALL' ? 'ALL TIME' : dateRangeFilter}
            </button>
            {isDateDropdownOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-surface-container border border-outline-variant z-20 shadow-xl rounded-sm">
                <button 
                  onClick={() => { setDateRangeFilter('ALL'); setCurrentPage(1); setIsDateDropdownOpen(false); }}
                  className="w-full text-left px-4 py-2.5 text-xs font-semibold hover:bg-surface-container-highest transition-colors text-on-surface block"
                >
                  ALL TIME
                </button>
                <button 
                  onClick={() => { setDateRangeFilter('OCTOBER'); setCurrentPage(1); setIsDateDropdownOpen(false); }}
                  className="w-full text-left px-4 py-2.5 text-xs font-semibold hover:bg-surface-container-highest transition-colors text-on-surface block"
                >
                  OCTOBER 2023
                </button>
                <button 
                  onClick={() => { setDateRangeFilter('NOVEMBER'); setCurrentPage(1); setIsDateDropdownOpen(false); }}
                  className="w-full text-left px-4 py-2.5 text-xs font-semibold hover:bg-surface-container-highest transition-colors text-on-surface block"
                >
                  NOVEMBER 2023
                </button>
                <button 
                  onClick={() => { setDateRangeFilter('DECEMBER'); setCurrentPage(1); setIsDateDropdownOpen(false); }}
                  className="w-full text-left px-4 py-2.5 text-xs font-semibold hover:bg-surface-container-highest transition-colors text-on-surface block"
                >
                  DECEMBER 2023
                </button>
                <button 
                  onClick={() => { setDateRangeFilter('JANUAR'); setCurrentPage(1); setIsDateDropdownOpen(false); }}
                  className="w-full text-left px-4 py-2.5 text-xs font-semibold hover:bg-surface-container-highest transition-colors text-on-surface block"
                >
                  JANUARY 2024
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {globalSearchQuery && (
        <div className="mb-4 px-4 py-2.5 bg-primary/10 border border-primary/20 text-primary rounded-sm flex items-center justify-between text-xs font-mono">
          <span className="truncate">Top Filter: "{globalSearchQuery}"</span>
          <button 
            onClick={() => setGlobalSearchQuery('')}
            className="text-red-400 hover:text-red-300 font-bold uppercase tracking-wider ml-2 cursor-pointer transition-colors"
          >
            Clear Filter
          </button>
        </div>
      )}

      {/* Bulk Print Action Banner */}
      {selectedInvoiceIds.length > 0 && (
        <div className="mb-4 p-4 bg-orange-500/10 border border-orange-500/20 rounded-sm flex flex-col sm:flex-row justify-between items-center gap-4 relative z-10 animate-fade-in">
          <div className="flex items-center gap-3">
            <Printer size={18} className="text-orange-400" />
            <div>
              <span className="text-xs font-mono uppercase font-bold tracking-wider text-orange-400 block sm:inline mr-2">Bulk Print Selected</span>
              <span className="text-xs text-on-surface-variant font-medium">Selected <strong className="text-on-surface font-mono">{selectedInvoiceIds.length}</strong> {selectedInvoiceIds.length === 1 ? 'invoice' : 'invoices'} for batch printing.</span>
            </div>
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={() => {
                const selectedInvs = invoices.filter(inv => selectedInvoiceIds.includes(inv.id));
                printInvoices(selectedInvs);
              }}
              className="w-full sm:w-auto flex items-center justify-center gap-2 bg-orange-500/20 hover:bg-orange-500/30 text-orange-300 border border-orange-500/30 px-4 py-2 text-xs font-mono font-bold uppercase tracking-wider rounded-sm transition-all cursor-pointer"
            >
              <Printer size={14} />
              Print Batch ({selectedInvoiceIds.length})
            </button>
            <button
              onClick={() => setSelectedInvoiceIds([])}
              className="w-full sm:w-auto flex items-center justify-center gap-1 bg-surface-container-highest hover:bg-surface-container-highest/80 text-on-surface-variant px-4 py-2 text-xs font-mono font-bold uppercase tracking-wider rounded-sm transition-all cursor-pointer border border-outline-variant"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Transaction Table */}
      <div className="border border-outline-variant overflow-x-auto custom-scrollbar bg-surface-container">
        <table className="w-full border-collapse min-w-[900px] text-left">
          <thead className="bg-[#2a2a2b] border-b border-outline-variant">
            <tr>
              <th className="p-4 w-12 text-center">
                <input 
                  type="checkbox"
                  className="rounded-sm border-outline-variant text-primary focus:ring-primary bg-background cursor-pointer"
                  checked={paginatedInvoices.length > 0 && paginatedInvoices.every(inv => selectedInvoiceIds.includes(inv.id))}
                  onChange={(e) => {
                    if (e.target.checked) {
                      const newSelected = [...selectedInvoiceIds];
                      paginatedInvoices.forEach(inv => {
                        if (!newSelected.includes(inv.id)) {
                          newSelected.push(inv.id);
                        }
                      });
                      setSelectedInvoiceIds(newSelected);
                    } else {
                      const filteredSelected = selectedInvoiceIds.filter(id => !paginatedInvoices.some(inv => inv.id === id));
                      setSelectedInvoiceIds(filteredSelected);
                    }
                  }}
                />
              </th>
              <th className="p-4 text-xs font-mono text-on-surface-variant uppercase tracking-wider">Invoice ID</th>
              <th className="p-4 text-xs font-mono text-on-surface-variant uppercase tracking-wider">Date</th>
              <th className="p-4 text-xs font-mono text-on-surface-variant uppercase tracking-wider">Customer Name</th>
              <th className="p-4 text-xs font-mono text-on-surface-variant uppercase tracking-wider">Project / Work Order</th>
              <th className="p-4 text-xs font-mono text-on-surface-variant uppercase tracking-wider text-right">Amount</th>
              <th className="p-4 text-xs font-mono text-on-surface-variant uppercase tracking-wider text-center">Status</th>
              <th className="p-4 text-xs font-mono text-on-surface-variant uppercase tracking-wider text-center">Action</th>
            </tr>
          </thead>
          <tbody className="bg-[#1b1b1c] divide-y divide-[#2a2a2b]">
            {paginatedInvoices.length > 0 ? (
              paginatedInvoices.map((inv) => (
                <tr 
                  key={inv.id}
                  className="zebra-stripe hover:bg-[#2a2a2b]/60 transition-colors group"
                >
                  <td className="p-4 text-center">
                    <input 
                      type="checkbox"
                      className="rounded-sm border-outline-variant text-primary focus:ring-primary bg-background cursor-pointer"
                      checked={selectedInvoiceIds.includes(inv.id)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setSelectedInvoiceIds([...selectedInvoiceIds, inv.id]);
                        } else {
                          setSelectedInvoiceIds(selectedInvoiceIds.filter(id => id !== inv.id));
                        }
                      }}
                    />
                  </td>
                  <td className="p-4 font-mono text-sm text-primary font-bold">
                    {inv.id}
                  </td>
                  <td className="p-4 text-sm text-on-surface-variant">
                    {inv.date}
                  </td>
                  <td className="p-4 text-sm text-on-surface font-medium">
                    {inv.customerName}
                  </td>
                  <td className="p-4 text-sm text-on-surface-variant italic font-light">
                    {inv.project}
                  </td>
                  <td className="p-4 font-mono text-sm text-on-surface text-right font-medium">
                    ${inv.amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                  <td className="p-4 text-center">
                    {inv.status === 'PAID' && (
                      <span className="inline-block bg-[#163e1c] text-[#4caf50] border border-[#2e7d32]/50 px-2.5 py-1 text-[11px] font-bold tracking-wider uppercase rounded-xs">
                        PAID
                      </span>
                    )}
                    {inv.status === 'PENDING' && (
                      <span className="inline-flex items-center gap-1.5 bg-[#422c19] text-[#ff9800] border border-[#ef6c00]/50 px-2.5 py-1 text-[11px] font-bold tracking-wider uppercase rounded-xs">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#ff9800] animate-pulse"></span>
                        PENDING
                      </span>
                    )}
                    {inv.status === 'OVERDUE' && (
                      <span className="inline-block bg-[#411c1d] text-[#ff5252] border border-[#c62828]/50 px-2.5 py-1 text-[11px] font-bold tracking-wider uppercase rounded-xs">
                        OVERDUE
                      </span>
                    )}
                    {inv.status === 'PARTS WAIT' && (
                      <span className="inline-block bg-[#2d2e33] text-[#cfd8dc] border border-[#78909c]/50 px-2.5 py-1 text-[11px] font-bold tracking-wider uppercase rounded-xs border-dashed">
                        PARTS WAIT
                      </span>
                    )}
                  </td>
                  <td className="p-4 text-center">
                    <div className="flex items-center justify-center gap-2">
                      {inv.status !== 'PAID' && (
                        <button
                          onClick={() => {
                            setTerminalCustomerId(inv.customerId);
                            setTerminalInvoiceId(inv.id);
                            setTerminalAmount(inv.amount);
                            setIsCardTerminalOpen(true);
                          }}
                          className="text-amber-300 hover:text-amber-200 p-1.5 rounded hover:bg-black/30 transition-all cursor-pointer flex items-center gap-1 text-[11px] font-mono uppercase tracking-wider font-semibold border border-amber-500/40 bg-amber-500/10 px-2 py-1"
                          title="Pay with Debit or Credit Card"
                        >
                          <CreditCard size={13} />
                          <span>PAY CARD</span>
                        </button>
                      )}
                      <button
                        onClick={() => {
                          setSelectedEmailInvoice(inv);
                          setIsEmailModalOpen(true);
                        }}
                        className="text-emerald-400 hover:text-emerald-300 p-1.5 rounded hover:bg-black/30 transition-all cursor-pointer flex items-center gap-1 text-[11px] font-mono uppercase tracking-wider font-semibold border border-emerald-500/20 bg-emerald-500/5 px-2 py-1"
                        title="Send Email to Client"
                      >
                        <Mail size={13} />
                        <span>EMAIL</span>
                      </button>
                      <button
                        onClick={() => printInvoices([inv])}
                        className="text-orange-400 hover:text-orange-300 p-1.5 rounded hover:bg-black/30 transition-all cursor-pointer flex items-center gap-1 text-[11px] font-mono uppercase tracking-wider font-semibold border border-orange-500/20 bg-orange-500/5 px-2 py-1"
                        title="Print Invoice"
                      >
                        <Printer size={13} />
                        <span>PRINT</span>
                      </button>
                      <button
                        onClick={() => handlePreviewInvoice(inv)}
                        className="text-primary hover:text-orange-500 p-1.5 rounded hover:bg-black/30 transition-all cursor-pointer flex items-center gap-1 text-[11px] font-mono uppercase tracking-wider font-semibold border border-primary/20 bg-primary/5 px-2 py-1"
                        title="Preview & Download PDF"
                      >
                        <Eye size={13} />
                        <span>PREVIEW</span>
                      </button>
                      <button
                        onClick={() => deleteInvoice(inv.id)}
                        className="text-on-surface-variant hover:text-red-400 p-1.5 rounded hover:bg-black/20 transition-all cursor-pointer"
                        title="Delete Invoice"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={8} className="p-12 text-center text-on-surface-variant text-sm italic">
                  No matching invoice found in ledger database.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      <div className="mt-6 flex flex-col sm:flex-row items-center justify-between border-t border-outline-variant pt-4 gap-4">
        <span className="text-xs font-mono text-on-surface-variant">
          Showing {paginatedInvoices.length} of {filteredInvoices.length} transactions
        </span>
        <div className="flex gap-2">
          <button 
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
            className={`w-10 h-10 border border-outline-variant flex items-center justify-center transition-colors rounded-sm ${
              currentPage === 1 ? 'opacity-30 cursor-not-allowed' : 'hover:bg-surface-container-highest cursor-pointer'
            }`}
          >
            <ChevronLeft size={16} />
          </button>
          
          {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
            <button
              key={page}
              onClick={() => handlePageChange(page)}
              className={`w-10 h-10 flex items-center justify-center font-mono text-xs font-semibold rounded-sm transition-all ${
                currentPage === page 
                  ? 'bg-primary-container text-on-background font-bold' 
                  : 'border border-outline-variant hover:bg-surface-container-highest text-on-surface'
              }`}
            >
              {page}
            </button>
          ))}

          <button 
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
            className={`w-10 h-10 border border-outline-variant flex items-center justify-center transition-colors rounded-sm ${
              currentPage === totalPages ? 'opacity-30 cursor-not-allowed' : 'hover:bg-surface-container-highest cursor-pointer'
            }`}
          >
            <ChevronRight size={16} />
          </button>
        </div>
      </div>

      {/* Create New Invoice Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4 backdrop-blur-xs">
          <div className="bg-[#1f1f20] border-2 border-outline-variant w-full max-w-lg shadow-2xl relative">
            <div className="metal-grain absolute inset-0"></div>
            
            <div className="relative z-10 p-6">
              {/* Header */}
              <div className="flex justify-between items-center border-b border-outline-variant pb-4 mb-6">
                <h3 className="text-xl font-bold uppercase tracking-wider text-primary font-narrow">
                  GENERATE NEW INVOICE
                </h3>
                <button 
                  onClick={() => setIsModalOpen(false)}
                  className="text-on-surface-variant hover:text-on-surface cursor-pointer"
                >
                  <X size={20} />
                </button>
              </div>

              {/* Form */}
              <form onSubmit={handleAddNewInvoice} className="space-y-4">
                {/* Select Customer */}
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-on-surface-variant mb-1.5 font-semibold">
                    Customer / Client Account
                  </label>
                  <select
                    id="select-customer"
                    className="w-full bg-background border border-outline-variant text-[#e5e2e3] focus:ring-1 focus:ring-primary-container p-3 text-sm focus:outline-none"
                    value={selectedCustomerId}
                    onChange={(e) => setSelectedCustomerId(e.target.value)}
                    required
                  >
                    <option value="">-- Choose Client --</option>
                    {clients.map(c => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.company || 'Individual'})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Select Project / Build */}
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-on-surface-variant mb-1.5 font-semibold">
                    Referenced Project / Build
                  </label>
                  <select
                    id="select-project"
                    className="w-full bg-background border border-outline-variant text-[#e5e2e3] focus:ring-1 focus:ring-primary-container p-3 text-sm focus:outline-none"
                    value={selectedProjectId}
                    onChange={(e) => setSelectedProjectId(e.target.value)}
                    required
                  >
                    <option value="">-- Choose Build Project --</option>
                    {builds.map(b => (
                      <option key={b.id} value={b.id}>
                        [{b.id}] {b.name} - {b.type}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Amount */}
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-on-surface-variant mb-1.5 font-semibold">
                    Invoice Amount ($)
                  </label>
                  <input
                    id="input-invoice-amount"
                    type="number"
                    step="0.01"
                    min="0"
                    placeholder="e.g. 1500.00"
                    className="w-full bg-background border border-outline-variant text-[#e5e2e3] focus:ring-1 focus:ring-primary-container p-3 text-sm focus:outline-none"
                    value={invoiceAmount}
                    onChange={(e) => setInvoiceAmount(e.target.value)}
                    required
                  />
                </div>

                {/* Status */}
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-on-surface-variant mb-1.5 font-semibold">
                    Initial Payment Status
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {(['PAID', 'PENDING', 'OVERDUE', 'PARTS WAIT'] as InvoiceStatus[]).map((st) => (
                      <button
                        key={st}
                        type="button"
                        onClick={() => setInvoiceStatus(st)}
                        className={`py-2 text-[10px] font-bold tracking-widest uppercase border transition-all ${
                          invoiceStatus === st 
                            ? 'bg-primary-container text-on-background border-primary-container' 
                            : 'bg-background border-outline-variant hover:bg-surface-container-highest text-on-surface-variant'
                        }`}
                      >
                        {st}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Submit */}
                <div className="pt-4 border-t border-outline-variant flex gap-3">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="flex-1 py-3 text-xs tracking-wider border border-outline-variant text-on-surface font-semibold hover:bg-surface-container-highest transition-all"
                  >
                    CANCEL
                  </button>
                  <button
                    id="btn-invoice-submit"
                    type="submit"
                    className="flex-1 py-3 text-xs tracking-wider bg-primary-container text-on-background hover:bg-orange-600 font-bold transition-all"
                  >
                    GENERATE LEDGER RECORD
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Invoice Preview Modal */}
      {isPreviewOpen && selectedPreviewInvoice && (() => {
        const inv = selectedPreviewInvoice;
        const clientDetails = clients.find(c => c.id === inv.customerId);
        const buildDetails = builds.find(b => b.id === inv.projectId);
        
        const issueDate = inv.date;
        let dueDate = 'Net 30';
        try {
          const d = new Date(inv.date);
          if (!isNaN(d.getTime())) {
            d.setDate(d.getDate() + 30);
            dueDate = d.toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
          }
        } catch (e) {}

        const engineeringCost = inv.amount * 0.15;
        const materialsCost = inv.amount * 0.45;
        const machiningCost = inv.amount * 0.30;
        const qcCost = inv.amount * 0.10;

        return (
          <div className="fixed inset-0 bg-black/90 flex items-center justify-center z-50 p-4 backdrop-blur-md overflow-y-auto">
            <div className="bg-[#18181b] border-2 border-outline-variant w-full max-w-3xl shadow-2xl relative my-8">
              <div className="metal-grain absolute inset-0 opacity-10"></div>
              
              <div className="relative z-10 p-6 md:p-8">
                {/* Header Actions */}
                <div className="flex justify-between items-center border-b border-outline-variant pb-4 mb-6">
                  <div className="flex items-center gap-2">
                    <FileText className="text-primary" size={22} />
                    <h3 className="text-lg md:text-xl font-bold uppercase tracking-wider text-primary font-narrow">
                      INVOICE SUMMARY PREVIEW
                    </h3>
                  </div>
                  <button 
                    onClick={() => {
                      setIsPreviewOpen(false);
                      setSelectedPreviewInvoice(null);
                    }}
                    className="text-on-surface-variant hover:text-on-surface hover:bg-white/10 p-1 rounded-sm cursor-pointer transition-all"
                  >
                    <X size={20} />
                  </button>
                </div>

                {/* Printable Canvas Styled Card */}
                <div className="bg-white text-[#1e293b] p-6 md:p-8 rounded-sm shadow-inner border border-slate-300 font-sans text-left max-h-[500px] overflow-y-auto custom-scrollbar">
                  {/* Banner / Stamp Row */}
                  <div className="flex justify-between items-start border-b-2 border-slate-900 pb-5 mb-6">
                    <div>
                      <h4 className="text-base font-extrabold uppercase tracking-tight text-slate-900">
                        HEAVY DUTY FABRICATION
                      </h4>
                      <p className="text-[11px] text-slate-500 font-medium mt-1 uppercase tracking-wider">
                        Industrial Custom Assembly & Frame Shop
                      </p>
                    </div>
                    <div className="text-right">
                      <h2 className="text-2xl font-black text-orange-600 tracking-wider m-0">
                        INVOICE
                      </h2>
                      <p className="text-[10px] font-mono font-bold text-slate-600 mt-1">
                        ID: {inv.id}
                      </p>
                      <p className="text-[10px] text-slate-500">
                        DATE: {issueDate}
                      </p>
                    </div>
                  </div>

                  {/* Customer / Shop Row */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-6 text-xs border-b border-slate-200 pb-5">
                    <div>
                      <h5 className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2">
                        BILLED BY:
                      </h5>
                      <p className="font-bold text-slate-800">Heavy Duty Fabrication Co.</p>
                      <p className="text-slate-600 mt-1">1024 Industrial Parkway, Suite B</p>
                      <p className="text-slate-600">Detroit, MI 48201</p>
                      <p className="text-slate-500 font-mono mt-1">billing@heavydutyfab.com</p>
                    </div>
                    <div>
                      <h5 className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2">
                        BILLED TO:
                      </h5>
                      <p className="font-bold text-slate-800">{clientDetails?.name || inv.customerName}</p>
                      <p className="text-slate-600 mt-1">{clientDetails?.company || 'Private Client'}</p>
                      <p className="text-slate-600">{clientDetails?.email || 'N/A'}</p>
                      <p className="text-slate-500 font-mono mt-1">{clientDetails?.phone || 'N/A'}</p>
                    </div>
                  </div>

                  {/* Project Context Box */}
                  <div className="bg-slate-100 p-4 border-l-4 border-orange-500 mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                    <div>
                      <h6 className="text-[9px] font-bold text-slate-500 uppercase tracking-wider mb-0.5">
                        Referenced Fabrication Project
                      </h6>
                      <p className="text-sm font-bold text-slate-800">
                        {inv.project}
                      </p>
                    </div>
                    <div className="sm:text-right font-mono text-[10px] text-slate-600 bg-white/80 border border-slate-200 px-2.5 py-1 rounded-sm">
                      <span className="font-bold text-slate-700">ID:</span> {inv.projectId} | <span className="font-bold text-slate-700">TYPE:</span> {buildDetails?.type || 'Custom'}
                    </div>
                  </div>

                  {/* Breakdown Table */}
                  <table className="w-full text-xs text-left border-collapse mb-6">
                    <thead>
                      <tr className="bg-slate-900 text-white font-mono uppercase text-[10px] tracking-wider">
                        <th className="p-2.5 text-center w-[8%]">#</th>
                        <th className="p-2.5 w-[57%]">Materials & Service Spec</th>
                        <th className="p-2.5 text-center w-[10%]">QTY</th>
                        <th className="p-2.5 text-right w-[12%]">RATE</th>
                        <th className="p-2.5 text-right w-[13%]">TOTAL</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      <tr>
                        <td className="p-2.5 text-center font-mono text-slate-500">1</td>
                        <td className="p-2.5">
                          <p className="font-bold text-slate-800">Structural Engineering & CAD Drafting</p>
                          <p className="text-[10px] text-slate-500 mt-0.5">Design review, stress-simulation modeling & Blueprint validation</p>
                        </td>
                        <td className="p-2.5 text-center font-mono">1</td>
                        <td className="p-2.5 text-right font-mono">${engineeringCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                        <td className="p-2.5 text-right font-mono">${engineeringCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                      </tr>
                      <tr>
                        <td className="p-2.5 text-center font-mono text-slate-500">2</td>
                        <td className="p-2.5">
                          <p className="font-bold text-slate-800">Heavy Steel & Raw Component Sourcing</p>
                          <p className="text-[10px] text-slate-500 mt-0.5">Spec-grade structural metals, fasteners, custom laser plates</p>
                        </td>
                        <td className="p-2.5 text-center font-mono">1</td>
                        <td className="p-2.5 text-right font-mono">${materialsCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                        <td className="p-2.5 text-right font-mono">${materialsCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                      </tr>
                      <tr>
                        <td className="p-2.5 text-center font-mono text-slate-500">3</td>
                        <td className="p-2.5">
                          <p className="font-bold text-slate-800">Precision Machining, Welding & Bench Assembly</p>
                          <p className="text-[10px] text-slate-500 mt-0.5">MIG/TIG welding, manual fitting, sandblasting & primer coat</p>
                        </td>
                        <td className="p-2.5 text-center font-mono">1</td>
                        <td className="p-2.5 text-right font-mono">${machiningCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                        <td className="p-2.5 text-right font-mono">${machiningCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                      </tr>
                      <tr>
                        <td className="p-2.5 text-center font-mono text-slate-500">4</td>
                        <td className="p-2.5">
                          <p className="font-bold text-slate-800">Quality Control, Dial Calibration & Testing</p>
                          <p className="text-[10px] text-slate-500 mt-0.5">Deflection checks, weld integrity scan & micro-tolerance logs</p>
                        </td>
                        <td className="p-2.5 text-center font-mono">1</td>
                        <td className="p-2.5 text-right font-mono">${qcCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                        <td className="p-2.5 text-right font-mono">${qcCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                      </tr>
                    </tbody>
                  </table>

                  {/* Status Stamp & Summary box */}
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-t border-slate-200 pt-5 gap-6">
                    <div className="relative">
                      <span className={`inline-block border-2 font-mono font-black uppercase text-xs tracking-widest px-3 py-1.5 rounded-sm select-none transform -rotate-3 ${
                        inv.status === 'PAID' 
                          ? 'border-emerald-600 text-emerald-700 bg-emerald-50' 
                          : inv.status === 'PENDING' 
                          ? 'border-amber-600 text-amber-700 bg-amber-50' 
                          : inv.status === 'OVERDUE' 
                          ? 'border-red-600 text-red-700 bg-red-50' 
                          : 'border-slate-600 text-slate-700 bg-slate-50'
                      }`}>
                        STATUS: {inv.status === 'PARTS WAIT' ? 'BLOCKED' : inv.status}
                      </span>
                    </div>

                    <div className="w-full sm:w-[260px] space-y-2 text-xs font-mono">
                      <div className="flex justify-between text-slate-500">
                        <span>SUBTOTAL:</span>
                        <span>${inv.amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                      </div>
                      <div className="flex justify-between text-slate-500">
                        <span>EST. TAX (0%):</span>
                        <span>$0.00</span>
                      </div>
                      <div className="flex justify-between font-bold text-base text-slate-900 border-t border-slate-300 pt-2 font-sans">
                        <span>GRAND TOTAL:</span>
                        <span>${inv.amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                      </div>
                    </div>
                  </div>

                  <p className="text-[10px] text-center text-slate-400 mt-10 uppercase font-mono tracking-wider">
                    Terms: Net 30 days from date of issue. Thank you for choosing Heavy Duty Frame Shop!
                  </p>
                </div>

                {/* Footer Controls */}
                <div className="pt-6 border-t border-outline-variant flex flex-col sm:flex-row gap-3 mt-6">
                  <button
                    type="button"
                    onClick={() => {
                      setIsPreviewOpen(false);
                      setSelectedPreviewInvoice(null);
                    }}
                    className="flex-1 py-3 text-xs tracking-wider border border-outline-variant text-on-surface hover:text-white font-mono uppercase font-bold hover:bg-white/5 transition-all cursor-pointer"
                  >
                    CLOSE PREVIEW
                  </button>
                  <button
                    onClick={() => printInvoices([inv])}
                    className="flex-1 py-3 text-xs tracking-wider border-2 border-orange-500/30 hover:border-orange-500/50 text-orange-400 hover:bg-orange-500/10 font-mono uppercase font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <Printer size={14} />
                    <span>PRINT INVOICE</span>
                  </button>
                  <button
                    onClick={() => handleDownloadPDF(inv)}
                    className="flex-1 py-3 text-xs tracking-wider bg-primary hover:bg-orange-600 text-white font-mono uppercase font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md shadow-primary/20"
                  >
                    <Download size={14} />
                    <span>DOWNLOAD PDF</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Project Invoice PDF Generator Modal */}
      {isProjectPdfOpen && (
        <div className="fixed inset-0 bg-black/90 flex items-center justify-center z-50 p-4 backdrop-blur-md overflow-y-auto">
          <div className="bg-[#18181b] border-2 border-outline-variant w-full max-w-6xl shadow-2xl relative my-4 rounded-sm">
            <div className="metal-grain absolute inset-0 opacity-10 pointer-events-none"></div>
            
            <div className="relative z-10 p-6 md:p-8">
              {/* Header */}
              <div className="flex justify-between items-center border-b border-outline-variant pb-4 mb-6">
                <div className="flex items-center gap-2">
                  <Printer className="text-primary" size={22} />
                  <h3 className="text-lg md:text-xl font-bold uppercase tracking-wider text-primary font-narrow">
                    PROJECT INVOICE GENERATOR & PDF PREVIEW
                  </h3>
                </div>
                <button 
                  onClick={() => setIsProjectPdfOpen(false)}
                  className="text-on-surface-variant hover:text-on-surface hover:bg-white/10 p-1 rounded-sm cursor-pointer transition-all"
                >
                  <X size={20} />
                </button>
              </div>

              {/* Success Banner */}
              {generatorSuccessMessage && (
                <div className="mb-6 p-4 bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs font-mono font-bold uppercase tracking-wider rounded-sm flex items-center gap-2 animate-fade-in">
                  <CheckCircle size={16} />
                  {generatorSuccessMessage}
                </div>
              )}

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                {/* Left Panel: Generator Controls (5 cols) */}
                <div className="lg:col-span-5 space-y-5 bg-[#202022] p-5 border border-outline-variant rounded-sm">
                  <h4 className="text-xs font-mono uppercase tracking-widest text-primary font-bold border-b border-outline-variant pb-2">
                    BILLING CONTROLS
                  </h4>

                  {/* Select Project Dropdown */}
                  <div>
                    <label className="block text-[10px] font-mono uppercase tracking-wider text-on-surface-variant mb-1.5 font-bold">
                      Select Project / Work Order
                    </label>
                    <select
                      value={selectedGeneratorProjectId}
                      onChange={(e) => {
                        setSelectedGeneratorProjectId(e.target.value);
                        const proj = builds.find(b => b.id === e.target.value);
                        if (proj) {
                          // Default to estimated or actual
                          setGeneratorAmountBasis('estimated');
                          setGeneratorCustomAmount(proj.estimatedCost.toString());
                        }
                      }}
                      className="w-full bg-[#121214] border border-outline-variant text-on-surface text-xs font-mono p-3 focus:outline-none focus:border-primary cursor-pointer"
                    >
                      <option value="" disabled>-- Choose a Project --</option>
                      {builds.map((b) => (
                        <option key={b.id} value={b.id}>
                          [{b.id}] {b.name} ({b.customerName})
                        </option>
                      ))}
                    </select>
                  </div>

                  {selectedProject ? (
                    <>
                      {/* Customer Summary Mini Box */}
                      <div className="bg-[#121214] p-3 border border-outline-variant text-xs space-y-1 font-mono">
                        <div className="text-[10px] text-on-surface-variant uppercase font-bold tracking-wider mb-1">
                          Client Information
                        </div>
                        <div className="flex justify-between">
                          <span className="text-on-surface-variant">Client Name:</span>
                          <span className="text-on-surface font-bold">{selectedProject.customerName}</span>
                        </div>
                        {selectedProjectClient && (
                          <>
                            <div className="flex justify-between">
                              <span className="text-on-surface-variant">Company:</span>
                              <span className="text-on-surface">{selectedProjectClient.company || 'Private'}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-on-surface-variant">Email:</span>
                              <span className="text-on-surface text-primary">{selectedProjectClient.email || 'N/A'}</span>
                            </div>
                          </>
                        )}
                        <div className="flex justify-between border-t border-white/5 pt-1 mt-1">
                          <span className="text-on-surface-variant">Project Type:</span>
                          <span className="text-on-surface font-medium">{selectedProject.type}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-on-surface-variant">Project Status:</span>
                          <span className="text-primary font-bold">{selectedProject.status}</span>
                        </div>
                      </div>

                      {/* Billing Amount Basis Selector */}
                      <div>
                        <label className="block text-[10px] font-mono uppercase tracking-wider text-on-surface-variant mb-1.5 font-bold">
                          Billing Cost Basis
                        </label>
                        <div className="grid grid-cols-1 gap-2">
                          <label className={`flex items-center justify-between p-3 border cursor-pointer transition-all ${
                            generatorAmountBasis === 'estimated' 
                              ? 'bg-primary/10 border-primary text-on-surface' 
                              : 'bg-[#121214] border-outline-variant hover:bg-white/5 text-on-surface-variant'
                          }`}>
                            <div className="flex items-center gap-2">
                              <input 
                                type="radio" 
                                name="amountBasis" 
                                checked={generatorAmountBasis === 'estimated'}
                                onChange={() => setGeneratorAmountBasis('estimated')}
                                className="text-primary focus:ring-primary bg-background border-outline-variant cursor-pointer"
                              />
                              <span className="text-xs font-mono font-medium">Project Estimated Cost</span>
                            </div>
                            <span className="text-xs font-mono font-bold">${selectedProject.estimatedCost.toLocaleString()}</span>
                          </label>

                          <label className={`flex items-center justify-between p-3 border cursor-pointer transition-all ${
                            !selectedProject.actualCost ? 'opacity-50 cursor-not-allowed' : ''
                          } ${
                            generatorAmountBasis === 'actual' 
                              ? 'bg-primary/10 border-primary text-on-surface' 
                              : 'bg-[#121214] border-outline-variant hover:bg-white/5 text-on-surface-variant'
                          }`}>
                            <div className="flex items-center gap-2">
                              <input 
                                type="radio" 
                                name="amountBasis" 
                                disabled={!selectedProject.actualCost}
                                checked={generatorAmountBasis === 'actual'}
                                onChange={() => setGeneratorAmountBasis('actual')}
                                className="text-primary focus:ring-primary bg-background border-outline-variant cursor-pointer"
                              />
                              <span className="text-xs font-mono font-medium">Project Actual Cost</span>
                            </div>
                            <span className="text-xs font-mono font-bold">
                              {selectedProject.actualCost ? `$${selectedProject.actualCost.toLocaleString()}` : 'N/A'}
                            </span>
                          </label>

                          <label className={`flex items-center justify-between p-3 border cursor-pointer transition-all ${
                            generatorAmountBasis === 'custom' 
                              ? 'bg-primary/10 border-primary text-on-surface' 
                              : 'bg-[#121214] border-outline-variant hover:bg-white/5 text-on-surface-variant'
                          }`}>
                            <div className="flex items-center gap-2">
                              <input 
                                type="radio" 
                                name="amountBasis" 
                                checked={generatorAmountBasis === 'custom'}
                                onChange={() => {
                                  setGeneratorAmountBasis('custom');
                                  if (!generatorCustomAmount) {
                                    setGeneratorCustomAmount(selectedProject.estimatedCost.toString());
                                  }
                                }}
                                className="text-primary focus:ring-primary bg-background border-outline-variant cursor-pointer"
                              />
                              <span className="text-xs font-mono font-medium">Custom Overridden Cost</span>
                            </div>
                          </label>
                        </div>
                      </div>

                      {/* Custom Amount Input field (visible only when custom selected) */}
                      {generatorAmountBasis === 'custom' && (
                        <div className="animate-fade-in">
                          <label className="block text-[10px] font-mono uppercase tracking-wider text-on-surface-variant mb-1 font-bold">
                            Custom Billing Amount ($)
                          </label>
                          <input 
                            type="number"
                            value={generatorCustomAmount}
                            onChange={(e) => setGeneratorCustomAmount(e.target.value)}
                            placeholder="Enter billing amount..."
                            className="w-full bg-[#121214] border border-outline-variant text-on-surface text-xs font-mono p-3 focus:outline-none focus:border-primary"
                          />
                        </div>
                      )}

                      {/* Select Status */}
                      <div>
                        <label className="block text-[10px] font-mono uppercase tracking-wider text-on-surface-variant mb-1.5 font-bold">
                          Invoice Payment Status
                        </label>
                        <div className="grid grid-cols-2 gap-2">
                          {(['PAID', 'PENDING', 'OVERDUE', 'PARTS WAIT'] as InvoiceStatus[]).map((st) => (
                            <button
                              key={st}
                              type="button"
                              onClick={() => setGeneratorInvoiceStatus(st)}
                              className={`py-2 text-[10px] font-mono font-bold tracking-wider uppercase border transition-all ${
                                generatorInvoiceStatus === st 
                                  ? 'bg-primary/20 text-primary border-primary' 
                                  : 'bg-[#121214] border-outline-variant hover:bg-white/5 text-on-surface-variant'
                              }`}
                            >
                              {st === 'PARTS WAIT' ? 'BLOCKED' : st}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        {/* Issue Date */}
                        <div>
                          <label className="block text-[10px] font-mono uppercase tracking-wider text-on-surface-variant mb-1 font-bold">
                            Invoice Issue Date
                          </label>
                          <input 
                            type="text"
                            value={generatorInvoiceDate}
                            onChange={(e) => setGeneratorInvoiceDate(e.target.value)}
                            placeholder="Oct 20, 2023"
                            className="w-full bg-[#121214] border border-outline-variant text-on-surface text-xs font-mono p-3 focus:outline-none focus:border-primary"
                          />
                        </div>

                        {/* Terms */}
                        <div>
                          <label className="block text-[10px] font-mono uppercase tracking-wider text-on-surface-variant mb-1 font-bold">
                            Payment Terms
                          </label>
                          <select
                            value={generatorInvoiceTerms}
                            onChange={(e) => setGeneratorInvoiceTerms(e.target.value)}
                            className="w-full bg-[#121214] border border-outline-variant text-on-surface text-xs font-mono p-3 focus:outline-none focus:border-primary cursor-pointer"
                          >
                            <option value="Net 30">Net 30 Days</option>
                            <option value="Net 15">Net 15 Days</option>
                            <option value="Net 60">Net 60 Days</option>
                            <option value="Due on Receipt">Due on Receipt</option>
                          </select>
                        </div>
                      </div>
                    </>
                  ) : (
                    <div className="p-8 border border-dashed border-outline-variant text-center font-mono text-xs text-on-surface-variant italic">
                      Please select a project from the dropdown above to start generating an invoice.
                    </div>
                  )}
                </div>

                {/* Right Panel: Live PDF Preview (7 cols) */}
                <div className="lg:col-span-7 flex flex-col h-[580px]">
                  <h4 className="text-xs font-mono uppercase tracking-widest text-on-surface-variant mb-2 font-bold flex justify-between items-center">
                    <span>LIVE PDF PREVIEW</span>
                    <span className="text-[10px] font-normal text-primary lowercase font-mono">100% printable view</span>
                  </h4>

                  {selectedProject ? (
                    <div className="flex-1 bg-white text-[#1e293b] p-6 md:p-8 rounded-sm shadow-inner border border-slate-300 font-sans text-left overflow-y-auto custom-scrollbar flex flex-col justify-between">
                      <div>
                        {/* Banner Row */}
                        <div className="flex justify-between items-start border-b-2 border-slate-900 pb-4 mb-4 font-sans">
                          <div>
                            <h4 className="text-sm font-extrabold uppercase tracking-tight text-slate-900">
                              HEAVY DUTY FABRICATION
                            </h4>
                            <p className="text-[10px] text-slate-500 font-medium mt-0.5 uppercase tracking-wider">
                              Industrial Custom Assembly & Frame Shop
                            </p>
                          </div>
                          <div className="text-right">
                            <h2 className="text-xl font-black text-orange-600 tracking-wider m-0">
                              INVOICE
                            </h2>
                            <p className="text-[9px] font-mono font-bold text-slate-600 mt-0.5">
                              ID: TEMP-{selectedProject.id}
                            </p>
                            <p className="text-[9px] text-slate-500">
                              DATE: {generatorInvoiceDate}
                            </p>
                          </div>
                        </div>

                        {/* Customer Row */}
                        <div className="grid grid-cols-2 gap-4 text-[11px] border-b border-slate-200 pb-4 mb-4">
                          <div>
                            <h5 className="text-[9px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                              BILLED BY:
                            </h5>
                            <p className="font-bold text-slate-800">Heavy Duty Fabrication Co.</p>
                            <p className="text-slate-600">1024 Industrial Parkway, Suite B</p>
                            <p className="text-slate-600">Detroit, MI 48201</p>
                          </div>
                          <div>
                            <h5 className="text-[9px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                              BILLED TO:
                            </h5>
                            <p className="font-bold text-slate-800">{selectedProject.customerName}</p>
                            <p className="text-slate-600">{selectedProjectClient?.company || 'Private Client'}</p>
                            <p className="text-slate-500 font-mono text-[10px]">{selectedProjectClient?.email || 'N/A'}</p>
                          </div>
                        </div>

                        {/* Project Context */}
                        <div className="bg-slate-100 p-3 border-l-4 border-orange-500 mb-4 flex justify-between items-center gap-3">
                          <div>
                            <h6 className="text-[8px] font-bold text-slate-500 uppercase tracking-wider mb-0.5">
                              Referenced Fabrication Project
                            </h6>
                            <p className="text-xs font-bold text-slate-800">
                              {selectedProject.name}
                            </p>
                          </div>
                          <div className="text-right font-mono text-[9px] text-slate-600">
                            <span className="font-bold">ID:</span> {selectedProject.id} | <span className="font-bold">TYPE:</span> {selectedProject.type}
                          </div>
                        </div>

                        {/* Itemized Table */}
                        <table className="w-full text-[11px] text-left border-collapse mb-4">
                          <thead>
                            <tr className="bg-slate-900 text-white font-mono uppercase text-[9px] tracking-wider">
                              <th className="p-2 text-center w-[8%]">#</th>
                              <th className="p-2 w-[57%]">Materials & Service Spec</th>
                              <th className="p-2 text-center w-[10%]">QTY</th>
                              <th className="p-2 text-right w-[12%]">RATE</th>
                              <th className="p-2 text-right w-[13%]">TOTAL</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-200">
                            <tr>
                              <td className="p-2 text-center font-mono text-slate-500">1</td>
                              <td className="p-2">
                                <p className="font-bold text-slate-800">Structural Engineering & CAD Drafting</p>
                                <p className="text-[9px] text-slate-500">Design review, stress-simulation modeling & Blueprint validation</p>
                              </td>
                              <td className="p-2 text-center font-mono">1</td>
                              <td className="p-2 text-right font-mono">${computedEngineeringCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                              <td className="p-2 text-right font-mono">${computedEngineeringCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                            </tr>
                            <tr>
                              <td className="p-2 text-center font-mono text-slate-500">2</td>
                              <td className="p-2">
                                <p className="font-bold text-slate-800">Heavy Steel & Raw Component Sourcing</p>
                                <p className="text-[9px] text-slate-500">Spec-grade structural metals, fasteners, custom laser plates</p>
                              </td>
                              <td className="p-2 text-center font-mono">1</td>
                              <td className="p-2 text-right font-mono">${computedMaterialsCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                              <td className="p-2 text-right font-mono">${computedMaterialsCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                            </tr>
                            <tr>
                              <td className="p-2 text-center font-mono text-slate-500">3</td>
                              <td className="p-2">
                                <p className="font-bold text-slate-800">Precision Machining, Welding & Bench Assembly</p>
                                <p className="text-[9px] text-slate-500">MIG/TIG welding, manual fitting, sandblasting & primer coat</p>
                              </td>
                              <td className="p-2 text-center font-mono">1</td>
                              <td className="p-2 text-right font-mono">${computedMachiningCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                              <td className="p-2 text-right font-mono">${computedMachiningCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                            </tr>
                            <tr>
                              <td className="p-2 text-center font-mono text-slate-500">4</td>
                              <td className="p-2">
                                <p className="font-bold text-slate-800">Quality Control, Dial Calibration & Testing</p>
                                <p className="text-[9px] text-slate-500">Deflection checks, weld integrity scan & micro-tolerance logs</p>
                              </td>
                              <td className="p-2 text-center font-mono">1</td>
                              <td className="p-2 text-right font-mono">${computedQcCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                              <td className="p-2 text-right font-mono">${computedQcCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>

                      {/* Stamp & Totals */}
                      <div>
                        <div className="flex justify-between items-center border-t border-slate-200 pt-3">
                          <div className="relative">
                            <span className={`inline-block border-2 font-mono font-black uppercase text-[10px] tracking-widest px-2.5 py-1 rounded-sm select-none transform -rotate-3 ${
                              generatorInvoiceStatus === 'PAID' 
                                ? 'border-emerald-600 text-emerald-700 bg-emerald-50' 
                                : generatorInvoiceStatus === 'PENDING' 
                                ? 'border-amber-600 text-amber-700 bg-amber-50' 
                                : generatorInvoiceStatus === 'OVERDUE' 
                                ? 'border-red-600 text-red-700 bg-red-50' 
                                : 'border-slate-600 text-slate-700 bg-slate-50'
                            }`}>
                              STATUS: {generatorInvoiceStatus === 'PARTS WAIT' ? 'BLOCKED' : generatorInvoiceStatus}
                            </span>
                          </div>

                          <div className="w-[200px] space-y-1.5 text-[10px] font-mono">
                            <div className="flex justify-between text-slate-500">
                              <span>SUBTOTAL:</span>
                              <span>${computedInvoiceAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                            </div>
                            <div className="flex justify-between text-slate-500">
                              <span>EST. TAX (0%):</span>
                              <span>$0.00</span>
                            </div>
                            <div className="flex justify-between font-bold text-xs text-slate-900 border-t border-slate-300 pt-1.5 font-sans">
                              <span>GRAND TOTAL:</span>
                              <span>${computedInvoiceAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                            </div>
                          </div>
                        </div>

                        <p className="text-[9px] text-center text-slate-400 mt-6 uppercase font-mono tracking-wider">
                          Terms: {generatorInvoiceTerms}. Thank you for choosing Heavy Duty Frame Shop!
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="flex-1 bg-surface-container/30 border border-dashed border-outline-variant rounded-sm flex items-center justify-center p-6 text-center text-on-surface-variant font-mono text-xs italic">
                      Live PDF-style preview will render here once a project is selected.
                    </div>
                  )}
                </div>
              </div>

              {/* Modal Footer Controls */}
              <div className="pt-6 border-t border-outline-variant flex flex-col sm:flex-row gap-3 mt-6">
                <button
                  type="button"
                  onClick={() => setIsProjectPdfOpen(false)}
                  className="flex-1 py-3 text-xs tracking-wider border border-outline-variant text-on-surface hover:text-white font-mono uppercase font-bold hover:bg-white/5 transition-all cursor-pointer"
                >
                  CLOSE GENERATOR
                </button>
                {selectedProject && transientInvoice && (
                  <>
                    <button
                      onClick={() => printInvoices([transientInvoice])}
                      className="flex-1 py-3 text-xs tracking-wider border-2 border-orange-500/30 hover:border-orange-500/50 text-orange-400 hover:bg-orange-500/10 font-mono uppercase font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
                    >
                      <Printer size={14} />
                      <span>PRINT INVOICE</span>
                    </button>
                    <button
                      onClick={() => handleDownloadPDF(transientInvoice)}
                      className="flex-1 py-3 text-xs tracking-wider bg-primary/20 hover:bg-primary/30 border border-primary/40 text-primary font-mono uppercase font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md"
                    >
                      <Download size={14} />
                      <span>DOWNLOAD PDF</span>
                    </button>
                    <button
                      onClick={handleSaveGeneratorInvoiceToLedger}
                      className="flex-1 py-3 text-xs tracking-wider bg-primary hover:bg-orange-600 text-white font-mono uppercase font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md shadow-primary/20"
                    >
                      <CheckCircle size={14} />
                      <span>SAVE TO LEDGER</span>
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Material & Labor Cost Estimator Widget */}
      <MaterialCostCalculator 
        isOpen={isEstimatorOpen} 
        onClose={() => setIsEstimatorOpen(false)} 
      />

      {/* Send Invoice Email Modal */}
      <SendInvoiceEmailModal
        isOpen={isEmailModalOpen}
        onClose={() => {
          setIsEmailModalOpen(false);
          setSelectedEmailInvoice(null);
        }}
        invoice={selectedEmailInvoice}
        client={clients.find(c => c.id === selectedEmailInvoice?.customerId)}
      />

      {/* Excel Spreadsheet Connector Hub Modal */}
      <ExcelConnectorModal
        isOpen={isExcelModalOpen}
        onClose={() => setIsExcelModalOpen(false)}
      />

      {/* Card Payment POS Terminal Modal */}
      <CardTransactionModal
        isOpen={isCardTerminalOpen}
        onClose={() => setIsCardTerminalOpen(false)}
        initialCustomerId={terminalCustomerId}
        initialInvoiceId={terminalInvoiceId}
        initialAmount={terminalAmount}
      />

      {/* Card Transactions Ledger Modal */}
      <CardTransactionsLedgerModal
        isOpen={isCardLedgerOpen}
        onClose={() => setIsCardLedgerOpen(false)}
        onOpenTerminal={() => {
          setTerminalCustomerId('');
          setTerminalInvoiceId('');
          setTerminalAmount(undefined);
          setIsCardTerminalOpen(true);
        }}
      />
    </div>
  );
};
