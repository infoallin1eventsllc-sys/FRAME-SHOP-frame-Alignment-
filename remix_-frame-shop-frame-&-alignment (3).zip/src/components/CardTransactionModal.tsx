/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { useAppState } from '../StateContext';
import { CardType, CardBrand, CardTransaction } from '../types';
import { 
  CreditCard, 
  X, 
  CheckCircle2, 
  Printer, 
  ShieldCheck, 
  ArrowRight, 
  Lock, 
  DollarSign, 
  AlertCircle,
  Building2,
  FileText,
  Clock,
  Sparkles,
  Zap,
  RotateCw
} from 'lucide-react';

interface CardTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialCustomerId?: string;
  initialInvoiceId?: string;
  initialAmount?: number;
}

export const CardTransactionModal: React.FC<CardTransactionModalProps> = ({
  isOpen,
  onClose,
  initialCustomerId = '',
  initialInvoiceId = '',
  initialAmount
}) => {
  const { clients, invoices, processCardTransaction } = useAppState();

  // Step state: 'input' | 'processing' | 'success'
  const [step, setStep] = useState<'input' | 'processing' | 'success'>('input');
  const [processingStage, setProcessingStage] = useState(0);

  // Form Fields
  const [selectedCustomerId, setSelectedCustomerId] = useState(initialCustomerId);
  const [selectedInvoiceId, setSelectedInvoiceId] = useState(initialInvoiceId);
  const [paymentType, setPaymentType] = useState<'invoice' | 'custom'>('invoice');
  const [customAmount, setCustomAmount] = useState<string>('');
  
  // Card Details
  const [cardType, setCardType] = useState<CardType>('credit');
  const [cardNumber, setCardNumber] = useState('');
  const [cardholderName, setCardholderName] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvc, setCvc] = useState('');
  const [zipCode, setZipCode] = useState('');
  const [passFeeToCustomer, setPassFeeToCustomer] = useState(false);
  const [notes, setNotes] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  // Resulting transaction
  const [completedTxn, setCompletedTxn] = useState<CardTransaction | null>(null);

  // Initialize or reset when modal opens or initial props change
  useEffect(() => {
    if (isOpen) {
      setStep('input');
      setProcessingStage(0);
      setErrorMessage('');
      setCompletedTxn(null);
      
      const custId = initialCustomerId || (clients[0]?.id || '');
      setSelectedCustomerId(custId);

      if (initialInvoiceId) {
        setPaymentType('invoice');
        setSelectedInvoiceId(initialInvoiceId);
      } else {
        setPaymentType('invoice');
      }

      if (initialAmount) {
        setCustomAmount(String(initialAmount));
      }
    }
  }, [isOpen, initialCustomerId, initialInvoiceId, initialAmount, clients]);

  // Auto-fill fallback fields for Apple Pay / Google Pay when selected
  useEffect(() => {
    if (cardType === 'apple_pay') {
      if (!cardNumber) setCardNumber('4000 1234 5678 8921');
      if (!expiry) setExpiry('12/28');
      if (!cvc) setCvc('882');
    } else if (cardType === 'google_pay') {
      if (!cardNumber) setCardNumber('4111 2222 3333 4019');
      if (!expiry) setExpiry('08/29');
      if (!cvc) setCvc('910');
    }
  }, [cardType]);

  // Selected client object
  const selectedClient = useMemo(() => {
    return clients.find(c => c.id === selectedCustomerId) || null;
  }, [clients, selectedCustomerId]);

  // Unpaid invoices for selected client
  const clientUnpaidInvoices = useMemo(() => {
    if (!selectedCustomerId) return [];
    return invoices.filter(inv => inv.customerId === selectedCustomerId && inv.status !== 'PAID');
  }, [invoices, selectedCustomerId]);

  // Auto-fill customer name on card if empty
  useEffect(() => {
    if (selectedClient && !cardholderName) {
      setCardholderName(selectedClient.name.replace(/["']/g, ''));
    }
  }, [selectedClient]);

  // Calculate charge amount
  const targetInvoice = useMemo(() => {
    return invoices.find(inv => inv.id === selectedInvoiceId) || null;
  }, [invoices, selectedInvoiceId]);

  const baseAmount = useMemo(() => {
    if (paymentType === 'invoice' && targetInvoice) {
      return targetInvoice.amount;
    }
    const parsed = parseFloat(customAmount);
    return isNaN(parsed) ? 0 : Math.max(0, parsed);
  }, [paymentType, targetInvoice, customAmount]);

  // Auto-detect Card Brand by starting digits or digital wallet
  const detectedBrand = useMemo<CardBrand>(() => {
    if (cardType === 'apple_pay') return 'apple_pay';
    if (cardType === 'google_pay') return 'google_pay';
    const digits = cardNumber.replace(/\D/g, '');
    if (digits.startsWith('4')) return 'visa';
    if (digits.startsWith('51') || digits.startsWith('52') || digits.startsWith('53') || digits.startsWith('54') || digits.startsWith('55')) return 'mastercard';
    if (digits.startsWith('34') || digits.startsWith('37')) return 'amex';
    if (digits.startsWith('6011') || digits.startsWith('65')) return 'discover';
    return 'visa';
  }, [cardNumber, cardType]);

  // Fee calculation
  const processingFee = useMemo(() => {
    if (cardType === 'debit' || cardType === 'apple_pay' || cardType === 'google_pay') return 0; // $0.00 fee for Debit / Digital Wallets
    if (baseAmount <= 0) return 0;
    return Number(((baseAmount * 0.029) + 0.30).toFixed(2));
  }, [cardType, baseAmount]);

  const totalChargeAmount = useMemo(() => {
    if (passFeeToCustomer && cardType === 'credit') {
      return baseAmount + processingFee;
    }
    return baseAmount;
  }, [baseAmount, processingFee, passFeeToCustomer, cardType]);

  // Format Card Number (adds spaces every 4 digits)
  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value.replace(/\D/g, '').slice(0, 16);
    const parts = raw.match(/.{1,4}/g) || [];
    setCardNumber(parts.join(' '));
  };

  // Format Expiry (MM/YY)
  const handleExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let raw = e.target.value.replace(/\D/g, '').slice(0, 4);
    if (raw.length >= 3) {
      raw = raw.slice(0, 2) + '/' + raw.slice(2);
    }
    setExpiry(raw);
  };

  // Handle Submit & Live Terminal Processing Simulation
  const handleProcessTransaction = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!selectedClient) {
      setErrorMessage('Please select a valid customer.');
      return;
    }

    if (baseAmount <= 0) {
      setErrorMessage('Transaction amount must be greater than $0.00.');
      return;
    }

    if (cardType !== 'apple_pay' && cardType !== 'google_pay') {
      const digitsOnly = cardNumber.replace(/\D/g, '');
      if (digitsOnly.length < 12) {
        setErrorMessage('Please enter a valid debit or credit card number.');
        return;
      }

      if (!expiry || expiry.length < 5) {
        setErrorMessage('Please enter a valid card expiration date (MM/YY).');
        return;
      }

      if (!cvc || cvc.length < 3) {
        setErrorMessage('Please enter a valid 3 or 4 digit security code (CVC).');
        return;
      }
    }

    // Begin terminal animation sequence
    setStep('processing');
    setProcessingStage(1);

    setTimeout(() => {
      setProcessingStage(2);
    }, 600);

    setTimeout(() => {
      setProcessingStage(3);
    }, 1200);

    setTimeout(async () => {
      try {
        const txn = await processCardTransaction({
          customerId: selectedClient.id,
          customerName: selectedClient.name,
          invoiceId: paymentType === 'invoice' ? selectedInvoiceId : undefined,
          amount: totalChargeAmount,
          cardType,
          cardBrand: detectedBrand,
          cardNumber,
          cardholderName: cardholderName || selectedClient.name,
          notes,
          passFeeToCustomer
        });
        setCompletedTxn(txn);
        setStep('success');
      } catch (err: any) {
        setStep('input');
        setErrorMessage(err?.message || 'Transaction authorization failed. Please try again.');
      }
    }, 1800);
  };

  // Printable receipt handler
  const handlePrintReceipt = () => {
    if (!completedTxn) return;
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    printWindow.document.write(`
      <html>
        <head>
          <title>Receipt ${completedTxn.id}</title>
          <style>
            body { font-family: 'Courier New', monospace; padding: 20px; max-width: 400px; margin: 0 auto; color: #000; }
            .text-center { text-align: center; }
            .header { border-bottom: 2px dashed #000; padding-bottom: 10px; margin-bottom: 15px; }
            .title { font-weight: bold; font-size: 16px; margin: 0; }
            .subtitle { font-size: 12px; color: #555; }
            .row { display: flex; justify-content: space-between; margin: 6px 0; font-size: 13px; }
            .total-row { border-top: 2px solid #000; border-bottom: 2px solid #000; padding: 8px 0; font-weight: bold; font-size: 15px; margin-top: 15px; }
            .footer { margin-top: 25px; border-top: 1px dashed #000; pt: 10px; font-size: 11px; text-align: center; color: #444; }
            .approved { display: inline-block; border: 2px solid #000; padding: 4px 12px; font-weight: bold; font-size: 14px; margin: 10px 0; }
          </style>
        </head>
        <body>
          <div class="header text-center">
            <h2 class="title">FABRICATORS STUDIO</h2>
            <div class="subtitle">Custom Fabrication & Precision Engineering</div>
            <div class="subtitle">Card Payment Receipt</div>
            <div class="approved">TRANSACTION APPROVED</div>
          </div>
          
          <div class="row"><span>Date & Time:</span><span>${completedTxn.timestamp}</span></div>
          <div class="row"><span>Transaction ID:</span><span>${completedTxn.id}</span></div>
          <div class="row"><span>Auth Code:</span><span>${completedTxn.authCode}</span></div>
          <div class="row"><span>Customer:</span><span>${completedTxn.customerName}</span></div>
          <div class="row"><span>Card Type:</span><span style="text-transform: uppercase;">${completedTxn.cardType} (${completedTxn.cardBrand})</span></div>
          <div class="row"><span>Card Number:</span><span>•••• •••• •••• ${completedTxn.lastFour}</span></div>
          <div class="row"><span>Cardholder:</span><span>${completedTxn.cardholderName}</span></div>
          ${completedTxn.invoiceId ? `<div class="row"><span>Invoice Ref:</span><span>${completedTxn.invoiceId}</span></div>` : ''}
          
          <div class="total-row row">
            <span>TOTAL PAID:</span>
            <span>$${completedTxn.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
          </div>

          <div class="footer">
            <div>Thank you for your business!</div>
            <div>Merchant Copy • Retain for Records</div>
          </div>
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
    }, 250);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 md:p-6 overflow-y-auto">
      <div className="bg-[#18181a] border border-amber-500/30 rounded-lg w-full max-w-2xl overflow-hidden shadow-2xl relative text-slate-100 flex flex-col my-auto max-h-[92vh]">
        
        {/* Modal Header */}
        <div className="bg-[#121214] border-b border-amber-500/20 px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-500/10 border border-amber-500/30 rounded-md text-amber-400">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold tracking-wide uppercase text-white flex items-center gap-2">
                Card Payment Terminal
                <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-2 py-0.5 rounded font-mono">
                  Gateway Live
                </span>
              </h3>
              <p className="text-xs text-slate-400">Process instant debit or credit card transactions for customers</p>
            </div>
          </div>
          
          <button 
            onClick={onClose}
            className="p-1.5 hover:bg-slate-800 rounded-md text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-5 flex-1">
          
          {/* STEP 1: INPUT FORM */}
          {step === 'input' && (
            <form onSubmit={handleProcessTransaction} className="space-y-5">
              
              {errorMessage && (
                <div className="bg-red-500/10 border border-red-500/40 p-3 rounded-md flex items-start gap-2.5 text-xs text-red-300">
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {/* Customer & Invoice Selection */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-[#202023] p-3.5 border border-slate-800 rounded-md">
                
                {/* Customer Dropdown */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Select Customer
                  </label>
                  <select
                    value={selectedCustomerId}
                    onChange={(e) => {
                      setSelectedCustomerId(e.target.value);
                      setSelectedInvoiceId('');
                    }}
                    className="w-full bg-[#121214] border border-slate-700 text-white text-xs rounded px-3 py-2 focus:outline-none focus:border-amber-500"
                  >
                    <option value="">-- Choose Customer --</option>
                    {clients.map(c => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.company || 'Private'}) - Bal: ${c.outstandingBalance.toLocaleString()}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Payment Purpose / Invoice selection */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Payment Target
                  </label>
                  <div className="flex gap-2 mb-2">
                    <button
                      type="button"
                      onClick={() => setPaymentType('invoice')}
                      className={`flex-1 text-xs py-1 px-2 rounded border font-medium transition-colors ${
                        paymentType === 'invoice'
                          ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                          : 'bg-[#121214] border-slate-700 text-slate-400 hover:text-white'
                      }`}
                    >
                      Pay Invoice
                    </button>
                    <button
                      type="button"
                      onClick={() => setPaymentType('custom')}
                      className={`flex-1 text-xs py-1 px-2 rounded border font-medium transition-colors ${
                        paymentType === 'custom'
                          ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                          : 'bg-[#121214] border-slate-700 text-slate-400 hover:text-white'
                      }`}
                    >
                      Custom Deposit
                    </button>
                  </div>

                  {paymentType === 'invoice' ? (
                    <select
                      value={selectedInvoiceId}
                      onChange={(e) => setSelectedInvoiceId(e.target.value)}
                      className="w-full bg-[#121214] border border-slate-700 text-white text-xs rounded px-3 py-2 focus:outline-none focus:border-amber-500"
                    >
                      <option value="">-- Select Pending Invoice --</option>
                      {clientUnpaidInvoices.map(inv => (
                        <option key={inv.id} value={inv.id}>
                          {inv.id} - {inv.project} (${inv.amount.toLocaleString()})
                        </option>
                      ))}
                    </select>
                  ) : (
                    <div className="relative">
                      <span className="absolute left-3 top-2.5 text-xs text-slate-400">$</span>
                      <input
                        type="number"
                        min="1"
                        step="0.01"
                        placeholder="0.00"
                        value={customAmount}
                        onChange={(e) => setCustomAmount(e.target.value)}
                        className="w-full bg-[#121214] border border-slate-700 text-white text-xs rounded pl-7 pr-3 py-2 focus:outline-none focus:border-amber-500 font-mono"
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* CARD TYPE SELECTOR: DEBIT, CREDIT, APPLE PAY, GOOGLE PAY */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                    Select Card / Wallet Payment Type
                  </label>
                  <span className="text-[11px] text-slate-400 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> Tokenized & Encrypted
                  </span>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5">
                  
                  {/* DEBIT CARD BUTTON */}
                  <button
                    type="button"
                    onClick={() => setCardType('debit')}
                    className={`p-2.5 rounded-md border text-left transition-all relative ${
                      cardType === 'debit'
                        ? 'bg-blue-950/40 border-blue-500 text-white shadow-lg ring-1 ring-blue-500/50'
                        : 'bg-[#202023] border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-0.5">
                      <span className="font-bold text-xs uppercase tracking-wider flex items-center gap-1 text-blue-400">
                        🏧 Debit
                      </span>
                      {cardType === 'debit' && (
                        <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
                      )}
                    </div>
                    <p className="text-[10px] text-slate-300 font-medium">Direct PIN Debit</p>
                    <p className="text-[9px] text-emerald-400 mt-0.5 font-mono font-semibold">
                      ✓ $0.00 Fee
                    </p>
                  </button>

                  {/* CREDIT CARD BUTTON */}
                  <button
                    type="button"
                    onClick={() => setCardType('credit')}
                    className={`p-2.5 rounded-md border text-left transition-all relative ${
                      cardType === 'credit'
                        ? 'bg-amber-950/40 border-amber-500 text-white shadow-lg ring-1 ring-amber-500/50'
                        : 'bg-[#202023] border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-0.5">
                      <span className="font-bold text-xs uppercase tracking-wider flex items-center gap-1 text-amber-400">
                        💳 Credit
                      </span>
                      {cardType === 'credit' && (
                        <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                      )}
                    </div>
                    <p className="text-[10px] text-slate-300 font-medium">Visa / MC / Amex</p>
                    <p className="text-[9px] text-slate-400 mt-0.5 font-mono">
                      2.9% + $0.30 Rate
                    </p>
                  </button>

                  {/* APPLE PAY BUTTON */}
                  <button
                    type="button"
                    onClick={() => setCardType('apple_pay')}
                    className={`p-2.5 rounded-md border text-left transition-all relative ${
                      cardType === 'apple_pay'
                        ? 'bg-slate-900 border-slate-200 text-white shadow-lg ring-1 ring-white/60'
                        : 'bg-[#202023] border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-0.5">
                      <span className="font-bold text-xs uppercase tracking-wider flex items-center gap-1 text-white">
                        <span className="text-sm"></span> Apple Pay
                      </span>
                      {cardType === 'apple_pay' && (
                        <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
                      )}
                    </div>
                    <p className="text-[10px] text-slate-300 font-medium">Biometric Touch ID</p>
                    <p className="text-[9px] text-emerald-400 mt-0.5 font-mono font-semibold">
                      ✓ Instant Tap
                    </p>
                  </button>

                  {/* GOOGLE PAY BUTTON */}
                  <button
                    type="button"
                    onClick={() => setCardType('google_pay')}
                    className={`p-2.5 rounded-md border text-left transition-all relative ${
                      cardType === 'google_pay'
                        ? 'bg-slate-900 border-blue-400 text-white shadow-lg ring-1 ring-blue-400/60'
                        : 'bg-[#202023] border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-0.5">
                      <span className="font-bold text-xs uppercase tracking-wider flex items-center gap-1 text-blue-300">
                        <span className="font-black text-blue-400">G</span> Pay
                      </span>
                      {cardType === 'google_pay' && (
                        <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
                      )}
                    </div>
                    <p className="text-[10px] text-slate-300 font-medium">1-Tap Wallet</p>
                    <p className="text-[9px] text-emerald-400 mt-0.5 font-mono font-semibold">
                      ✓ Instant Tap
                    </p>
                  </button>

                </div>
              </div>

              {/* VIRTUAL INTERACTIVE CARD GRAPHIC */}
              <div className="relative overflow-hidden rounded-xl p-5 border shadow-xl transition-all"
                   style={{
                     background: cardType === 'debit' 
                       ? 'linear-gradient(135deg, #0f2027 0%, #203a43 50%, #2c5364 100%)' 
                       : cardType === 'apple_pay'
                       ? 'linear-gradient(135deg, #000000 0%, #1c1c1e 50%, #2c2c2e 100%)'
                       : cardType === 'google_pay'
                       ? 'linear-gradient(135deg, #1e293b 0%, #0f172a 50%, #030712 100%)'
                       : 'linear-gradient(135deg, #1f1c2c 0%, #302b63 50%, #24243e 100%)',
                     borderColor: cardType === 'debit' 
                       ? '#3b82f640' 
                       : cardType === 'apple_pay' 
                       ? '#ffffff40' 
                       : cardType === 'google_pay' 
                       ? '#60a5fa40' 
                       : '#f59e0b40'
                   }}>
                
                {/* Background decorative watermark */}
                <div className="absolute right-[-20px] bottom-[-20px] opacity-10 pointer-events-none">
                  <CreditCard className="w-48 h-48 text-white" />
                </div>

                <div className="flex justify-between items-start mb-6">
                  <div className="flex items-center gap-2">
                    {/* Metallic Chip Graphic or Wallet Logo */}
                    {cardType === 'apple_pay' ? (
                      <div className="px-3 py-1 bg-white/10 backdrop-blur border border-white/20 rounded-md flex items-center gap-1.5 text-white font-bold text-sm">
                        <span></span> <span className="font-semibold tracking-wide">Pay</span>
                      </div>
                    ) : cardType === 'google_pay' ? (
                      <div className="px-3 py-1 bg-white/10 backdrop-blur border border-blue-400/30 rounded-md flex items-center gap-1.5 text-white font-bold text-sm">
                        <span className="text-blue-400 font-black">G</span> <span className="font-semibold tracking-wide">Pay</span>
                      </div>
                    ) : (
                      <div className="w-10 h-7 bg-gradient-to-tr from-amber-200 via-amber-400 to-amber-100 rounded border border-amber-500/60 flex items-center justify-center shadow-inner">
                        <div className="w-8 h-5 border border-amber-800/40 rounded-xs grid grid-cols-2 gap-0.5">
                          <div className="border-r border-b border-amber-800/40" />
                          <div className="border-b border-amber-800/40" />
                          <div className="border-r border-amber-800/40" />
                          <div />
                        </div>
                      </div>
                    )}
                    
                    {/* Contactless Signal Icon */}
                    <svg className="w-5 h-5 text-slate-200/80" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.636 18.364a9 9 0 010-12.728M8.464 15.536a5 5 0 010-7.072M11.293 12.707a1 1 0 010-1.414" />
                    </svg>
                  </div>

                  {/* Card Type Badge & Brand */}
                  <div className="flex flex-col items-end">
                    <span className={`text-[10px] font-bold font-mono px-2 py-0.5 rounded border tracking-widest uppercase ${
                      cardType === 'debit' 
                        ? 'bg-blue-500/20 text-blue-300 border-blue-400/40' 
                        : cardType === 'apple_pay' 
                        ? 'bg-white/20 text-white border-white/40' 
                        : cardType === 'google_pay' 
                        ? 'bg-blue-500/20 text-blue-300 border-blue-400/40' 
                        : 'bg-amber-500/20 text-amber-300 border-amber-400/40'
                    }`}>
                      {cardType === 'debit' 
                        ? 'DEBIT CARD' 
                        : cardType === 'apple_pay' 
                        ? ' APPLE PAY EXPRESS' 
                        : cardType === 'google_pay' 
                        ? 'G PAY WALLET' 
                        : 'CREDIT CARD'}
                    </span>
                    <span className="text-xs font-black uppercase text-white tracking-wider mt-1 font-mono">
                      {detectedBrand.replace('_', ' ').toUpperCase()}
                    </span>
                  </div>
                </div>

                {/* Card Number / Token Preview */}
                <div className="mb-4">
                  <div className="text-[10px] text-slate-300 uppercase font-mono tracking-wider mb-1">
                    {cardType === 'apple_pay' || cardType === 'google_pay' ? 'Device Account Number / Device Token' : 'Card Number'}
                  </div>
                  <div className="font-mono text-lg md:text-xl font-bold tracking-widest text-white drop-shadow">
                    {cardNumber || '•••• •••• •••• ••••'}
                  </div>
                </div>

                {/* Cardholder & Expiry Row */}
                <div className="flex justify-between items-end">
                  <div>
                    <div className="text-[9px] text-slate-300 uppercase font-mono">
                      {cardType === 'apple_pay' ? 'Apple ID Account' : cardType === 'google_pay' ? 'Google Account Holder' : 'Cardholder Name'}
                    </div>
                    <div className="font-mono text-xs md:text-sm font-semibold uppercase text-slate-100 tracking-wider">
                      {cardholderName || 'FULL NAME'}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-[9px] text-slate-300 uppercase font-mono">Expires</div>
                    <div className="font-mono text-xs md:text-sm font-semibold text-slate-100 tracking-wider">
                      {expiry || 'MM/YY'}
                    </div>
                  </div>
                </div>
              </div>

              {/* CARD / WALLET INPUT FORM FIELDS */}
              <div className="space-y-3">
                {cardType === 'apple_pay' ? (
                  <div className="bg-slate-900 border border-slate-700 rounded-md p-3.5 space-y-2">
                    <div className="flex items-center gap-2 text-white font-bold text-xs uppercase tracking-wider">
                      <span className="text-lg"></span> Apple Pay Express Token Ready
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Biometric Touch ID / Face ID passkey active for <strong className="text-white">{cardholderName || 'Selected Customer'}</strong>. Click below to verify passkey and authorize terminal transaction.
                    </p>
                  </div>
                ) : cardType === 'google_pay' ? (
                  <div className="bg-slate-900 border border-blue-500/40 rounded-md p-3.5 space-y-2">
                    <div className="flex items-center gap-2 text-blue-300 font-bold text-xs uppercase tracking-wider">
                      <span className="text-blue-400 font-black text-sm">G</span> Google Pay 1-Tap Wallet Connected
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Encrypted wallet token active for <strong className="text-white">{selectedClient?.email || cardholderName || 'Selected Customer'}</strong>. Authenticates with Google Payments Encryption Service instantly.
                    </p>
                  </div>
                ) : (
                  <>
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                        Cardholder Full Name
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Marcus Blackwood"
                        value={cardholderName}
                        onChange={(e) => setCardholderName(e.target.value)}
                        className="w-full bg-[#121214] border border-slate-700 text-white text-xs rounded px-3 py-2 focus:outline-none focus:border-amber-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                        Card Number
                      </label>
                      <div className="relative">
                        <input
                          type="text"
                          required
                          placeholder="4532 •••• •••• 8812"
                          value={cardNumber}
                          onChange={handleCardNumberChange}
                          className="w-full bg-[#121214] border border-slate-700 text-white text-xs rounded px-3 py-2 pr-10 focus:outline-none focus:border-amber-500 font-mono tracking-widest"
                        />
                        <CreditCard className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-3">
                      <div>
                        <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                          Expiry (MM/YY)
                        </label>
                        <input
                          type="text"
                          required
                          placeholder="12/28"
                          value={expiry}
                          onChange={handleExpiryChange}
                          className="w-full bg-[#121214] border border-slate-700 text-white text-xs rounded px-3 py-2 focus:outline-none focus:border-amber-500 font-mono text-center"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                          CVC / CVV
                        </label>
                        <input
                          type="password"
                          required
                          maxLength={4}
                          placeholder="123"
                          value={cvc}
                          onChange={(e) => setCvc(e.target.value.replace(/\D/g, '').slice(0, 4))}
                          className="w-full bg-[#121214] border border-slate-700 text-white text-xs rounded px-3 py-2 focus:outline-none focus:border-amber-500 font-mono text-center"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                          Billing Zip Code
                        </label>
                        <input
                          type="text"
                          placeholder="90210"
                          value={zipCode}
                          onChange={(e) => setZipCode(e.target.value.slice(0, 10))}
                          className="w-full bg-[#121214] border border-slate-700 text-white text-xs rounded px-3 py-2 focus:outline-none focus:border-amber-500 font-mono text-center"
                        />
                      </div>
                    </div>
                  </>
                )}

                {/* Additional Options */}
                {cardType === 'credit' && processingFee > 0 && (
                  <div className="pt-1">
                    <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-300">
                      <input
                        type="checkbox"
                        checked={passFeeToCustomer}
                        onChange={(e) => setPassFeeToCustomer(e.target.checked)}
                        className="rounded border-slate-700 bg-[#121214] text-amber-500 focus:ring-amber-500"
                      />
                      <span>Pass 2.9% + $0.30 merchant credit fee (${processingFee.toFixed(2)}) to customer</span>
                    </label>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    Terminal Notes / Internal Reference (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Down payment for custom chassis TIG welding"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    className="w-full bg-[#121214] border border-slate-700 text-white text-xs rounded px-3 py-2 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              {/* PAYMENT SUMMARY FOOTER BAR */}
              <div className="bg-[#121214] border border-slate-800 p-4 rounded-md flex flex-col md:flex-row justify-between items-center gap-3">
                <div className="space-y-0.5 text-center md:text-left">
                  <div className="text-xs text-slate-400">Total Transaction Charge:</div>
                  <div className="text-xl font-mono font-bold text-amber-400 flex items-center justify-center md:justify-start gap-1">
                    ${totalChargeAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    {(cardType === 'debit' || cardType === 'apple_pay' || cardType === 'google_pay') && (
                      <span className="text-[10px] text-emerald-400 font-sans bg-emerald-500/20 px-1.5 py-0.5 rounded ml-2">
                        NO FEE
                      </span>
                    )}
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={baseAmount <= 0}
                  className={`w-full md:w-auto px-6 py-2.5 text-slate-950 font-bold text-xs uppercase tracking-wider rounded-md transition-all shadow-lg flex items-center justify-center gap-2 ${
                    cardType === 'apple_pay'
                      ? 'bg-white hover:bg-slate-200 text-slate-950 ring-2 ring-slate-300'
                      : cardType === 'google_pay'
                      ? 'bg-blue-500 hover:bg-blue-600 text-white'
                      : 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700'
                  }`}
                >
                  <Lock className="w-4 h-4" />
                  {cardType === 'apple_pay' ? (
                    <span>Pay with Pay (${totalChargeAmount.toFixed(2)})</span>
                  ) : cardType === 'google_pay' ? (
                    <span>Pay with G Pay (${totalChargeAmount.toFixed(2)})</span>
                  ) : (
                    <span>Process ${totalChargeAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {cardType.toUpperCase()}</span>
                  )}
                </button>
              </div>

            </form>
          )}

          {/* STEP 2: LIVE TERMINAL AUTHORIZATION OVERLAY */}
          {step === 'processing' && (
            <div className="py-12 flex flex-col items-center justify-center text-center space-y-6">
              
              {/* Terminal Spinner graphic */}
              <div className="relative">
                <div className="w-20 h-20 rounded-full border-4 border-amber-500/20 border-t-amber-500 animate-spin" />
                <div className="absolute inset-0 flex items-center justify-center">
                  {cardType === 'apple_pay' ? (
                    <span className="text-2xl text-white"></span>
                  ) : cardType === 'google_pay' ? (
                    <span className="text-2xl font-black text-blue-400">G</span>
                  ) : (
                    <CreditCard className="w-8 h-8 text-amber-400" />
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="text-base font-bold uppercase tracking-wider text-white">
                  Processing Terminal Transaction
                </h4>
                <p className="text-xs text-slate-400 font-mono">
                  Charging ${totalChargeAmount.toFixed(2)} via {cardType === 'apple_pay' ? 'Apple Pay' : cardType === 'google_pay' ? 'Google Pay' : cardType.toUpperCase()} ({detectedBrand.replace('_', ' ').toUpperCase()})
                </p>
              </div>

              {/* Step checklist */}
              <div className="w-full max-w-md bg-[#121214] border border-slate-800 rounded-md p-4 space-y-3 font-mono text-xs text-left">
                <div className={`flex items-center gap-2 ${processingStage >= 1 ? 'text-amber-400 font-semibold' : 'text-slate-600'}`}>
                  {processingStage >= 1 ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Clock className="w-4 h-4" />}
                  <span>1. Contacting {cardType === 'apple_pay' ? 'Apple Pay Secure Enclave' : cardType === 'google_pay' ? 'Google Pay Encryption Service' : cardType === 'debit' ? 'Interbank Debit Network' : 'Credit Card Gateway'}...</span>
                </div>

                <div className={`flex items-center gap-2 ${processingStage >= 2 ? 'text-amber-400 font-semibold' : 'text-slate-600'}`}>
                  {processingStage >= 2 ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Clock className="w-4 h-4" />}
                  <span>2. {cardType === 'apple_pay' ? 'Verifying Face ID / Touch ID Passkey...' : cardType === 'google_pay' ? 'Verifying Google Account Security Token...' : 'Verifying CVC Security & AVS Address Code...'}</span>
                </div>

                <div className={`flex items-center gap-2 ${processingStage >= 3 ? 'text-emerald-400 font-bold' : 'text-slate-600'}`}>
                  {processingStage >= 3 ? <CheckCircle2 className="w-4 h-4 text-emerald-400 animate-bounce" /> : <Clock className="w-4 h-4" />}
                  <span>3. Requesting Single-Use Payment Authorization Token...</span>
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: TRANSACTION APPROVED RECEIPT */}
          {step === 'success' && completedTxn && (
            <div className="space-y-6 py-2">
              
              {/* Approval Header Banner */}
              <div className="bg-emerald-500/10 border border-emerald-500/30 p-4 rounded-md text-center space-y-1">
                <div className="inline-flex p-2 bg-emerald-500/20 text-emerald-400 rounded-full mb-1">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h4 className="text-lg font-bold text-emerald-400 uppercase tracking-wider">
                  Transaction Approved!
                </h4>
                <p className="text-xs text-slate-300">
                  Auth Code: <span className="font-mono text-emerald-300 font-bold">{completedTxn.authCode}</span>
                </p>
              </div>

              {/* Terminal Digital Receipt Card */}
              <div className="bg-[#121214] border border-slate-800 rounded-md p-5 space-y-4 font-mono text-xs">
                
                <div className="border-b border-slate-800 pb-3 flex justify-between items-center">
                  <div>
                    <div className="font-bold text-white uppercase text-sm">FABRICATORS STUDIO</div>
                    <div className="text-[10px] text-slate-400">Card Payment Receipt</div>
                  </div>
                  <div className="text-right">
                    <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] px-2 py-0.5 rounded font-bold uppercase">
                      {completedTxn.cardType} PAID
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-slate-300">
                  <div>
                    <span className="text-slate-500">Transaction ID:</span>
                    <div className="text-white font-bold">{completedTxn.id}</div>
                  </div>
                  <div>
                    <span className="text-slate-500">Timestamp:</span>
                    <div className="text-white">{completedTxn.timestamp}</div>
                  </div>
                  <div>
                    <span className="text-slate-500">Customer:</span>
                    <div className="text-white">{completedTxn.customerName}</div>
                  </div>
                  <div>
                    <span className="text-slate-500">Card Used:</span>
                    <div className="text-white uppercase">{completedTxn.cardBrand} •••• {completedTxn.lastFour}</div>
                  </div>
                  {completedTxn.invoiceId && (
                    <div className="col-span-2">
                      <span className="text-slate-500">Invoice Settled:</span>
                      <div className="text-amber-400 font-bold">{completedTxn.invoiceId} (Status set to PAID)</div>
                    </div>
                  )}
                </div>

                {/* Amount Breakdown */}
                <div className="border-t border-slate-800 pt-3 space-y-1.5">
                  <div className="flex justify-between text-slate-400">
                    <span>Base Amount:</span>
                    <span>${(completedTxn.amount - (completedTxn.passFeeToCustomer ? completedTxn.processingFee : 0)).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                  </div>
                  {completedTxn.passFeeToCustomer && completedTxn.processingFee > 0 && (
                    <div className="flex justify-between text-slate-400">
                      <span>Credit Fee (2.9% + $0.30):</span>
                      <span>${completedTxn.processingFee.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-white font-bold text-sm pt-1 border-t border-slate-700">
                    <span>TOTAL CHARGED:</span>
                    <span className="text-amber-400">${completedTxn.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  type="button"
                  onClick={handlePrintReceipt}
                  className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white font-semibold text-xs rounded-md transition-colors flex items-center justify-center gap-2"
                >
                  <Printer className="w-4 h-4 text-amber-400" />
                  Print Merchant Receipt
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setStep('input');
                    setCompletedTxn(null);
                  }}
                  className="flex-1 py-2.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs uppercase tracking-wider rounded-md transition-colors flex items-center justify-center gap-2"
                >
                  <RotateCw className="w-4 h-4" />
                  Process Another Payment
                </button>
              </div>

            </div>
          )}

        </div>
      </div>
    </div>
  );
};
