import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useAppState } from '../StateContext.tsx';
import { 
  Cloud, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw, 
  Database, 
  X 
} from 'lucide-react';

export const SyncStatusToast: React.FC = () => {
  const { syncState, dismissSyncState } = useAppState();

  if (!syncState) return null;

  const { isOpen, type, actionName, status, errorMessage } = syncState;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          id="sync-status-toast-container"
          initial={{ opacity: 0, y: 50, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 20, scale: 0.95 }}
          transition={{ type: "spring", stiffness: 350, damping: 25 }}
          className="fixed bottom-6 right-6 z-50 w-full max-w-sm px-4 sm:px-0 pointer-events-none"
        >
          <div className="pointer-events-auto relative overflow-hidden bg-slate-950/95 border-2 border-slate-800 text-white p-4 shadow-2xl rounded-xs flex items-start gap-4">
            
            {/* Metallic Brushed Aluminum Grain overlay to match Frame Shop brand */}
            <div className="absolute inset-0 metal-grain opacity-5 pointer-events-none" />

            {/* Visual accent bar indicating progress status */}
            <div 
              className={`absolute bottom-0 left-0 h-1 transition-all duration-300 ${
                status === 'syncing' 
                  ? 'bg-amber-500 w-2/3 animate-pulse' 
                  : status === 'synced' 
                    ? 'bg-emerald-500 w-full' 
                    : 'bg-red-500 w-full'
              }`} 
            />

            {/* Left Icon Area with status-specific styling */}
            <div className="mt-0.5 flex-shrink-0">
              {status === 'syncing' && (
                <div className="relative flex items-center justify-center">
                  <RefreshCw size={20} className="text-amber-500 animate-spin" />
                  <Database size={10} className="absolute text-amber-500/80" />
                </div>
              )}
              {status === 'synced' && (
                <div className="relative flex items-center justify-center p-0.5 bg-emerald-500/10 rounded-full border border-emerald-500/30">
                  <CheckCircle2 size={18} className="text-emerald-400" />
                </div>
              )}
              {status === 'error' && (
                <div className="relative flex items-center justify-center p-0.5 bg-red-500/10 rounded-full border border-red-500/30">
                  <AlertCircle size={18} className="text-red-400" />
                </div>
              )}
            </div>

            {/* Message Area */}
            <div className="flex-1 min-w-0 pr-4">
              <div className="flex items-center gap-1.5 mb-1">
                <span className="font-mono text-[9px] font-black tracking-widest text-slate-400 uppercase">
                  {type === 'build' ? 'Blueprint Pipeline' : type === 'ledger' ? 'Billing Ledger' : 'Customer Registry'}
                </span>
                <span className="text-[9px] font-mono text-slate-600 font-bold">•</span>
                <span className={`font-mono text-[9px] font-black tracking-widest uppercase ${
                  status === 'syncing' 
                    ? 'text-amber-400' 
                    : status === 'synced' 
                      ? 'text-emerald-400' 
                      : 'text-red-400'
                }`}>
                  {status === 'syncing' ? 'Syncing...' : status === 'synced' ? 'Persisted' : 'Error'}
                </span>
              </div>
              
              <p className="text-xs font-semibold text-slate-200 leading-snug truncate">
                {actionName}
              </p>

              <div className="mt-1.5 flex items-center gap-1.5 text-[11px] font-medium text-slate-400">
                <Cloud size={12} className={status === 'synced' ? 'text-emerald-400 animate-pulse' : 'text-slate-500'} />
                <span className="font-sans leading-none">
                  {status === 'syncing' && 'Writing changes to remote ledger...'}
                  {status === 'synced' && 'Data successfully persisted to Firestore.'}
                  {status === 'error' && (errorMessage || 'Sync transaction failed.')}
                </span>
              </div>
            </div>

            {/* Manual Dismiss Button */}
            <button
              id="btn-dismiss-sync-toast"
              onClick={dismissSyncState}
              className="absolute top-3 right-3 text-slate-500 hover:text-slate-300 transition-colors p-0.5 hover:bg-slate-900/60 rounded-xs cursor-pointer"
              title="Dismiss Notification"
            >
              <X size={14} />
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
