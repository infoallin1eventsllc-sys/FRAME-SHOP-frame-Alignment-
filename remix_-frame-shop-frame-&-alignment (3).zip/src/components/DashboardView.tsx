/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo, useState, useEffect } from 'react';
import { useAppState } from '../StateContext';
import { 
  Wrench, 
  Activity, 
  Flame, 
  Sparkles, 
  Settings, 
  Cpu, 
  Hammer, 
  BadgeAlert, 
  CheckSquare, 
  Layers,
  TrendingUp,
  DollarSign,
  CalendarDays,
  Clock,
  AlertTriangle,
  Plus,
  X,
  Trash2
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip as RechartsTooltip,
  Legend,
  Cell,
  PieChart,
  Pie,
  AreaChart,
  Area
} from 'recharts';

interface QuickNote {
  id: string;
  timestamp: string;
  content: string;
  category: 'ALERT' | 'MAINTENANCE' | 'SAFETY' | 'SHIFT_HANDOFF' | 'GENERAL';
  severity: 'LOW' | 'MEDIUM' | 'HIGH';
  station: string;
}

const getPastTimeString = (hoursAgo: number) => {
  const d = new Date();
  d.setHours(d.getHours() - hoursAgo);
  return d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }) + ' - ' + d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
};

const DEFAULT_QUICK_NOTES: QuickNote[] = [
  {
    id: 'note-1',
    timestamp: getPastTimeString(1),
    content: 'Epoxy resin fumes detected near sandblast exhaust. Scrubber unit engaged to 100%.',
    category: 'SAFETY',
    severity: 'HIGH',
    station: 'High-Frequency Sandblast'
  },
  {
    id: 'note-2',
    timestamp: getPastTimeString(3),
    content: 'Completed dial calibration on CNC Lathe spindle. Deflection tolerances are < 0.005mm.',
    category: 'MAINTENANCE',
    severity: 'MEDIUM',
    station: 'Nakamura CNC Lathe'
  },
  {
    id: 'note-3',
    timestamp: getPastTimeString(6),
    content: 'Laser alignment mapping completed for chassis jig. Ready for structural sub-frame weld.',
    category: 'GENERAL',
    severity: 'LOW',
    station: 'Laser Alignment Rig A'
  }
];

export const DashboardView: React.FC = () => {
  const { 
    builds, 
    invoices, 
    clients, 
    setActiveTab, 
    inventory, 
    lowStockThreshold, 
    updateInventoryStock 
  } = useAppState();

  // Quick Notes State
  const [quickNotes, setQuickNotes] = useState<QuickNote[]>(() => {
    const saved = localStorage.getItem('fs_quick_notes');
    return saved ? JSON.parse(saved) : DEFAULT_QUICK_NOTES;
  });

  const [isNoteModalOpen, setIsNoteModalOpen] = useState(false);
  const [noteContent, setNoteContent] = useState('');
  const [noteCategory, setNoteCategory] = useState<'ALERT' | 'MAINTENANCE' | 'SAFETY' | 'SHIFT_HANDOFF' | 'GENERAL'>('GENERAL');
  const [noteSeverity, setNoteSeverity] = useState<'LOW' | 'MEDIUM' | 'HIGH'>('LOW');
  const [noteStation, setNoteStation] = useState('General Shop Floor');
  const [noteSuccess, setNoteSuccess] = useState('');

  useEffect(() => {
    localStorage.setItem('fs_quick_notes', JSON.stringify(quickNotes));
  }, [quickNotes]);

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteContent.trim()) return;

    const newNote: QuickNote = {
      id: `note-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }) + ' - ' + new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      content: noteContent.trim(),
      category: noteCategory,
      severity: noteSeverity,
      station: noteStation
    };

    setQuickNotes(prev => [newNote, ...prev]);
    setNoteContent('');
    setNoteCategory('GENERAL');
    setNoteSeverity('LOW');
    setNoteStation('General Shop Floor');
    
    setNoteSuccess('Shop floor update logged successfully!');
    setTimeout(() => {
      setNoteSuccess('');
      setIsNoteModalOpen(false);
    }, 1200);
  };

  const handleDeleteNote = (id: string) => {
    setQuickNotes(prev => prev.filter(note => note.id !== id));
  };

  const lowStockItems = useMemo(() => {
    return inventory.filter(item => item.stock < lowStockThreshold);
  }, [inventory, lowStockThreshold]);

  const stats = useMemo(() => {
    const totalBuilds = builds.length;
    const activeBuilds = builds.filter(b => b.status === 'IN PROGRESS').length;
    const partsWaitBuilds = builds.filter(b => b.status === 'PARTS WAIT').length;
    const completedBuilds = builds.filter(b => b.status === 'COMPLETED' || b.status === 'DELIVERED').length;
    
    // Live efficiency rate
    const completionPercent = totalBuilds > 0 ? Math.round((completedBuilds / totalBuilds) * 100) : 0;
    
    // Total unpaid outstanding invoices count
    const unpaidCount = invoices.filter(inv => inv.status !== 'PAID').length;

    return {
      totalBuilds,
      activeBuilds,
      partsWaitBuilds,
      completedBuilds,
      completionPercent,
      unpaidCount
    };
  }, [builds, invoices]);

  // Realistic live machine/rig stations
  const stations = [
    { name: 'Laser Alignment Rig A', state: 'Coordinate Mapping', load: 85, color: 'text-primary', status: 'ACTIVE' },
    { name: 'Nakamura CNC Lathe', state: 'Spindle Idle', load: 10, color: 'text-on-surface-variant', status: 'STANDBY' },
    { name: 'Chassis Alignment Jig', state: 'Frame Calibrating', load: 100, color: 'text-primary-container', status: 'LOCKED' },
    { name: 'High-Frequency Sandblast', state: 'Exhaust Purifying', load: 40, color: 'text-secondary', status: 'ACTIVE' },
  ];

  // Recent workshop activities
  const recentActivities = useMemo(() => {
    const list: string[] = [];
    
    // Mix builds and invoices into activities
    builds.filter(b => !b.isArchived).slice(0, 3).forEach(b => {
      list.push(`Work order [${b.id}] for ${b.customerName} is marked raw [${b.status}]`);
    });

    invoices.slice(0, 3).forEach(inv => {
      list.push(`Invoice ${inv.id} generated for ${inv.customerName} | amount $${inv.amount}`);
    });

    // Fallback if none exist
    if (list.length === 0) {
      list.push('No custom transactions recorded in current shop shifts.');
    }

    return list;
  }, [builds, invoices]);

  // Active builds status distribution data
  const buildDistributionData = useMemo(() => {
    const statuses = ['QUEUED', 'IN PROGRESS', 'PARTS WAIT', 'COMPLETED', 'DELIVERED'] as const;
    const colors = {
      QUEUED: '#94a3b8', // Cool Slate
      'IN PROGRESS': '#2563eb', // Royal Blue
      'PARTS WAIT': '#f59e0b', // Amber Warning
      COMPLETED: '#10b981', // Emerald Success
      DELIVERED: '#6366f1', // High-end Indigo
    };
    return statuses.map(st => {
      const count = builds.filter(b => b.status === st).length;
      return {
        name: st,
        count,
        color: colors[st],
      };
    }).filter(item => item.count > 0);
  }, [builds]);

  // Upcoming billing deadlines from PENDING or OVERDUE invoices (Net 30)
  const upcomingInvoices = useMemo(() => {
    return invoices
      .filter(inv => inv.status === 'PENDING' || inv.status === 'OVERDUE')
      .map(inv => {
        let dueDate = 'Net 30';
        let daysRemaining = 30;
        try {
          const dateObj = new Date(inv.date);
          if (!isNaN(dateObj.getTime())) {
            dateObj.setDate(dateObj.getDate() + 30);
            dueDate = dateObj.toLocaleDateString('en-US', {
              month: 'short',
              day: 'numeric',
              year: 'numeric'
            });
            const diffMs = dateObj.getTime() - new Date().getTime();
            daysRemaining = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
          }
        } catch (e) {
          // ignore
        }
        return {
          ...inv,
          dueDate,
          daysRemaining
        };
      })
      .sort((a, b) => a.daysRemaining - b.daysRemaining);
  }, [invoices]);

  // Project valuation breakdown by build status
  const valuationStats = useMemo(() => {
    const totalValuation = builds.reduce((acc, b) => acc + (b.estimatedCost || 0), 0);
    const activeValuation = builds
      .filter(b => b.status === 'IN PROGRESS' || b.status === 'PARTS WAIT' || b.status === 'QUEUED')
      .reduce((acc, b) => acc + (b.estimatedCost || 0), 0);
    const completedValuation = builds
      .filter(b => b.status === 'COMPLETED' || b.status === 'DELIVERED')
      .reduce((acc, b) => acc + (b.estimatedCost || 0), 0);

    return {
      totalValuation,
      activeValuation,
      completedValuation
    };
  }, [builds]);

  // Chart data for project valuation by status
  const valuationChartData = useMemo(() => {
    const statuses = ['QUEUED', 'IN PROGRESS', 'PARTS WAIT', 'COMPLETED', 'DELIVERED'] as const;
    return statuses.map(st => {
      const valuation = builds
        .filter(b => b.status === st)
        .reduce((acc, b) => acc + (b.estimatedCost || 0), 0);
      return {
        status: st,
        Valuation: valuation,
      };
    });
  }, [builds]);

  return (
    <div className="relative z-10 font-sans">
      {/* Header */}
      <div className="border-b border-outline-variant pb-6 mb-12">
        <h2 className="text-4xl md:text-5xl font-bold uppercase tracking-tight text-on-surface font-narrow flex items-center gap-3">
          <Activity className="text-primary-container" />
          SHOP FLOOR MONITOR
        </h2>
        <p className="text-base text-on-surface-variant font-medium mt-1">
          Active machinery cycles, queue efficiencies, and fabricator schedules
        </p>
      </div>

      {/* Grid Quick Numbers */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        {/* Metric 1 */}
        <div className="bg-surface-container border border-outline-variant p-6 relative overflow-hidden">
          <div className="metal-grain absolute inset-0"></div>
          <div className="relative z-10">
            <span className="text-[10px] font-mono text-on-surface-variant uppercase tracking-widest block mb-2">
              ACTIVE FAB QUEUES
            </span>
            <div className="flex justify-between items-end">
              <p className="text-4xl font-bold font-narrow text-primary">{stats.activeBuilds} / {stats.totalBuilds}</p>
              <Hammer className="text-primary-container opacity-85 mb-1" size={24} />
            </div>
            <p className="text-[11px] text-on-surface-variant mt-3 font-mono">
              {stats.partsWaitBuilds} WAITING ON SUPPLIERS
            </p>
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-surface-container border border-outline-variant p-6 relative overflow-hidden">
          <div className="metal-grain absolute inset-0"></div>
          <div className="relative z-10">
            <span className="text-[10px] font-mono text-on-surface-variant uppercase tracking-widest block mb-2">
              WORK EFFICIENCY MTD
            </span>
            <div className="flex justify-between items-end">
              <p className="text-4xl font-bold font-narrow text-emerald-400">{stats.completionPercent}%</p>
              <CheckSquare className="text-emerald-500 opacity-85 mb-1" size={24} />
            </div>
            <p className="text-[11px] text-on-surface-variant mt-3 font-mono">
              {stats.completedBuilds} BUILDS SHIPPED
            </p>
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-surface-container border border-outline-variant p-6 relative overflow-hidden">
          <div className="metal-grain absolute inset-0"></div>
          <div className="relative z-10">
            <span className="text-[10px] font-mono text-on-surface-variant uppercase tracking-widest block mb-2">
              OUTSTANDING LEDGER
            </span>
            <div className="flex justify-between items-end">
              <p className="text-4xl font-bold font-narrow text-[#ffb4ab]">#{stats.unpaidCount}</p>
              <BadgeAlert className="text-red-400 opacity-85 mb-1" size={24} />
            </div>
            <p className="text-[11px] text-on-surface-variant mt-3 font-mono uppercase">
              requires immediate billing follow-ups
            </p>
          </div>
        </div>

        {/* Metric 4 */}
        <div className="bg-surface-container border border-outline-variant p-6 relative overflow-hidden">
          <div className="metal-grain absolute inset-0"></div>
          <div className="relative z-10">
            <span className="text-[10px] font-mono text-on-surface-variant uppercase tracking-widest block mb-2">
              FACILITY TEMPERATURE
            </span>
            <div className="flex justify-between items-end">
              <p className="text-4xl font-bold font-narrow text-primary-container">64.5°F</p>
              <Flame className="text-primary opacity-85 mb-1 animate-pulse" size={24} />
            </div>
            <p className="text-[11px] text-on-surface-variant mt-3 font-mono">
              FUME EXTRACTION SYSTEM ONLINE
            </p>
          </div>
        </div>
      </div>

      {/* LOW STOCK WARNINGS */}
      {lowStockItems.length > 0 ? (
        <div className="mb-12 bg-amber-950/15 border-2 border-amber-500/40 p-6 relative overflow-hidden rounded-xs">
          <div className="metal-grain absolute inset-0 opacity-40 pointer-events-none" />
          <div className="relative z-10">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-amber-500/20 pb-4 mb-4">
              <div className="flex items-center gap-2.5">
                <BadgeAlert className="text-amber-500 animate-pulse" size={24} />
                <div>
                  <h3 className="text-xl font-bold uppercase tracking-wider text-amber-500 font-narrow">
                    INVENTORY DEPLETION WARNINGS
                  </h3>
                  <p className="text-xs text-amber-500/80 font-mono uppercase tracking-wider mt-0.5">
                    {lowStockItems.length} Raw {lowStockItems.length === 1 ? 'Material' : 'Materials'} below pre-set safety threshold ({lowStockThreshold})
                  </p>
                </div>
              </div>
              <button 
                onClick={() => setActiveTab('settings')}
                className="bg-amber-500/20 hover:bg-amber-500/30 text-amber-400 text-xs font-mono font-bold uppercase tracking-wider px-4 py-2 border border-amber-500/30 rounded-xs cursor-pointer transition-all shrink-0"
              >
                Configure Thresholds
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {lowStockItems.map((item) => {
                const progressPct = Math.min(100, Math.round((item.stock / lowStockThreshold) * 100));
                return (
                  <div key={item.id} className="bg-slate-950/90 border border-amber-500/20 p-4 rounded-xs flex flex-col justify-between hover:border-amber-500/40 transition-colors">
                    <div>
                      <div className="flex justify-between items-start gap-2 mb-1">
                        <span className="font-narrow font-bold text-slate-200 text-sm truncate">
                          {item.name}
                        </span>
                        <span className="text-[10px] font-mono text-amber-500 bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded-full font-black uppercase tracking-wider shrink-0 flex items-center gap-1">
                          <AlertTriangle size={10} />
                          ALERT
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-500 font-mono uppercase">
                        Current: <strong className="text-amber-500">{item.stock}</strong> / {lowStockThreshold} {item.unitType}
                      </p>

                      <div className="mt-3">
                        <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden border border-slate-950">
                          <div 
                            style={{ width: `${progressPct}%` }}
                            className="h-full rounded-full bg-amber-500 transition-all duration-300"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between gap-2 mt-4 pt-3 border-t border-slate-900">
                      <span className="font-mono text-[9px] text-slate-500 uppercase">
                        Unit: {item.unitType}
                      </span>
                      <button
                        onClick={() => updateInventoryStock(item.id, item.stock + 10)}
                        className="bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 font-mono text-[10px] font-bold uppercase px-2.5 py-1.5 border border-emerald-500/20 rounded-xs cursor-pointer transition-colors"
                      >
                        +10 Restock
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      ) : (
        <div className="mb-12 bg-emerald-950/10 border border-emerald-500/20 p-4 relative overflow-hidden rounded-xs">
          <div className="metal-grain absolute inset-0 opacity-20 pointer-events-none" />
          <div className="relative z-10 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div className="flex items-center gap-2.5">
              <CheckSquare className="text-emerald-400" size={18} />
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-emerald-400 font-narrow">
                  ALL RAW MATERIALS FULLY SUPPLIED
                </p>
                <p className="text-[10px] text-slate-400 font-mono uppercase mt-0.5">
                  All {inventory.length} tracked materials are above the pre-set safety threshold ({lowStockThreshold})
                </p>
              </div>
            </div>
            <button 
              onClick={() => setActiveTab('settings')}
              className="text-emerald-400 hover:text-white font-mono text-[10px] font-bold uppercase tracking-wider px-3 py-1.5 border border-emerald-500/20 hover:border-emerald-500/50 bg-emerald-500/5 rounded-xs cursor-pointer transition-all shrink-0"
            >
              Adjust Settings
            </button>
          </div>
        </div>
      )}

      {/* QUICK STATS & BLUEPRINT ANALYTICS */}
      <div className="bg-surface-container border border-outline-variant p-6 md:p-8 relative overflow-hidden mb-12">
        <div className="metal-grain absolute inset-0"></div>
        <div className="relative z-10">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-outline-variant/60 pb-4 mb-6 gap-4">
            <div>
              <h3 className="text-xl font-bold uppercase tracking-wider text-primary font-narrow flex items-center gap-2">
                <TrendingUp size={20} className="text-primary" />
                QUICK STATS & BLUEPRINT ANALYTICS
              </h3>
              <p className="text-xs text-on-surface-variant font-mono uppercase mt-1">
                Project pipeline volume, valuations, and settling balances
              </p>
            </div>
            
            <div className="flex flex-wrap gap-4 font-mono text-xs">
              <div className="bg-background/50 border border-outline-variant/50 px-3 py-1.5 rounded-sm">
                <span className="text-on-surface-variant mr-1.5 uppercase">TOTAL PORTFOLIO:</span>
                <span className="text-primary font-bold">${valuationStats.totalValuation.toLocaleString()}</span>
              </div>
              <div className="bg-background/50 border border-outline-variant/50 px-3 py-1.5 rounded-sm">
                <span className="text-on-surface-variant mr-1.5 uppercase">ACTIVE PIPELINE:</span>
                <span className="text-amber-500 font-bold">${valuationStats.activeValuation.toLocaleString()}</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Left: Active Build Distribution & Project Valuations (Recharts) */}
            <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Build status distribution */}
              <div className="bg-background/40 border border-outline-variant/40 p-4 flex flex-col h-[280px] rounded-xs">
                <div className="flex justify-between items-center mb-3">
                  <span className="text-[11px] font-mono text-on-surface-variant uppercase tracking-wider font-bold flex items-center gap-1.5">
                    <Clock size={12} className="text-primary" />
                    BUILD ORDER STATS
                  </span>
                  <span className="text-[10px] font-mono bg-primary/10 text-primary px-2 py-0.5 rounded-sm">
                    {builds.length} Total Builds
                  </span>
                </div>
                
                <div className="flex-1 min-h-0">
                  {buildDistributionData.length > 0 ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={buildDistributionData} margin={{ top: 10, right: 10, left: -25, bottom: 5 }}>
                        <XAxis dataKey="name" stroke="#475569" fontSize={9} tickLine={false} />
                        <YAxis stroke="#475569" fontSize={9} tickLine={false} />
                        <RechartsTooltip
                          cursor={{ fill: 'rgba(37, 99, 235, 0.05)' }}
                          content={({ active, payload }) => {
                            if (active && payload && payload.length) {
                              const data = payload[0].payload;
                              return (
                                <div className="bg-surface border border-outline-variant p-2 shadow-md font-mono text-[10px] rounded-sm">
                                  <p className="font-bold text-on-surface uppercase mb-0.5">{data.name}</p>
                                  <p className="text-primary font-bold">Builds: {data.count}</p>
                                </div>
                              );
                            }
                            return null;
                          }}
                        />
                        <Bar dataKey="count" radius={[2, 2, 0, 0]}>
                          {buildDistributionData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="h-full flex items-center justify-center text-xs font-mono text-on-surface-variant">
                      No build orders recorded.
                    </div>
                  )}
                </div>
              </div>

              {/* Valuation Tied in each phase */}
              <div className="bg-background/40 border border-outline-variant/40 p-4 flex flex-col h-[280px] rounded-xs">
                <div className="flex justify-between items-center mb-3">
                  <span className="text-[11px] font-mono text-on-surface-variant uppercase tracking-wider font-bold flex items-center gap-1.5">
                    <DollarSign size={12} className="text-emerald-500" />
                    VALUATION BY STATUS
                  </span>
                  <span className="text-[10px] font-mono bg-emerald-500/10 text-emerald-500 px-2 py-0.5 rounded-sm">
                    Est. Value
                  </span>
                </div>

                <div className="flex-1 min-h-0">
                  {builds.length > 0 ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={valuationChartData} margin={{ top: 10, right: 10, left: -10, bottom: 5 }}>
                        <defs>
                          <linearGradient id="valGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#2563eb" stopOpacity={0.3} />
                            <stop offset="95%" stopColor="#2563eb" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <XAxis dataKey="status" stroke="#475569" fontSize={9} tickLine={false} />
                        <YAxis stroke="#475569" fontSize={9} tickLine={false} tickFormatter={(v) => `$${v}`} />
                        <RechartsTooltip
                          content={({ active, payload }) => {
                            if (active && payload && payload.length) {
                              return (
                                <div className="bg-surface border border-outline-variant p-2 shadow-md font-mono text-[10px] rounded-sm">
                                  <p className="font-bold text-on-surface uppercase mb-0.5">{payload[0].payload.status}</p>
                                  <p className="text-primary font-bold">Valuation: ${payload[0].value?.toLocaleString()}</p>
                                </div>
                              );
                            }
                            return null;
                          }}
                        />
                        <Area type="monotone" dataKey="Valuation" stroke="#2563eb" strokeWidth={1.5} fillOpacity={1} fill="url(#valGrad)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="h-full flex items-center justify-center text-xs font-mono text-on-surface-variant">
                      No valuation metrics available.
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Right: Upcoming Billing Deadlines & Unpaid Cash Volume */}
            <div className="lg:col-span-4 bg-background/25 border border-outline-variant/40 p-4 flex flex-col h-[280px] rounded-xs">
              <div className="flex justify-between items-center mb-3">
                <span className="text-[11px] font-mono text-on-surface-variant uppercase tracking-wider font-bold flex items-center gap-1.5">
                  <CalendarDays size={12} className="text-red-400" />
                  UPCOMING BILLING DEADLINES
                </span>
                <span className="text-[10px] font-mono bg-red-400/10 text-red-400 px-2 py-0.5 rounded-sm font-bold">
                  Net 30
                </span>
              </div>

              <div className="flex-1 overflow-y-auto custom-scrollbar space-y-2.5 pr-1">
                {upcomingInvoices.length > 0 ? (
                  upcomingInvoices.map((inv) => (
                    <div key={inv.id} className="bg-background/60 border border-outline-variant/30 p-2.5 flex justify-between items-center rounded-xs hover:border-primary/40 transition-colors">
                      <div className="min-w-0 flex-1 mr-2">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-mono text-[10px] text-on-surface-variant font-bold uppercase">{inv.id}</span>
                          <span className={`text-[9px] font-mono px-1 py-0.2 rounded-xs font-semibold ${
                            inv.status === 'OVERDUE' ? 'bg-red-400/10 text-red-400' : 'bg-amber-500/10 text-amber-500'
                          }`}>
                            {inv.status}
                          </span>
                        </div>
                        <p className="text-[11px] font-semibold text-on-surface truncate mt-0.5">{inv.customerName}</p>
                        <p className="text-[10px] text-on-surface-variant font-mono truncate">{inv.project}</p>
                      </div>
                      <div className="text-right shrink-0">
                        <p className="text-xs font-bold text-on-surface font-mono">${inv.amount.toLocaleString()}</p>
                        <p className={`text-[9px] font-mono mt-0.5 font-semibold ${
                          inv.daysRemaining <= 5 ? 'text-red-400 font-bold' : 'text-on-surface-variant'
                        }`}>
                          {inv.daysRemaining <= 0 ? 'Overdue!' : `Due in ${inv.daysRemaining}d`}
                        </p>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-xs font-mono text-on-surface-variant">
                    <CheckSquare size={24} className="text-emerald-500 mb-2 opacity-80" />
                    <span>All client balances settled.</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left: Active Machinery and Stations load */}
        <div className="lg:col-span-7 bg-surface-container border border-outline-variant relative p-6 md:p-8">
          <div className="metal-grain absolute inset-0"></div>
          <div className="relative z-10">
            <h3 className="text-xl font-bold uppercase tracking-wider text-primary font-narrow mb-6 flex items-center gap-2">
              <Cpu className="text-primary-container" size={18} />
              LIVE MACHINERY STATIONS
            </h3>

            <div className="space-y-6">
              {stations.map((st, idx) => (
                <div key={idx} className="bg-background/40 border border-outline-variant/30 p-4 rounded-xs">
                  <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center gap-2">
                      <span className={`w-2.5 h-2.5 rounded-full bg-primary-container ${
                        st.status === 'ACTIVE' || st.status === 'LOCKED' ? 'animate-ping' : ''
                      }`} />
                      <p className="text-sm font-semibold text-on-surface">{st.name}</p>
                    </div>
                    <span className="text-[10px] font-mono font-bold bg-secondary/15 px-2 py-0.5 text-secondary tracking-wider uppercase border border-secondary/25">
                      {st.status}
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-xs text-on-surface-variant font-mono">
                    <span>Task: {st.state}</span>
                    <span>Load: {st.load}%</span>
                  </div>
                  <div className="mt-3 h-2.5 bg-surface-container-highest overflow-hidden">
                    <div 
                      className="h-full bg-primary-container transition-all duration-300" 
                      style={{ width: `${st.load}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Recent Shop Floor activities log & Quick Notes */}
        <div className="lg:col-span-5 bg-surface-container border border-outline-variant relative p-6 md:p-8">
          <div className="metal-grain absolute inset-0"></div>
          <div className="relative z-10">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold uppercase tracking-wider text-primary font-narrow flex items-center gap-2">
                <Settings size={18} className="animate-spin-slow" />
                SHIFT TELEMETRY LOGS
              </h3>
              <button 
                onClick={() => setIsNoteModalOpen(true)}
                className="text-[10px] font-mono font-bold tracking-widest text-primary border border-primary/20 bg-primary/5 hover:bg-primary/10 px-2 py-1 rounded-sm cursor-pointer transition-all uppercase"
                title="Log note"
              >
                + LOG NOTE
              </button>
            </div>

            <div className="space-y-4 max-h-[380px] overflow-y-auto custom-scrollbar pr-1">
              {/* Custom Quick Notes */}
              {quickNotes.map((note) => {
                const severityStyles = {
                  HIGH: {
                    border: 'border-l-4 border-l-red-500',
                    bg: 'bg-red-500/5',
                    badge: 'bg-red-500/10 text-red-600 border border-red-500/20',
                    text: 'text-red-700'
                  },
                  MEDIUM: {
                    border: 'border-l-4 border-l-amber-500',
                    bg: 'bg-amber-500/5',
                    badge: 'bg-amber-500/10 text-amber-600 border border-amber-500/20',
                    text: 'text-amber-700'
                  },
                  LOW: {
                    border: 'border-l-4 border-l-blue-500',
                    bg: 'bg-blue-500/5',
                    badge: 'bg-blue-500/10 text-blue-600 border border-blue-500/20',
                    text: 'text-blue-700'
                  }
                }[note.severity] || {
                  border: 'border-l-2 border-l-slate-400',
                  bg: 'bg-slate-500/5',
                  badge: 'bg-slate-500/10 text-slate-600 border border-slate-500/20',
                  text: 'text-slate-600'
                };

                const categoryEmoji = {
                  SAFETY: '⚠️ SAFETY',
                  MAINTENANCE: '🔧 MAINT',
                  ALERT: '🚨 ALERT',
                  SHIFT_HANDOFF: '📋 HANDOFF',
                  GENERAL: '💬 UPDATE'
                }[note.category] || '💬 LOG';

                return (
                  <div 
                    key={note.id} 
                    className={`p-3 relative rounded-xs transition-all hover:shadow-xs flex items-start gap-3 text-xs text-on-surface ${severityStyles.border} ${severityStyles.bg} border border-outline-variant/40 group`}
                  >
                    <div className="flex-1 space-y-1.5">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`text-[9px] font-mono font-black uppercase tracking-wider px-2 py-0.5 rounded-sm ${severityStyles.badge}`}>
                          {categoryEmoji}
                        </span>
                        <span className="text-[10px] font-mono text-on-surface-variant font-bold bg-slate-100 border border-slate-200 px-1.5 py-0.5 rounded-sm">
                          {note.station}
                        </span>
                        <span className="text-[9px] font-mono text-on-surface-variant/70 italic ml-auto mr-5">
                          {note.timestamp}
                        </span>
                      </div>
                      <p className="leading-relaxed font-medium text-on-surface pr-4">{note.content}</p>
                      <p className="text-[9px] font-mono text-on-surface-variant uppercase tracking-wider">
                        Shop Floor log | active session shift
                      </p>
                    </div>
                    
                    {/* Delete button */}
                    <button
                      onClick={() => handleDeleteNote(note.id)}
                      className="absolute top-2.5 right-2.5 p-1 text-on-surface-variant hover:text-red-500 hover:bg-red-500/10 rounded-sm transition-all opacity-0 group-hover:opacity-100 focus:opacity-100 cursor-pointer"
                      title="Archive & Resolve Update"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                );
              })}
              
              {/* Divider if we have custom quick notes and recentActivities */}
              {quickNotes.length > 0 && (
                <div className="flex items-center gap-2 my-2 py-1">
                  <span className="text-[9px] font-mono uppercase text-on-surface-variant tracking-wider whitespace-nowrap">SYSTEM SHIFT EVENTS</span>
                  <div className="flex-1 border-t border-outline-variant/40"></div>
                </div>
              )}

              {recentActivities.map((act, id) => (
                <div key={id} className="bg-background/25 border-l-2 border-primary p-3.5 flex gap-3 text-xs text-on-surface">
                  <div className="flex-1 space-y-1">
                    <p className="leading-relaxed ">{act}</p>
                    <p className="text-[10px] font-mono text-on-surface-variant uppercase">
                      Shift Log entry #{id + 104} | verified by foreman
                    </p>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-8 pt-6 border-t border-outline-variant/60">
              <h4 className="text-xs font-mono text-primary uppercase tracking-widest font-bold mb-3 block">
                SHOP DISPATCH COMMANDS
              </h4>
              <div className="grid grid-cols-2 gap-3">
                <button 
                  onClick={() => setActiveTab('builds')}
                  className="bg-primary-container hover:opacity-90 text-on-primary-container py-3 text-center text-xs font-bold tracking-wider uppercase cursor-pointer"
                >
                  DISPATCH BUILD
                </button>
                <button 
                  onClick={() => setActiveTab('billing')}
                  className="bg-surface-container-highest hover:bg-surface-container border border-outline py-3 text-center text-xs font-bold text-on-surface tracking-wider uppercase cursor-pointer"
                >
                  INSPECT LEDGER
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Floating Action Button (FAB) */}
      <button
        id="fab-quick-note"
        onClick={() => setIsNoteModalOpen(true)}
        className="fixed bottom-6 right-6 z-40 bg-primary hover:bg-blue-700 active:scale-95 text-white rounded-full p-4 shadow-xl hover:scale-105 transition-all flex items-center justify-center gap-2 border border-primary/20 cursor-pointer group animate-bounce-subtle"
        title="Log fast shop floor update or alert"
      >
        <Activity size={22} className="group-hover:animate-pulse" />
        <span className="max-w-0 overflow-hidden group-hover:max-w-[120px] transition-all duration-300 ease-out font-mono text-xs font-bold uppercase tracking-wider whitespace-nowrap">
          Quick Note
        </span>
      </button>

      {/* Quick Note / Alert Modal */}
      {isNoteModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-surface border-2 border-outline-variant w-full max-w-lg shadow-2xl relative rounded-xs font-sans overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="metal-grain absolute inset-0 opacity-10 pointer-events-none" />
            
            {/* Modal Header */}
            <div className="bg-slate-900 text-slate-100 p-5 border-b border-outline-variant relative z-10 flex justify-between items-center">
              <div>
                <h3 className="text-lg font-bold uppercase tracking-wider font-narrow flex items-center gap-2 text-primary">
                  <Activity size={18} className="text-primary animate-pulse" />
                  LOG SHOP FLOOR UPDATE / ALERT
                </h3>
                <p className="text-[11px] text-slate-400 font-mono uppercase mt-1">
                  Active Shift Telemetry dispatch and incident logger
                </p>
              </div>
              <button 
                onClick={() => {
                  setIsNoteModalOpen(false);
                  setNoteSuccess('');
                }}
                className="p-1 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xs transition-colors cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Modal Body */}
            <form onSubmit={handleAddNote} className="p-6 space-y-5 relative z-10">
              
              {noteSuccess && (
                <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 text-xs font-mono rounded-xs flex items-center gap-2">
                  <CheckSquare size={14} className="text-emerald-500" />
                  <span>{noteSuccess}</span>
                </div>
              )}

              {/* Note Content Textarea */}
              <div className="space-y-1.5">
                <label className="block text-[10px] font-mono font-bold uppercase tracking-wider text-on-surface-variant">
                  Update / Alert Content <span className="text-red-500">*</span>
                </label>
                <textarea
                  id="note-content-input"
                  required
                  rows={3}
                  value={noteContent}
                  onChange={(e) => setNoteContent(e.target.value)}
                  placeholder="Describe the shop floor observation, machine calibration alert, safety hazard, or shift handoff log..."
                  className="w-full bg-background border border-outline-variant p-3 text-xs text-on-surface rounded-xs focus:outline-none focus:border-primary font-sans leading-relaxed resize-none"
                />
              </div>

              {/* Grid: Category & Severity */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {/* Category Selection */}
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-mono font-bold uppercase tracking-wider text-on-surface-variant">
                    Category
                  </label>
                  <select
                    id="note-category-select"
                    value={noteCategory}
                    onChange={(e) => setNoteCategory(e.target.value as any)}
                    className="w-full bg-background border border-outline-variant p-2.5 text-xs text-on-surface rounded-xs focus:outline-none focus:border-primary font-mono"
                  >
                    <option value="GENERAL">💬 GENERAL UPDATE</option>
                    <option value="ALERT">🚨 SYSTEM ALERT</option>
                    <option value="MAINTENANCE">🔧 MAINTENANCE</option>
                    <option value="SAFETY">⚠️ SAFETY WARNING</option>
                    <option value="SHIFT_HANDOFF">📋 SHIFT HANDOFF</option>
                  </select>
                </div>

                {/* Station Selection */}
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-mono font-bold uppercase tracking-wider text-on-surface-variant">
                    Machinery / Station
                  </label>
                  <select
                    id="note-station-select"
                    value={noteStation}
                    onChange={(e) => setNoteStation(e.target.value)}
                    className="w-full bg-background border border-outline-variant p-2.5 text-xs text-on-surface rounded-xs focus:outline-none focus:border-primary font-mono"
                  >
                    <option value="General Shop Floor">General Shop Floor</option>
                    <option value="Laser Alignment Rig A">Laser Alignment Rig A</option>
                    <option value="Nakamura CNC Lathe">Nakamura CNC Lathe</option>
                    <option value="Chassis Alignment Jig">Chassis Alignment Jig</option>
                    <option value="High-Frequency Sandblast">High-Frequency Sandblast</option>
                  </select>
                </div>

              </div>

              {/* Severity Button Group */}
              <div className="space-y-2">
                <label className="block text-[10px] font-mono font-bold uppercase tracking-wider text-on-surface-variant">
                  Severity & Priority Level
                </label>
                <div className="grid grid-cols-3 gap-2.5">
                  {(['LOW', 'MEDIUM', 'HIGH'] as const).map((sev) => {
                    const isSelected = noteSeverity === sev;
                    const styles = {
                      LOW: isSelected 
                        ? 'bg-blue-600 text-white border-blue-600 shadow-sm' 
                        : 'bg-blue-500/5 text-blue-600 hover:bg-blue-500/10 border-blue-500/20',
                      MEDIUM: isSelected 
                        ? 'bg-amber-600 text-white border-amber-600 shadow-sm' 
                        : 'bg-amber-500/5 text-amber-600 hover:bg-amber-500/10 border-amber-500/20',
                      HIGH: isSelected 
                        ? 'bg-red-600 text-white border-red-600 shadow-sm' 
                        : 'bg-red-500/5 text-red-600 hover:bg-red-500/10 border-red-500/20',
                    }[sev];
                    
                    return (
                      <button
                        key={sev}
                        id={`btn-sev-${sev.toLowerCase()}`}
                        type="button"
                        onClick={() => setNoteSeverity(sev)}
                        className={`py-2 text-center text-xs font-bold font-mono border rounded-xs transition-all uppercase cursor-pointer ${styles}`}
                      >
                        {sev}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Modal Footer Actions */}
              <div className="flex justify-end gap-3 pt-4 border-t border-outline-variant/60">
                <button
                  id="btn-cancel-note"
                  type="button"
                  onClick={() => {
                    setIsNoteModalOpen(false);
                    setNoteSuccess('');
                  }}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-mono font-bold uppercase tracking-wider rounded-xs border border-slate-200 cursor-pointer transition-colors"
                >
                  DISCARD
                </button>
                <button
                  id="btn-submit-note"
                  type="submit"
                  className="px-5 py-2 bg-primary hover:bg-blue-700 text-white text-xs font-mono font-bold uppercase tracking-wider rounded-xs cursor-pointer transition-colors"
                >
                  LOG TO TELEMETRY
                </button>
              </div>

            </form>
          </div>
        </div>
      )}
    </div>
  );
};
