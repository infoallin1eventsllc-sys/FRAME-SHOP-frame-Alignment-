/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { useAppState } from '../StateContext';
import { Client, ClientStatus } from '../types';
import { 
  Users, 
  Search, 
  Plus, 
  Mail, 
  Phone, 
  Briefcase, 
  Coins, 
  Bookmark, 
  Wrench,
  Trash2,
  X,
  FileSpreadsheet,
  Download,
  CreditCard
} from 'lucide-react';
import { ClientDistributionMap } from './ClientDistributionMap';
import { exportClientsToExcel } from '../lib/excel';
import { ExcelConnectorModal } from './ExcelConnectorModal';
import { CardTransactionModal } from './CardTransactionModal';

export const ClientsView: React.FC = () => {
  const { clients, invoices, builds, addClient, deleteClient, globalSearchQuery, setGlobalSearchQuery } = useAppState();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedClient, setSelectedClient] = useState<Client | null>(clients[0] || null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isExcelModalOpen, setIsExcelModalOpen] = useState(false);

  // Card Terminal state
  const [isCardTerminalOpen, setIsCardTerminalOpen] = useState(false);
  const [terminalCustomerId, setTerminalCustomerId] = useState('');
  const [terminalAmount, setTerminalAmount] = useState<number | undefined>(undefined);

  // New client form states
  const [clientName, setClientName] = useState('');
  const [clientEmail, setClientEmail] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [clientCompany, setClientCompany] = useState('');
  const [clientNotes, setClientNotes] = useState('');
  const [clientRegion, setClientRegion] = useState('west');

  // Filtering
  const filteredClients = useMemo(() => {
    const localQuery = searchTerm.toLowerCase().trim();
    const globalQuery = globalSearchQuery.toLowerCase().trim();
    return clients.filter(c => {
      const matchesLocal = !localQuery || 
        c.id.toLowerCase().includes(localQuery) ||
        c.name.toLowerCase().includes(localQuery) ||
        c.company.toLowerCase().includes(localQuery) ||
        (c.email && c.email.toLowerCase().includes(localQuery));
        
      const matchesGlobal = !globalQuery || 
        c.id.toLowerCase().includes(globalQuery) ||
        c.name.toLowerCase().includes(globalQuery) ||
        c.company.toLowerCase().includes(globalQuery) ||
        (c.email && c.email.toLowerCase().includes(globalQuery));
        
      return matchesLocal && matchesGlobal;
    });
  }, [clients, searchTerm, globalSearchQuery]);

  // Handle selected client fallback
  const currentDetails = useMemo(() => {
    if (!selectedClient) return null;
    // Find the latest state for this client in outer clients array (since stats recalculate)
    return clients.find(c => c.id === selectedClient.id) || selectedClient;
  }, [selectedClient, clients]);

  // Find invoices & builds for selected client
  const clientInvoices = useMemo(() => {
    if (!currentDetails) return [];
    return invoices.filter(inv => inv.customerId === currentDetails.id);
  }, [currentDetails, invoices]);

  const clientBuilds = useMemo(() => {
    if (!currentDetails) return [];
    return builds.filter(b => b.customerId === currentDetails.id);
  }, [currentDetails, builds]);

  const handleAddNewClient = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientName) return;

    // Get initials for custom avatar
    const initials = clientName
      .split(' ')
      .map(part => part[0])
      .join('')
      .slice(0, 2)
      .toUpperCase() || 'CX';

    const finalNotes = clientNotes 
      ? `${clientNotes}\n\n[Region: ${clientRegion}]` 
      : `No custom preferences loaded yet.\n\n[Region: ${clientRegion}]`;

    addClient({
      name: clientName,
      email: clientEmail || 'n/a',
      phone: clientPhone || 'n/a',
      company: clientCompany || 'Individual',
      avatar: initials,
      notes: finalNotes,
      status: 'ACTIVE'
    });

    // Reset forms
    setClientName('');
    setClientEmail('');
    setClientPhone('');
    setClientCompany('');
    setClientNotes('');
    setClientRegion('west');
    setIsModalOpen(false);
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    deleteClient(id);
    if (selectedClient?.id === id) {
      setSelectedClient(clients[0] || null);
    }
  };

  return (
    <div className="relative z-10 font-sans">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 mb-12">
        <div>
          <h2 className="text-4xl md:text-5xl font-bold uppercase tracking-tight text-on-surface font-narrow">
            Client Directory
          </h2>
          <p className="text-base text-on-surface-variant font-medium mt-1">
            Registered riders and specialty custom builders
          </p>
        </div>
        <div className="flex items-center gap-3 w-full md:w-auto">
          <button 
            id="btn-excel-clients"
            onClick={() => setIsExcelModalOpen(true)}
            className="flex-1 md:flex-none bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-5 py-3 font-semibold text-xs tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-all cursor-pointer rounded-sm"
          >
            <FileSpreadsheet size={16} />
            EXCEL HUB
          </button>
          <button 
            id="btn-export-clients-excel"
            onClick={() => exportClientsToExcel(clients)}
            className="flex-1 md:flex-none border border-outline-variant hover:bg-surface-container-highest text-on-surface px-5 py-3 font-semibold text-xs tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-all cursor-pointer rounded-sm"
            title="Download Clients Directory as Excel file"
          >
            <Download size={16} />
            EXPORT EXCEL
          </button>
          <button 
            id="btn-add-client"
            onClick={() => setIsModalOpen(true)}
            className="flex-1 md:flex-none bg-primary-container hover:opacity-90 text-white px-6 py-3 font-semibold text-xs tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-all cursor-pointer rounded-sm"
          >
            <Plus size={16} />
            REGISTER CLIENT
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left: Clients List */}
        <div className="lg:col-span-5 bg-surface-container border border-outline-variant p-4">
          <div className="mb-4 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant" size={16} />
            <input 
              type="text"
              placeholder="Filter clients by name, company..."
              className="w-full bg-background border-none focus:outline-none focus:ring-1 focus:ring-primary-container text-on-surface pl-10 pr-4 py-2 text-xs"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          {globalSearchQuery && (
            <div className="mb-4 px-3 py-2 bg-primary/10 border border-primary/20 text-primary rounded-sm flex items-center justify-between text-[11px] font-mono">
              <span className="truncate">Top Filter: "{globalSearchQuery}"</span>
              <button 
                onClick={() => setGlobalSearchQuery('')}
                className="text-red-400 hover:text-red-300 font-bold uppercase tracking-wider ml-2 cursor-pointer transition-colors"
              >
                Clear
              </button>
            </div>
          )}

          <div className="space-y-2 max-h-[500px] overflow-y-auto custom-scrollbar pr-1">
            {filteredClients.length > 0 ? (
              filteredClients.map((c) => (
                <div
                  key={c.id}
                  onClick={() => setSelectedClient(c)}
                  className={`p-3.5 border transition-all cursor-pointer flex justify-between items-center group relative ${
                    currentDetails?.id === c.id 
                      ? 'bg-primary/10 border-primary' 
                      : 'bg-surface border-outline-variant/40 hover:border-outline-variant'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-primary/20 border border-outline-variant/60 flex items-center justify-center text-primary font-bold text-xs" style={{minWidth: '40px'}}>
                      {c.avatar}
                    </div>
                    <div>
                      <h4 className="text-sm font-semibold text-on-surface">{c.name}</h4>
                      <p className="text-[11px] font-mono text-on-surface-variant uppercase tracking-wider uppercase">
                        {c.company || 'Private Owner'}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono text-on-surface-variant font-bold pr-2">
                      ${c.outstandingBalance > 0 ? c.outstandingBalance : 0}
                    </span>
                    <button
                      onClick={(e) => handleDelete(c.id, e)}
                      className="text-on-surface-variant hover:text-red-400 opacity-0 group-hover:opacity-100 p-1 rounded hover:bg-black/20 transition-all"
                      title="De-register Client"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-xs text-on-surface-variant text-center py-8 italic">
                No fabricator accounts match your search.
              </p>
            )}
          </div>
        </div>

        {/* Right: Client Details */}
        <div className="lg:col-span-7 bg-surface-container border border-outline-variant relative min-h-[580px]">
          <div className="metal-grain absolute inset-0"></div>

          {currentDetails ? (
            <div className="relative z-10 p-6 md:p-8 space-y-8">
              {/* Profile Card Summary */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-outline-variant pb-6 gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-primary/20 border border-outline flex items-center justify-center text-primary font-mono text-xl font-bold">
                    {currentDetails.avatar}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-on-surface">{currentDetails.name}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs text-on-surface-variant flex items-center gap-1">
                        <Briefcase size={12} />
                        {currentDetails.company || 'Private Rider'}
                      </span>
                      <span className="bg-secondary-container text-secondary text-[10px] px-2 py-0.5 font-bold tracking-wider rounded-xs border border-secondary/40">
                        {currentDetails.status}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="text-left sm:text-right font-mono">
                  <p className="text-[10px] text-on-surface-variant uppercase tracking-wider">Account ID</p>
                  <p className="text-sm text-primary font-bold">{currentDetails.id}</p>
                </div>
              </div>

              {/* Grid Contact Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-background/50 border border-outline-variant/40 p-4 rounded-xs">
                  <p className="text-[10px] font-mono text-on-surface-variant uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <Mail size={12} className="text-primary-container" /> EMAIL WORK ADDRESS
                  </p>
                  <p className="text-sm font-mono text-on-surface truncate break-all selection:bg-purple-800">
                    {currentDetails.email}
                  </p>
                </div>
                <div className="bg-background/50 border border-outline-variant/40 p-4 rounded-xs">
                  <p className="text-[10px] font-mono text-on-surface-variant uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <Phone size={12} className="text-primary-container" /> SECURE MOBILE
                  </p>
                  <p className="text-sm font-mono text-on-surface">
                    {currentDetails.phone}
                  </p>
                </div>
              </div>

              {/* Balances block */}
              <div className="grid grid-cols-2 gap-4 border-t border-b border-outline-variant py-6">
                <div>
                  <p className="text-[10px] font-mono text-on-surface-variant uppercase tracking-wider flex items-center gap-1.5">
                    <Coins size={12} className="text-red-400" /> OUTSTANDING BAL.
                  </p>
                  <p className="text-2xl font-bold font-narrow text-primary mt-1">
                    ${currentDetails.outstandingBalance?.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </p>
                  <button
                    onClick={() => {
                      setTerminalCustomerId(currentDetails.id);
                      setTerminalAmount(currentDetails.outstandingBalance > 0 ? currentDetails.outstandingBalance : undefined);
                      setIsCardTerminalOpen(true);
                    }}
                    className="mt-3 text-[11px] font-bold font-mono px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded uppercase tracking-wider flex items-center gap-1.5 transition-all shadow cursor-pointer"
                  >
                    <CreditCard size={13} />
                    CHARGE CARD (DEBIT / CREDIT)
                  </button>
                </div>
                <div>
                  <p className="text-[10px] font-mono text-on-surface-variant uppercase tracking-wider flex items-center gap-1.5">
                    <Coins size={12} className="text-emerald-500" /> LIFETIME SPEND
                  </p>
                  <p className="text-2xl font-bold font-narrow text-emerald-600 mt-1">
                    ${currentDetails.lifetimeSpend?.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </p>
                </div>
              </div>

              {/* Grease-monkey requirements notes */}
              <div className="bg-background/40 border border-secondary/20 p-5 rounded-xs relative">
                <div className="absolute right-4 top-4">
                  <Wrench size={16} className="text-primary/70 animate-spin-slow" />
                </div>
                <h4 className="text-xs font-mono uppercase tracking-wider text-primary font-bold mb-2 flex items-center gap-1.5">
                  <Bookmark size={12} /> SPECIALTY METALLURGY NOTES
                </h4>
                <p className="text-xs text-on-surface-variant leading-relaxed italic">
                  "{currentDetails.notes}"
                </p>
              </div>

              {/* Connected Active builds lists */}
              <div className="space-y-4">
                <h4 className="text-xs font-mono uppercase tracking-widest text-primary font-bold">
                  CONNECTED ACTIVE PROJECTS ({clientBuilds.length})
                </h4>
                {clientBuilds.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {clientBuilds.map(b => (
                      <div key={b.id} className="bg-background/80 p-3 border border-outline-variant/30 rounded-xs flex flex-col justify-between">
                        <div>
                          <p className="text-xs font-semibold text-on-surface">{b.name}</p>
                          <p className="text-[10px] font-mono text-on-surface-variant uppercase">{b.type}</p>
                        </div>
                        <div className="flex justify-between items-center mt-3">
                          <span className="text-[9px] font-mono font-bold bg-primary/10 text-primary px-1.5 py-0.5 uppercase tracking-wider">
                            {b.status}
                          </span>
                          <span className="text-[10px] font-mono text-primary">${b.estimatedCost}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-on-surface-variant italic font-light">No custom parts listed yet.</p>
                )}
              </div>
            </div>
          ) : (
            <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-on-surface-variant">
              <Users size={32} className="stroke-1 mb-2" />
              <p className="text-sm italic">De-registered or empty clients registry.</p>
            </div>
          )}
        </div>
      </div>

      {/* Client Distribution Map Visualization */}
      <ClientDistributionMap 
        onSelectClient={(c) => {
          setSelectedClient(c);
          // Scroll details into view on mobile
          const detailsContainer = document.getElementById('client-distribution-map-card');
          if (detailsContainer) {
            detailsContainer.scrollIntoView({ behavior: 'smooth' });
          }
        }} 
        selectedClientId={currentDetails?.id} 
      />

      {/* Register Client Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4 backdrop-blur-xs">
          <div className="bg-surface border-2 border-outline w-full max-w-lg shadow-2xl relative">
            <div className="metal-grain absolute inset-0"></div>
            
            <div className="relative z-10 p-6">
              {/* Header */}
              <div className="flex justify-between items-center border-b border-outline-variant pb-4 mb-6">
                <h3 className="text-xl font-bold uppercase tracking-wider text-primary font-narrow">
                  REGISTER FIRST-TIME CLIENT
                </h3>
                <button 
                  onClick={() => setIsModalOpen(false)}
                  className="text-on-surface-variant hover:text-on-surface cursor-pointer"
                >
                  <X size={20} />
                </button>
              </div>

              {/* Form */}
              <form onSubmit={handleAddNewClient} className="space-y-4">
                {/* Full name */}
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-on-surface-variant mb-1 ml-0.5">
                    Customer / Rider Name
                  </label>
                  <input
                    id="client-name"
                    type="text"
                    required
                    placeholder="e.g. Alex 'Thunder' Thompson"
                    className="w-full bg-background border border-outline-variant text-[#e5e2e3] focus:ring-1 focus:ring-primary-container p-3 text-sm focus:outline-none"
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                  />
                </div>

                {/* Company Name */}
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-on-surface-variant mb-1 ml-0.5">
                    Company / Specialty Shop
                  </label>
                  <input
                    id="client-company"
                    type="text"
                    placeholder="e.g. Thompson Steel Works (or leave blank)"
                    className="w-full bg-background border border-outline-variant text-[#e5e2e3] focus:ring-1 focus:ring-primary-container p-3 text-sm focus:outline-none"
                    value={clientCompany}
                    onChange={(e) => setClientCompany(e.target.value)}
                  />
                </div>

                {/* Email and Phone */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-mono uppercase tracking-wider text-on-surface-variant mb-1 ml-0.5">
                      Secure Email Address
                    </label>
                    <input
                    id="client-email"
                      type="email"
                      placeholder="e.g. email@example.com"
                      className="w-full bg-background border border-outline-variant text-[#e5e2e3] focus:ring-1 focus:ring-primary-container p-3 text-sm focus:outline-none"
                      value={clientEmail}
                      onChange={(e) => setClientEmail(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-mono uppercase tracking-wider text-on-surface-variant mb-1 ml-0.5">
                      Secure Mobile Call/SMS
                    </label>
                    <input
                    id="client-phone"
                      type="text"
                      placeholder="e.g. (555) 123-4567"
                      className="w-full bg-background border border-outline-variant text-[#e5e2e3] focus:ring-1 focus:ring-primary-container p-3 text-sm focus:outline-none"
                      value={clientPhone}
                      onChange={(e) => setClientPhone(e.target.value)}
                    />
                  </div>
                </div>

                {/* Operating Region */}
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-on-surface-variant mb-1 ml-0.5">
                    Operating Region / Logistics Zone
                  </label>
                  <select
                    id="client-region-select"
                    className="w-full bg-background border border-outline-variant text-[#e5e2e3] focus:ring-1 focus:ring-primary-container p-3 text-sm focus:outline-none"
                    value={clientRegion}
                    onChange={(e) => setClientRegion(e.target.value)}
                  >
                    <option value="west">West Coast (WA, OR, CA, NV)</option>
                    <option value="mountain">Mountain West (CO, UT, AZ, NM)</option>
                    <option value="midwest">Midwest Hub (IL, IN, MI, OH, WI)</option>
                    <option value="south">Gulf Coast & South (TX, FL, GA, TN)</option>
                    <option value="northeast">Northeast Corridor (NY, MA, PA, NJ)</option>
                    <option value="international">International / Export (Canada, Europe, UK)</option>
                  </select>
                </div>

                {/* Notes */}
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-on-surface-variant mb-1 ml-0.5">
                    Metallurgy Preferences & Custom Requirements Info
                  </label>
                  <textarea
                    id="client-notes"
                    placeholder="e.g. Prefers raw steel sand-blasted looks, TIG exhaust segmental guidelines, etc."
                    className="w-full bg-background border border-outline-variant text-[#e5e2e3] focus:ring-1 focus:ring-primary-container p-3 text-sm focus:outline-none h-24 resize-none"
                    value={clientNotes}
                    onChange={(e) => setClientNotes(e.target.value)}
                  />
                </div>

                {/* Buttons */}
                <div className="pt-4 border-t border-outline flex gap-3">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="flex-1 py-3 text-xs tracking-wider border border-outline text-on-surface font-semibold hover:bg-surface-container-highest transition-all"
                  >
                    CANCEL
                  </button>
                  <button
                    id="btn-client-submit"
                    type="submit"
                    className="flex-1 py-3 text-xs tracking-wider bg-primary-container text-white hover:opacity-90 font-bold transition-all"
                  >
                    REGISTER NEW CLIENT
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Excel Connector Hub Modal */}
      <ExcelConnectorModal
        isOpen={isExcelModalOpen}
        onClose={() => setIsExcelModalOpen(false)}
        defaultTab="export"
      />

      {/* Card Payment POS Terminal Modal */}
      <CardTransactionModal
        isOpen={isCardTerminalOpen}
        onClose={() => setIsCardTerminalOpen(false)}
        initialCustomerId={terminalCustomerId}
        initialAmount={terminalAmount}
      />
    </div>
  );
};
