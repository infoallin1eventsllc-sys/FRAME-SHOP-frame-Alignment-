import React, { useState } from 'react';
import { useAppState } from '../StateContext.tsx';
import { 
  Settings, 
  Sparkles, 
  Sliders, 
  Hammer, 
  Trash2, 
  Plus, 
  AlertTriangle, 
  CheckCircle,
  Package,
  Boxes,
  Download,
  FileText,
  Copy,
  RefreshCw,
  X
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const { 
    inventory, 
    lowStockThreshold, 
    updateInventoryStock, 
    updateLowStockThreshold, 
    addInventoryItem, 
    deleteInventoryItem,
    clients,
    builds
  } = useAppState();

  const [newItemName, setNewItemName] = useState('');
  const [newItemUnit, setNewItemUnit] = useState('meters');
  const [newItemStock, setNewItemStock] = useState(10);
  const [addSuccess, setAddSuccess] = useState(false);

  // Match or discover essential workshop materials
  const steelTubingItem = inventory.find(
    item => item.name.toLowerCase().includes('steel tubing') || item.id === 'inv-1'
  );
  const weldingWireItem = inventory.find(
    item => item.name.toLowerCase().includes('welding wire') || item.name.toLowerCase().includes('weld wire')
  );
  const grindingDiscsItem = inventory.find(
    item => item.name.toLowerCase().includes('grinding disc') || item.name.toLowerCase().includes('grind disc')
  );

  const handleAddSteelTubingPreset = () => {
    addInventoryItem('Structural Steel Tubing (HSS)', 'meters', 15);
  };

  const handleAddWeldingWirePreset = () => {
    addInventoryItem('MIG/TIG Welding Wire (0.035")', 'spools', 8);
  };

  const handleAddGrindingDiscsPreset = () => {
    addInventoryItem('Grinding Discs (5-inch Flap)', 'units', 25);
  };

  const handleAddAllPresets = () => {
    if (!steelTubingItem) handleAddSteelTubingPreset();
    if (!weldingWireItem) handleAddWeldingWirePreset();
    if (!grindingDiscsItem) handleAddGrindingDiscsPreset();
  };

  const handleAddNewItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemName.trim()) return;

    addInventoryItem(
      newItemName.trim(),
      newItemUnit,
      newItemStock
    );

    setNewItemName('');
    setNewItemStock(10);
    setAddSuccess(true);
    setTimeout(() => setAddSuccess(false), 3000);
  };

  const [exportSuccess, setExportSuccess] = useState<string | null>(null);

  const [isAuditModalOpen, setIsAuditModalOpen] = useState(false);
  const [copiedReport, setCopiedReport] = useState(false);
  const [auditText, setAuditText] = useState('');

  const handleGenerateAuditReport = () => {
    // 1. Get quick notes from localStorage
    let savedQuickNotes = [];
    try {
      const raw = localStorage.getItem('fs_quick_notes');
      if (raw) savedQuickNotes = JSON.parse(raw);
    } catch (e) {
      console.error(e);
    }

    const dateStr = new Date().toLocaleString();
    let report = `============================================================\n`;
    report += `          FORGEFLOW FABRICATION SHOP FLOOR AUDIT LOG        \n`;
    report += `                  GENERATED: ${dateStr}             \n`;
    report += `============================================================\n\n`;

    // SECTION A: WORKSHOP TELEMETRY & QUICK NOTES
    report += `[SECTION 1: DISPATCH TELEMETRY & ALERT NOTES]\n`;
    report += `------------------------------------------------------------\n`;
    if (savedQuickNotes.length === 0) {
      report += `No active/resolved shop-floor dispatch logs recorded.\n`;
    } else {
      savedQuickNotes.forEach((note: any, idx: number) => {
        report += `[LOG #${idx + 1}] ${note.timestamp}\n`;
        report += `  Station : ${note.station}\n`;
        report += `  Category: ${note.category} | Severity: ${note.severity}\n`;
        report += `  Log     : ${note.content}\n`;
        report += `  ----------------------------------------------------------\n`;
      });
    }
    report += `\n`;

    // SECTION B: ACTIVE CUSTOM FABRICATIONS (BUILDS)
    report += `[SECTION 2: PROJECT PIPELINES & BUILD TELEMETRY]\n`;
    report += `------------------------------------------------------------\n`;
    if (!builds || builds.length === 0) {
      report += `No active or historical custom fabrication projects recorded.\n`;
    } else {
      builds.forEach((b: any) => {
        report += `ORDER ${b.id}: ${b.name}\n`;
        report += `  Client     : ${b.customerName} (ID: ${b.customerId})\n`;
        report += `  Type       : ${b.type}\n`;
        report += `  Status     : ${b.status} | Initiated: ${b.startDate}\n`;
        report += `  Estimated  : $${b.estimatedCost.toLocaleString()}\n`;
        if (b.actualCost) {
          report += `  Actual Cost: $${b.actualCost.toLocaleString()}\n`;
        }
        if (b.completionDate) {
          report += `  Completed  : ${b.completionDate}\n`;
        }
        if (b.fabricationNotes) {
          report += `  Blueprint Specs: ${b.fabricationNotes}\n`;
        }
        if (b.greaseMonkeyNotes && b.greaseMonkeyNotes.length > 0) {
          report += `  Changelog Notes:\n`;
          b.greaseMonkeyNotes.forEach((n: string) => {
            report += `    - ${n}\n`;
          });
        }
        report += `  Archived   : ${b.isArchived ? 'YES' : 'NO'}\n`;
        report += `  ----------------------------------------------------------\n`;
      });
    }
    report += `\n`;

    // SECTION C: RAW MATERIALS INVENTORY STATUS
    report += `[SECTION 3: RAW MATERIAL INVENTORY AUDIT]\n`;
    report += `------------------------------------------------------------\n`;
    const lowStock = (inventory || []).filter((item: any) => item.stock < lowStockThreshold);
    report += `Total Registered Consumables: ${(inventory || []).length}\n`;
    report += `Low Stock Alerts Threshold   : < ${lowStockThreshold} units\n`;
    report += `Critical Depletion Alerts   : ${lowStock.length} items\n\n`;

    if (!inventory || inventory.length === 0) {
      report += `No raw materials cataloged in shop floor inventory.\n`;
    } else {
      inventory.forEach((item: any) => {
        const isLow = item.stock < lowStockThreshold;
        report += `${isLow ? '⚠️ [ALERT] ' : '✅ [OK]    '} ${item.name.padEnd(35)} : ${item.stock} ${item.unitType}\n`;
      });
    }
    report += `\n`;

    // SECTION D: CLIENT RELATIONS & LEDGERS
    report += `[SECTION 4: CUSTOMER BALANCES & LEDGER SUMMARY]\n`;
    report += `------------------------------------------------------------\n`;
    const activeClients = (clients || []).filter((c: any) => c.status === 'ACTIVE');
    const totalBalance = (clients || []).reduce((acc: number, c: any) => acc + (c.outstandingBalance || 0), 0);
    const totalSpend = (clients || []).reduce((acc: number, c: any) => acc + (c.lifetimeSpend || 0), 0);

    report += `Registered Clients Count : ${(clients || []).length} (${activeClients.length} active)\n`;
    report += `Cumulative Outstanding   : $${totalBalance.toLocaleString()}\n`;
    report += `Cumulative Lifetime LTV  : $${totalSpend.toLocaleString()}\n\n`;

    if (!clients || clients.length === 0) {
      report += `No customer profiles registered on this node.\n`;
    } else {
      clients.forEach((c: any) => {
        report += `CLIENT ${c.id}: ${c.name}\n`;
        report += `  Company    : ${c.company || 'N/A'}\n`;
        report += `  Status     : ${c.status}\n`;
        report += `  Balance Due: $${(c.outstandingBalance || 0).toLocaleString()}\n`;
        report += `  LTV Spend  : $${(c.lifetimeSpend || 0).toLocaleString()}\n`;
        if (c.notes) {
          report += `  Tech Notes : ${c.notes}\n`;
        }
        report += `  ----------------------------------------------------------\n`;
      });
    }

    report += `\n============================================================\n`;
    report += `                END OF FABRICATION AUDIT REPORT             \n`;
    report += `============================================================\n`;

    setAuditText(report);
    setIsAuditModalOpen(true);
  };

  const handleCopyAuditText = () => {
    navigator.clipboard.writeText(auditText);
    setCopiedReport(true);
    setTimeout(() => setCopiedReport(false), 2000);
  };

  const handleDownloadAuditReport = () => {
    const blob = new Blob([auditText], { type: 'text/plain;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `forgeflow_audit_report_${new Date().toISOString().split('T')[0]}.txt`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportClients = () => {
    if (!clients || clients.length === 0) {
      alert('No client data available to export.');
      return;
    }

    const headers = [
      'Client ID',
      'Name',
      'Email',
      'Phone',
      'Company',
      'Outstanding Balance ($)',
      'Lifetime Spend ($)',
      'Status',
      'Notes'
    ];

    const rows = clients.map(c => [
      c.id,
      c.name,
      c.email || '',
      c.phone || '',
      c.company || '',
      c.outstandingBalance || 0,
      c.lifetimeSpend || 0,
      c.status,
      c.notes || ''
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => 
        row.map(val => {
          const str = val === null || val === undefined ? '' : String(val);
          const escaped = str.replace(/"/g, '""');
          if (escaped.includes(',') || escaped.includes('\n') || escaped.includes('"')) {
            return `"${escaped}"`;
          }
          return escaped;
        }).join(',')
      )
    ].join('\r\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `clients_backup_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setExportSuccess('Clients database exported successfully!');
    setTimeout(() => setExportSuccess(null), 3000);
  };

  const handleExportBuilds = () => {
    if (!builds || builds.length === 0) {
      alert('No build data available to export.');
      return;
    }

    const headers = [
      'Build ID',
      'Build Name',
      'Customer ID',
      'Customer Name',
      'Type',
      'Description',
      'Status',
      'Start Date',
      'Completion Date',
      'Estimated Cost ($)',
      'Actual Cost ($)',
      'Fabrication Notes',
      'Grease Monkey Notes',
      'Archived'
    ];

    const rows = builds.map(b => [
      b.id,
      b.name,
      b.customerId,
      b.customerName,
      b.type,
      b.description,
      b.status,
      b.startDate,
      b.completionDate || '',
      b.estimatedCost || 0,
      b.actualCost || '',
      b.fabricationNotes || '',
      (b.greaseMonkeyNotes || []).join(' | '),
      b.isArchived ? 'TRUE' : 'FALSE'
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => 
        row.map(val => {
          const str = val === null || val === undefined ? '' : String(val);
          const escaped = str.replace(/"/g, '""');
          if (escaped.includes(',') || escaped.includes('\n') || escaped.includes('"')) {
            return `"${escaped}"`;
          }
          return escaped;
        }).join(',')
      )
    ].join('\r\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `builds_backup_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setExportSuccess('Builds database exported successfully!');
    setTimeout(() => setExportSuccess(null), 3000);
  };

  return (
    <div className="relative z-10 font-sans">
      {/* Header */}
      <div className="border-b border-outline-variant pb-6 mb-12">
        <h2 className="text-4xl md:text-5xl font-bold uppercase tracking-tight text-on-surface font-narrow flex items-center gap-3">
          <Settings className="text-primary-container" />
          SYSTEM CONFIGURATION
        </h2>
        <p className="text-base text-on-surface-variant font-medium mt-1">
          Adjust warning thresholds, manage raw material stock levels, and configure shop-floor parameters
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left column: Parameters & Threshold */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Threshold Card */}
          <div className="bg-surface-container border border-outline-variant p-6 relative overflow-hidden rounded-xs">
            <div className="metal-grain absolute inset-0 opacity-40 pointer-events-none" />
            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-4 border-b border-outline-variant/60 pb-3">
                <Sliders size={18} className="text-primary" />
                <h3 className="text-base font-bold uppercase tracking-wider text-on-surface font-narrow">
                  Alert Parameters
                </h3>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-mono uppercase tracking-widest text-on-surface-variant mb-2">
                    Global Low-Stock Threshold
                  </label>
                  
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => updateLowStockThreshold(lowStockThreshold - 1)}
                      className="w-10 h-10 bg-slate-900 border border-outline-variant text-[#e5e2e3] font-bold text-lg hover:bg-slate-800 flex items-center justify-center cursor-pointer transition-colors"
                      title="Decrease threshold"
                    >
                      -
                    </button>
                    
                    <input
                      id="low-stock-threshold-input"
                      type="number"
                      min="1"
                      className="w-24 h-10 bg-background border border-outline-variant text-[#e5e2e3] text-center font-mono text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                      value={lowStockThreshold}
                      onChange={(e) => updateLowStockThreshold(Number(e.target.value))}
                    />

                    <button
                      type="button"
                      onClick={() => updateLowStockThreshold(lowStockThreshold + 1)}
                      className="w-10 h-10 bg-slate-900 border border-outline-variant text-[#e5e2e3] font-bold text-lg hover:bg-slate-800 flex items-center justify-center cursor-pointer transition-colors"
                      title="Increase threshold"
                    >
                      +
                    </button>
                  </div>
                  
                  <p className="text-[11px] text-on-surface-variant mt-3 leading-relaxed">
                    Raw materials with inventory stock quantities falling **below this pre-set value** will trigger visual warning indicators on the main Dashboard.
                  </p>
                </div>

                <div className="bg-slate-950/40 p-3 border border-outline-variant/30 rounded-xs mt-2">
                  <div className="flex items-start gap-2">
                    <AlertTriangle size={14} className="text-amber-500 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-[10px] font-mono uppercase font-bold text-amber-500 tracking-wider">
                        Current Threshold Severity
                      </p>
                      <p className="text-[10px] text-slate-400 mt-0.5 leading-relaxed">
                        Setting a higher threshold warns fabricators earlier of impending material depletions.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Add New Material Form Card */}
          <div className="bg-surface-container border border-outline-variant p-6 relative overflow-hidden rounded-xs">
            <div className="metal-grain absolute inset-0 opacity-40 pointer-events-none" />
            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-4 border-b border-outline-variant/60 pb-3">
                <Plus size={18} className="text-primary" />
                <h3 className="text-base font-bold uppercase tracking-wider text-on-surface font-narrow">
                  Add Raw Material Preset
                </h3>
              </div>

              <form onSubmit={handleAddNewItem} className="space-y-4">
                <div>
                  <label className="block text-xs font-mono uppercase tracking-widest text-on-surface-variant mb-1.5 ml-0.5">
                    Material Name
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 1/4 inch Steel Rebar"
                    className="w-full bg-background border border-outline-variant text-[#e5e2e3] p-3 text-xs focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary placeholder:text-slate-600 font-mono"
                    value={newItemName}
                    onChange={(e) => setNewItemName(e.target.value)}
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-mono uppercase tracking-widest text-on-surface-variant mb-1.5 ml-0.5">
                      Unit Measure
                    </label>
                    <select
                      className="w-full bg-background border border-outline-variant text-[#e5e2e3] p-2.5 text-xs focus:outline-none focus:ring-1 focus:ring-primary font-mono"
                      value={newItemUnit}
                      onChange={(e) => setNewItemUnit(e.target.value)}
                    >
                      <option value="meters">meters</option>
                      <option value="sheets">sheets</option>
                      <option value="kits">kits</option>
                      <option value="cans">cans</option>
                      <option value="lbs">lbs</option>
                      <option value="units">units</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-mono uppercase tracking-widest text-on-surface-variant mb-1.5 ml-0.5">
                      Initial Stock
                    </label>
                    <input
                      type="number"
                      min="0"
                      className="w-full bg-background border border-outline-variant text-[#e5e2e3] p-2 text-xs focus:outline-none focus:ring-1 focus:ring-primary font-mono"
                      value={newItemStock}
                      onChange={(e) => setNewItemStock(Math.max(0, Number(e.target.value)))}
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-primary hover:bg-secondary text-white font-mono text-xs font-bold uppercase tracking-wider rounded-sm transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md"
                >
                  <Plus size={14} />
                  <span>Register Material</span>
                </button>

                {addSuccess && (
                  <div className="p-2.5 bg-emerald-950/20 border border-emerald-900/40 text-emerald-400 text-[11px] font-mono rounded-xs flex items-center gap-1.5">
                    <CheckCircle size={12} />
                    <span>Material successfully registered!</span>
                  </div>
                )}
              </form>
            </div>
          </div>

          {/* Local Backup & Export Card */}
          <div className="bg-surface-container border border-outline-variant p-6 relative overflow-hidden rounded-xs">
            <div className="metal-grain absolute inset-0 opacity-40 pointer-events-none" />
            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-4 border-b border-outline-variant/60 pb-3">
                <Download size={18} className="text-primary" />
                <h3 className="text-base font-bold uppercase tracking-wider text-on-surface font-narrow">
                  Local Backup & Export
                </h3>
              </div>

              <p className="text-[11px] text-on-surface-variant mb-4 leading-relaxed">
                Export shop floor custom fabrication data and registered client databases to standard CSV spreadsheet backups.
              </p>

              {exportSuccess && (
                <div className="mb-4 p-2.5 bg-emerald-950/20 border border-emerald-900/40 text-emerald-400 text-xs font-mono rounded-xs flex items-center gap-1.5 animate-fade-in">
                  <CheckCircle size={14} />
                  <span>{exportSuccess}</span>
                </div>
              )}

              <div className="space-y-3">
                <button
                  id="btn-export-clients-csv"
                  type="button"
                  onClick={handleExportClients}
                  className="w-full py-2.5 bg-slate-900 hover:bg-slate-850 border border-outline-variant text-[#e5e2e3] font-mono text-xs font-bold uppercase tracking-wider rounded-sm transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md"
                >
                  <Download size={14} className="text-primary" />
                  <span>EXPORT CLIENTS TO CSV</span>
                </button>

                <button
                  id="btn-export-builds-csv"
                  type="button"
                  onClick={handleExportBuilds}
                  className="w-full py-2.5 bg-slate-900 hover:bg-slate-850 border border-outline-variant text-[#e5e2e3] font-mono text-xs font-bold uppercase tracking-wider rounded-sm transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md"
                >
                  <Download size={14} className="text-primary" />
                  <span>EXPORT BUILDS TO CSV</span>
                </button>
              </div>

              <p className="text-[9px] text-slate-500 font-mono mt-4 leading-relaxed text-center uppercase tracking-wider">
                Spreadsheets compile all relational active and historical records
              </p>
            </div>
          </div>

          {/* Consolidated Audit Summary Report Card */}
          <div className="bg-surface-container border border-outline-variant p-6 relative overflow-hidden rounded-xs">
            <div className="metal-grain absolute inset-0 opacity-40 pointer-events-none" />
            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-4 border-b border-outline-variant/60 pb-3">
                <FileText size={18} className="text-primary" />
                <h3 className="text-base font-bold uppercase tracking-wider text-on-surface font-narrow">
                  CONSOLIDATED AUDIT REPORT
                </h3>
              </div>

              <p className="text-[11px] text-on-surface-variant mb-4 leading-relaxed">
                Generate a unified plain-text audit summary report combining active workshop telemetry notes, materials depletion warnings, and outstanding client balances.
              </p>

              <button
                id="btn-generate-audit-report"
                type="button"
                onClick={handleGenerateAuditReport}
                className="w-full py-3 bg-primary hover:bg-blue-700 text-white font-mono text-xs font-bold uppercase tracking-widest rounded-sm transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md border border-primary/20 hover:scale-[1.02] active:scale-95 duration-150"
              >
                <FileText size={14} />
                <span>GENERATE SUMMARY REPORT</span>
              </button>

              <p className="text-[9px] text-slate-500 font-mono mt-4 leading-relaxed text-center uppercase tracking-wider">
                Audits compile quick notes, active build states, and current stock status
              </p>
            </div>
          </div>

        </div>

        {/* Right column: Material Registry list */}
        <div className="lg:col-span-8 space-y-6">

          {/* Essential Shop Raw Materials Quick-Manager */}
          <div className="bg-surface-container border border-outline-variant p-6 relative overflow-hidden rounded-xs">
            <div className="metal-grain absolute inset-0 opacity-40 pointer-events-none" />
            <div className="relative z-10">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4 border-b border-outline-variant/60 pb-3">
                <div className="flex items-center gap-2">
                  <Package size={18} className="text-primary animate-pulse" />
                  <div>
                    <h3 className="text-base font-bold uppercase tracking-wider text-on-surface font-narrow">
                      Essential Materials Stock-Manager
                    </h3>
                    <p className="text-[10px] text-on-surface-variant font-mono uppercase tracking-wider">
                      Primary fabrication consumables and quick-calibration desk
                    </p>
                  </div>
                </div>
                {(!steelTubingItem || !weldingWireItem || !grindingDiscsItem) && (
                  <button
                    id="btn-seed-all-essentials"
                    type="button"
                    onClick={handleAddAllPresets}
                    className="text-[10px] font-mono font-bold tracking-widest text-primary border border-primary/20 bg-primary/5 hover:bg-primary/10 px-2.5 py-1.5 rounded-sm cursor-pointer transition-all uppercase flex items-center gap-1.5 self-start sm:self-auto"
                  >
                    <Plus size={12} />
                    <span>SEED ALL 3 ESSENTIALS</span>
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* 1. Steel Tubing */}
                <div className={`p-4 border rounded-xs relative flex flex-col justify-between min-h-[170px] transition-all ${
                  steelTubingItem 
                    ? (steelTubingItem.stock < lowStockThreshold ? 'bg-amber-950/10 border-amber-500/30' : 'bg-slate-900/20 border-outline-variant/30')
                    : 'bg-slate-950/40 border-dashed border-outline-variant/40'
                }`}>
                  <div>
                    <div className="flex justify-between items-start gap-2 mb-1.5">
                      <span className="font-mono text-[9px] font-bold text-primary tracking-widest uppercase">
                        STRUCTURAL STEEL
                      </span>
                      {steelTubingItem && (
                        steelTubingItem.stock < lowStockThreshold ? (
                          <span className="px-1.5 py-0.5 text-[8px] font-mono font-black uppercase text-amber-500 bg-amber-500/10 border border-amber-500/20 rounded-full animate-bounce-subtle">
                            LOW
                          </span>
                        ) : (
                          <span className="px-1.5 py-0.5 text-[8px] font-mono font-bold uppercase text-emerald-400 bg-emerald-400/10 border border-emerald-400/20 rounded-full">
                            OK
                          </span>
                        )
                      )}
                    </div>
                    <h4 className="text-xs font-bold text-slate-200 line-clamp-1">Steel Tubing</h4>
                    <p className="text-[10px] text-slate-500 font-mono mt-0.5">Heavy structural HSS framework</p>
                  </div>

                  {steelTubingItem ? (
                    <div className="mt-3 space-y-2.5">
                      <div className="flex justify-between items-baseline">
                        <span className="font-narrow font-bold text-xl text-slate-100">{steelTubingItem.stock}</span>
                        <span className="font-mono text-[9px] text-slate-400 uppercase">{steelTubingItem.unitType}</span>
                      </div>
                      {/* Control Group */}
                      <div className="grid grid-cols-4 gap-1">
                        <button
                          type="button"
                          onClick={() => updateInventoryStock(steelTubingItem.id, steelTubingItem.stock - 5)}
                          className="py-1 bg-slate-950 hover:bg-slate-850 text-slate-400 hover:text-white border border-outline-variant/30 font-mono text-[9px] rounded-xs cursor-pointer transition-colors"
                          title="Reduce stock by 5"
                        >
                          -5
                        </button>
                        <button
                          type="button"
                          onClick={() => updateInventoryStock(steelTubingItem.id, steelTubingItem.stock - 1)}
                          className="py-1 bg-slate-950 hover:bg-slate-850 text-slate-400 hover:text-white border border-outline-variant/30 font-mono text-[9px] rounded-xs cursor-pointer transition-colors"
                          title="Reduce stock by 1"
                        >
                          -1
                        </button>
                        <button
                          type="button"
                          onClick={() => updateInventoryStock(steelTubingItem.id, steelTubingItem.stock + 1)}
                          className="py-1 bg-slate-950 hover:bg-slate-850 text-slate-400 hover:text-white border border-outline-variant/30 font-mono text-[9px] rounded-xs cursor-pointer transition-colors"
                          title="Increase stock by 1"
                        >
                          +1
                        </button>
                        <button
                          type="button"
                          onClick={() => updateInventoryStock(steelTubingItem.id, steelTubingItem.stock + 5)}
                          className="py-1 bg-slate-950 hover:bg-slate-850 text-slate-400 hover:text-white border border-outline-variant/30 font-mono text-[9px] rounded-xs cursor-pointer transition-colors"
                          title="Increase stock by 5"
                        >
                          +5
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="mt-4">
                      <button
                        id="btn-add-steel-preset"
                        type="button"
                        onClick={handleAddSteelTubingPreset}
                        className="w-full py-2 bg-slate-900 hover:bg-slate-850 text-primary border border-primary/20 hover:border-primary/40 text-[10px] font-mono font-bold uppercase tracking-wider rounded-xs cursor-pointer transition-all flex items-center justify-center gap-1"
                      >
                        <Plus size={11} />
                        <span>Register Tubing</span>
                      </button>
                    </div>
                  )}
                </div>

                {/* 2. Welding Wire */}
                <div className={`p-4 border rounded-xs relative flex flex-col justify-between min-h-[170px] transition-all ${
                  weldingWireItem 
                    ? (weldingWireItem.stock < lowStockThreshold ? 'bg-amber-950/10 border-amber-500/30' : 'bg-slate-900/20 border-outline-variant/30')
                    : 'bg-slate-950/40 border-dashed border-outline-variant/40'
                }`}>
                  <div>
                    <div className="flex justify-between items-start gap-2 mb-1.5">
                      <span className="font-mono text-[9px] font-bold text-primary tracking-widest uppercase">
                        CONSUMABLES
                      </span>
                      {weldingWireItem && (
                        weldingWireItem.stock < lowStockThreshold ? (
                          <span className="px-1.5 py-0.5 text-[8px] font-mono font-black uppercase text-amber-500 bg-amber-500/10 border border-amber-500/20 rounded-full animate-bounce-subtle">
                            LOW
                          </span>
                        ) : (
                          <span className="px-1.5 py-0.5 text-[8px] font-mono font-bold uppercase text-emerald-400 bg-emerald-400/10 border border-emerald-400/20 rounded-full">
                            OK
                          </span>
                        )
                      )}
                    </div>
                    <h4 className="text-xs font-bold text-slate-200 line-clamp-1">Welding Wire</h4>
                    <p className="text-[10px] text-slate-500 font-mono mt-0.5">MIG spools / TIG filler rods</p>
                  </div>

                  {weldingWireItem ? (
                    <div className="mt-3 space-y-2.5">
                      <div className="flex justify-between items-baseline">
                        <span className="font-narrow font-bold text-xl text-slate-100">{weldingWireItem.stock}</span>
                        <span className="font-mono text-[9px] text-slate-400 uppercase">{weldingWireItem.unitType}</span>
                      </div>
                      {/* Control Group */}
                      <div className="grid grid-cols-4 gap-1">
                        <button
                          type="button"
                          onClick={() => updateInventoryStock(weldingWireItem.id, weldingWireItem.stock - 5)}
                          className="py-1 bg-slate-950 hover:bg-slate-850 text-slate-400 hover:text-white border border-outline-variant/30 font-mono text-[9px] rounded-xs cursor-pointer transition-colors"
                          title="Reduce stock by 5"
                        >
                          -5
                        </button>
                        <button
                          type="button"
                          onClick={() => updateInventoryStock(weldingWireItem.id, weldingWireItem.stock - 1)}
                          className="py-1 bg-slate-950 hover:bg-slate-850 text-slate-400 hover:text-white border border-outline-variant/30 font-mono text-[9px] rounded-xs cursor-pointer transition-colors"
                          title="Reduce stock by 1"
                        >
                          -1
                        </button>
                        <button
                          type="button"
                          onClick={() => updateInventoryStock(weldingWireItem.id, weldingWireItem.stock + 1)}
                          className="py-1 bg-slate-950 hover:bg-slate-850 text-slate-400 hover:text-white border border-outline-variant/30 font-mono text-[9px] rounded-xs cursor-pointer transition-colors"
                          title="Increase stock by 1"
                        >
                          +1
                        </button>
                        <button
                          type="button"
                          onClick={() => updateInventoryStock(weldingWireItem.id, weldingWireItem.stock + 5)}
                          className="py-1 bg-slate-950 hover:bg-slate-850 text-slate-400 hover:text-white border border-outline-variant/30 font-mono text-[9px] rounded-xs cursor-pointer transition-colors"
                          title="Increase stock by 5"
                        >
                          +5
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="mt-4">
                      <button
                        id="btn-add-wire-preset"
                        type="button"
                        onClick={handleAddWeldingWirePreset}
                        className="w-full py-2 bg-slate-900 hover:bg-slate-850 text-primary border border-primary/20 hover:border-primary/40 text-[10px] font-mono font-bold uppercase tracking-wider rounded-xs cursor-pointer transition-all flex items-center justify-center gap-1"
                      >
                        <Plus size={11} />
                        <span>Register Wire</span>
                      </button>
                    </div>
                  )}
                </div>

                {/* 3. Grinding Discs */}
                <div className={`p-4 border rounded-xs relative flex flex-col justify-between min-h-[170px] transition-all ${
                  grindingDiscsItem 
                    ? (grindingDiscsItem.stock < lowStockThreshold ? 'bg-amber-950/10 border-amber-500/30' : 'bg-slate-900/20 border-outline-variant/30')
                    : 'bg-slate-950/40 border-dashed border-outline-variant/40'
                }`}>
                  <div>
                    <div className="flex justify-between items-start gap-2 mb-1.5">
                      <span className="font-mono text-[9px] font-bold text-primary tracking-widest uppercase">
                        ABRASIVES
                      </span>
                      {grindingDiscsItem && (
                        grindingDiscsItem.stock < lowStockThreshold ? (
                          <span className="px-1.5 py-0.5 text-[8px] font-mono font-black uppercase text-amber-500 bg-amber-500/10 border border-amber-500/20 rounded-full animate-bounce-subtle">
                            LOW
                          </span>
                        ) : (
                          <span className="px-1.5 py-0.5 text-[8px] font-mono font-bold uppercase text-emerald-400 bg-emerald-400/10 border border-emerald-400/20 rounded-full">
                            OK
                          </span>
                        )
                      )}
                    </div>
                    <h4 className="text-xs font-bold text-slate-200 line-clamp-1">Grinding Discs</h4>
                    <p className="text-[10px] text-slate-500 font-mono mt-0.5">Flap & cutting abrasives</p>
                  </div>

                  {grindingDiscsItem ? (
                    <div className="mt-3 space-y-2.5">
                      <div className="flex justify-between items-baseline">
                        <span className="font-narrow font-bold text-xl text-slate-100">{grindingDiscsItem.stock}</span>
                        <span className="font-mono text-[9px] text-slate-400 uppercase">{grindingDiscsItem.unitType}</span>
                      </div>
                      {/* Control Group */}
                      <div className="grid grid-cols-4 gap-1">
                        <button
                          type="button"
                          onClick={() => updateInventoryStock(grindingDiscsItem.id, grindingDiscsItem.stock - 5)}
                          className="py-1 bg-slate-950 hover:bg-slate-850 text-slate-400 hover:text-white border border-outline-variant/30 font-mono text-[9px] rounded-xs cursor-pointer transition-colors"
                          title="Reduce stock by 5"
                        >
                          -5
                        </button>
                        <button
                          type="button"
                          onClick={() => updateInventoryStock(grindingDiscsItem.id, grindingDiscsItem.stock - 1)}
                          className="py-1 bg-slate-950 hover:bg-slate-850 text-slate-400 hover:text-white border border-outline-variant/30 font-mono text-[9px] rounded-xs cursor-pointer transition-colors"
                          title="Reduce stock by 1"
                        >
                          -1
                        </button>
                        <button
                          type="button"
                          onClick={() => updateInventoryStock(grindingDiscsItem.id, grindingDiscsItem.stock + 1)}
                          className="py-1 bg-slate-950 hover:bg-slate-850 text-slate-400 hover:text-white border border-outline-variant/30 font-mono text-[9px] rounded-xs cursor-pointer transition-colors"
                          title="Increase stock by 1"
                        >
                          +1
                        </button>
                        <button
                          type="button"
                          onClick={() => updateInventoryStock(grindingDiscsItem.id, grindingDiscsItem.stock + 5)}
                          className="py-1 bg-slate-950 hover:bg-slate-850 text-slate-400 hover:text-white border border-outline-variant/30 font-mono text-[9px] rounded-xs cursor-pointer transition-colors"
                          title="Increase stock by 5"
                        >
                          +5
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="mt-4">
                      <button
                        id="btn-add-discs-preset"
                        type="button"
                        onClick={handleAddGrindingDiscsPreset}
                        className="w-full py-2 bg-slate-900 hover:bg-slate-850 text-primary border border-primary/20 hover:border-primary/40 text-[10px] font-mono font-bold uppercase tracking-wider rounded-xs cursor-pointer transition-all flex items-center justify-center gap-1"
                      >
                        <Plus size={11} />
                        <span>Register Discs</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="bg-surface-container border border-outline-variant p-6 relative overflow-hidden rounded-xs min-h-[500px] flex flex-col">
            <div className="metal-grain absolute inset-0 opacity-40 pointer-events-none" />
            <div className="relative z-10 flex-1 flex flex-col">
              
              <div className="flex justify-between items-center mb-6 border-b border-outline-variant/60 pb-3">
                <div className="flex items-center gap-2">
                  <Boxes size={18} className="text-primary" />
                  <h3 className="text-base font-bold uppercase tracking-wider text-on-surface font-narrow">
                    Raw Materials Inventory Registry
                  </h3>
                </div>
                <span className="font-mono text-[10px] text-slate-500 uppercase tracking-widest">
                  {inventory.length} materials tracked
                </span>
              </div>

              {/* Material List Table */}
              <div className="space-y-3 overflow-y-auto max-h-[550px] pr-1 flex-1">
                {inventory.map((item) => {
                  const isLow = item.stock < lowStockThreshold;
                  
                  // Percentage calculation for visual progress bar (cap at 100%)
                  const progressPct = Math.min(100, Math.round((item.stock / lowStockThreshold) * 100));

                  return (
                    <div 
                      key={item.id}
                      className={`p-4 border transition-all rounded-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-4 ${
                        isLow 
                          ? 'bg-amber-950/10 border-amber-500/30 hover:border-amber-500/50' 
                          : 'bg-slate-900/20 border-outline-variant/30 hover:border-outline-variant/60'
                      }`}
                    >
                      {/* Name & Unit Info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-narrow font-bold text-slate-200 text-sm">
                            {item.name}
                          </span>
                          
                          {isLow ? (
                            <span className="px-2 py-0.5 text-[9px] font-mono font-black uppercase text-amber-500 bg-amber-500/10 border border-amber-500/20 rounded-full animate-pulse flex items-center gap-1">
                              <AlertTriangle size={9} />
                              Low Stock
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 text-[9px] font-mono font-bold uppercase text-emerald-400 bg-emerald-400/10 border border-emerald-400/20 rounded-full flex items-center gap-1">
                              <CheckCircle size={9} />
                              In Stock
                            </span>
                          )}
                        </div>

                        {/* Progress Bar Visualizer */}
                        <div className="mt-2.5 max-w-md">
                          <div className="flex justify-between font-mono text-[9px] text-slate-500 mb-1">
                            <span>Stock Levels: {item.stock} / {lowStockThreshold} {item.unitType}</span>
                            <span>{progressPct}%</span>
                          </div>
                          <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden border border-slate-900">
                            <div 
                              style={{ width: `${progressPct}%` }}
                              className={`h-full rounded-full transition-all duration-500 ${
                                isLow ? 'bg-amber-500' : 'bg-emerald-500'
                              }`}
                            />
                          </div>
                        </div>
                      </div>

                      {/* Stock Adjuster Control Buttons & Action items */}
                      <div className="flex items-center gap-4 w-full md:w-auto shrink-0 justify-between md:justify-end">
                        
                        {/* Adjuster */}
                        <div className="flex items-center bg-slate-950 rounded-xs border border-outline-variant/30 p-1">
                          <button
                            type="button"
                            onClick={() => updateInventoryStock(item.id, item.stock - 1)}
                            className="w-8 h-8 flex items-center justify-center font-bold font-mono text-slate-400 hover:text-white transition-colors cursor-pointer"
                            title="Decrement stock"
                          >
                            -
                          </button>
                          
                          <span className="w-12 text-center font-mono text-xs font-bold text-slate-200">
                            {item.stock}
                          </span>

                          <button
                            type="button"
                            onClick={() => updateInventoryStock(item.id, item.stock + 1)}
                            className="w-8 h-8 flex items-center justify-center font-bold font-mono text-slate-400 hover:text-white transition-colors cursor-pointer"
                            title="Increment stock"
                          >
                            +
                          </button>
                        </div>

                        {/* Unit type label */}
                        <span className="font-mono text-[10px] text-slate-500 uppercase">
                          {item.unitType}
                        </span>

                        {/* Delete preset button (only allow delete for items that aren't the primary initial presets to prevent breaking basic setup, or just all) */}
                        <button
                          type="button"
                          onClick={() => deleteInventoryItem(item.id)}
                          className="p-1.5 bg-red-950/20 text-red-400 border border-red-900/30 hover:bg-red-900/20 hover:border-red-800 rounded-sm cursor-pointer transition-all"
                          title={`Delete ${item.name}`}
                        >
                          <Trash2 size={13} />
                        </button>

                      </div>

                    </div>
                  );
                })}

                {inventory.length === 0 && (
                  <div className="flex flex-col items-center justify-center text-center py-16 border border-dashed border-outline-variant/40 rounded-xs bg-slate-950/25">
                    <Package className="text-slate-600 mb-3" size={36} />
                    <p className="font-mono text-xs text-slate-400 uppercase tracking-widest">
                      No materials registered in inventory
                    </p>
                    <p className="text-[11px] text-slate-500 mt-1 max-w-xs">
                      Use the registration form on the left to add raw materials to the database.
                    </p>
                  </div>
                )}
              </div>

            </div>
          </div>
        </div>

      </div>

      {/* Consolidated Audit Report Modal */}
      {isAuditModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/85 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-surface border-2 border-outline-variant w-full max-w-3xl shadow-2xl relative rounded-xs font-sans overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[85vh]">
            <div className="metal-grain absolute inset-0 opacity-10 pointer-events-none" />
            
            {/* Modal Header */}
            <div className="bg-slate-900 text-slate-100 p-5 border-b border-outline-variant relative z-10 flex justify-between items-center flex-shrink-0">
              <div>
                <h3 className="text-lg font-bold uppercase tracking-wider font-narrow flex items-center gap-2 text-primary">
                  <FileText size={18} className="text-primary animate-pulse" />
                  CONSOLIDATED WORKSHOP AUDIT REPORT
                </h3>
                <p className="text-[11px] text-slate-400 font-mono uppercase mt-1">
                  Cross-referenced dispatch notes, active projects, inventory levels, and outstanding accounts
                </p>
              </div>
              <button 
                onClick={() => setIsAuditModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xs transition-colors cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Modal Body / Report Textarea */}
            <div className="p-6 overflow-y-auto flex-1 bg-slate-950 font-mono text-xs text-[#10b981] leading-relaxed relative z-10">
              <textarea
                id="audit-report-text-view"
                readOnly
                value={auditText}
                className="w-full h-full min-h-[350px] bg-transparent border-0 resize-none outline-none text-[#10b981] font-mono select-all selection:bg-[#10b981]/20"
                style={{ fontFamily: "'JetBrains Mono', 'Fira Code', monospace" }}
              />
            </div>

            {/* Modal Footer Actions */}
            <div className="flex flex-col sm:flex-row justify-between items-center gap-3 p-5 border-t border-outline-variant/60 bg-slate-900 relative z-10 flex-shrink-0">
              <div className="flex items-center gap-2">
                <button
                  id="btn-refresh-audit"
                  type="button"
                  onClick={handleGenerateAuditReport}
                  className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-mono font-bold uppercase tracking-wider rounded-xs border border-outline-variant/30 cursor-pointer transition-colors flex items-center gap-1.5"
                  title="Re-generate and refresh audit telemetry data"
                >
                  <RefreshCw size={12} />
                  <span>REFRESH REPORT</span>
                </button>
              </div>

              <div className="flex gap-3 w-full sm:w-auto">
                <button
                  id="btn-copy-audit"
                  type="button"
                  onClick={handleCopyAuditText}
                  className={`flex-1 sm:flex-none px-4 py-2 text-xs font-mono font-bold uppercase tracking-wider rounded-xs border cursor-pointer transition-all flex items-center justify-center gap-1.5 ${
                    copiedReport 
                      ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' 
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border-outline-variant/30'
                  }`}
                >
                  <Copy size={12} />
                  <span>{copiedReport ? 'COPIED!' : 'COPY REPORT'}</span>
                </button>
                
                <button
                  id="btn-download-audit"
                  type="button"
                  onClick={handleDownloadAuditReport}
                  className="flex-1 sm:flex-none px-5 py-2 bg-primary hover:bg-blue-700 text-white text-xs font-mono font-bold uppercase tracking-wider rounded-xs cursor-pointer transition-colors flex items-center justify-center gap-1.5"
                >
                  <Download size={12} />
                  <span>DOWNLOAD TEXT</span>
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
