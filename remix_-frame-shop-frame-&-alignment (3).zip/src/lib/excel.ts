import * as XLSX from 'xlsx';
import { Invoice, Client, Build, InventoryItem } from '../types';

/**
 * Excel Spreadsheet Helper Utilities for ForgeFlow Metalworks
 */

// Export Invoices to XLSX
export function exportInvoicesToExcel(invoices: Invoice[]) {
  const data = invoices.map(inv => ({
    'Invoice Number': inv.id,
    'Date': inv.date,
    'Client Name': inv.customerName,
    'Client ID': inv.customerId,
    'Project / Order': inv.project,
    'Project ID': inv.projectId,
    'Amount ($)': inv.amount,
    'Status': inv.status,
    'Last Emailed': inv.lastEmailedAt || 'Not Sent'
  }));

  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Invoices');

  // Set column widths
  worksheet['!cols'] = [
    { wch: 18 }, // Invoice Number
    { wch: 15 }, // Date
    { wch: 25 }, // Client Name
    { wch: 15 }, // Client ID
    { wch: 28 }, // Project
    { wch: 15 }, // Project ID
    { wch: 15 }, // Amount
    { wch: 15 }, // Status
    { wch: 20 }, // Last Emailed
  ];

  XLSX.writeFile(workbook, `ForgeFlow_Invoices_${new Date().toISOString().split('T')[0]}.xlsx`);
}

// Export Clients to XLSX
export function exportClientsToExcel(clients: Client[]) {
  const data = clients.map(client => ({
    'Client ID': client.id,
    'Client Name': client.name,
    'Company': client.company || 'N/A',
    'Email Address': client.email,
    'Phone': client.phone,
    'Status': client.status,
    'Outstanding Balance ($)': client.outstandingBalance || 0,
    'Lifetime Spend ($)': client.lifetimeSpend || 0,
    'Notes': client.notes || ''
  }));

  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Clients');

  worksheet['!cols'] = [
    { wch: 15 },
    { wch: 25 },
    { wch: 25 },
    { wch: 28 },
    { wch: 18 },
    { wch: 12 },
    { wch: 22 },
    { wch: 20 },
    { wch: 35 }
  ];

  XLSX.writeFile(workbook, `ForgeFlow_Clients_${new Date().toISOString().split('T')[0]}.xlsx`);
}

// Export Inventory Materials to XLSX
export function exportInventoryToExcel(inventory: InventoryItem[]) {
  const data = inventory.map(item => ({
    'Item ID': item.id,
    'Material Description': item.name,
    'Unit Type': item.unitType,
    'Stock Quantity': item.stock
  }));

  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Inventory Materials');

  worksheet['!cols'] = [
    { wch: 15 },
    { wch: 35 },
    { wch: 15 },
    { wch: 18 }
  ];

  XLSX.writeFile(workbook, `ForgeFlow_Inventory_${new Date().toISOString().split('T')[0]}.xlsx`);
}

// Export Builds to XLSX
export function exportBuildsToExcel(builds: Build[]) {
  const data = builds.map(b => ({
    'Build ID': b.id,
    'Project Name': b.name,
    'Client Name': b.customerName,
    'Client ID': b.customerId,
    'Fabrication Type': b.type,
    'Status': b.status,
    'Start Date': b.startDate,
    'Completion Date': b.completionDate || 'Ongoing',
    'Estimated Cost ($)': b.estimatedCost,
    'Actual Cost ($)': b.actualCost || 'N/A',
    'Fabrication Specs': b.fabricationNotes || '',
    'Archived': b.isArchived ? 'Yes' : 'No'
  }));

  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Custom Builds');

  worksheet['!cols'] = [
    { wch: 15 },
    { wch: 30 },
    { wch: 25 },
    { wch: 15 },
    { wch: 22 },
    { wch: 15 },
    { wch: 15 },
    { wch: 18 },
    { wch: 18 },
    { wch: 18 },
    { wch: 35 },
    { wch: 10 }
  ];

  XLSX.writeFile(workbook, `ForgeFlow_Projects_${new Date().toISOString().split('T')[0]}.xlsx`);
}

// Export Consolidated Enterprise Workbook (All 4 Modules)
export function exportFullWorkbook(
  invoices: Invoice[],
  clients: Client[],
  builds: Build[],
  inventory: InventoryItem[]
) {
  const workbook = XLSX.utils.book_new();

  // 1. Invoices
  const invData = invoices.map(inv => ({
    'Invoice ID': inv.id,
    'Date': inv.date,
    'Client Name': inv.customerName,
    'Project': inv.project,
    'Amount ($)': inv.amount,
    'Status': inv.status
  }));
  const invSheet = XLSX.utils.json_to_sheet(invData);
  invSheet['!cols'] = [{ wch: 15 }, { wch: 15 }, { wch: 25 }, { wch: 25 }, { wch: 15 }, { wch: 12 }];
  XLSX.utils.book_append_sheet(workbook, invSheet, 'Invoices');

  // 2. Clients
  const clientData = clients.map(c => ({
    'Client ID': c.id,
    'Name': c.name,
    'Company': c.company || 'N/A',
    'Email': c.email,
    'Phone': c.phone,
    'Status': c.status,
    'Outstanding ($)': c.outstandingBalance || 0,
    'Lifetime Spend ($)': c.lifetimeSpend || 0
  }));
  const clientSheet = XLSX.utils.json_to_sheet(clientData);
  clientSheet['!cols'] = [{ wch: 12 }, { wch: 22 }, { wch: 22 }, { wch: 25 }, { wch: 16 }, { wch: 10 }, { wch: 18 }, { wch: 18 }];
  XLSX.utils.book_append_sheet(workbook, clientSheet, 'Clients');

  // 3. Projects
  const buildData = builds.map(b => ({
    'Build ID': b.id,
    'Project Name': b.name,
    'Client': b.customerName,
    'Type': b.type,
    'Status': b.status,
    'Estimated ($)': b.estimatedCost,
    'Actual ($)': b.actualCost || 'N/A'
  }));
  const buildSheet = XLSX.utils.json_to_sheet(buildData);
  buildSheet['!cols'] = [{ wch: 12 }, { wch: 25 }, { wch: 22 }, { wch: 20 }, { wch: 14 }, { wch: 15 }, { wch: 15 }];
  XLSX.utils.book_append_sheet(workbook, buildSheet, 'Projects');

  // 4. Inventory
  const invMatData = inventory.map(item => ({
    'Material ID': item.id,
    'Description': item.name,
    'Unit Type': item.unitType,
    'Stock': item.stock
  }));
  const invMatSheet = XLSX.utils.json_to_sheet(invMatData);
  invMatSheet['!cols'] = [{ wch: 12 }, { wch: 30 }, { wch: 15 }, { wch: 12 }];
  XLSX.utils.book_append_sheet(workbook, invMatSheet, 'Inventory');

  XLSX.writeFile(workbook, `ForgeFlow_Enterprise_Database_${new Date().toISOString().split('T')[0]}.xlsx`);
}

/**
 * Parses an uploaded Excel file (.xlsx, .xls, .csv) and returns generic array of records
 */
export async function parseExcelFile(file: File): Promise<{ sheetNames: string[]; data: Record<string, any>[] }> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const buffer = e.target?.result;
        const workbook = XLSX.read(buffer, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        
        // Convert worksheet to JSON rows
        const rows: Record<string, any>[] = XLSX.utils.sheet_to_json(worksheet, { defval: '' });
        
        resolve({
          sheetNames: workbook.SheetNames,
          data: rows
        });
      } catch (err) {
        reject(new Error('Could not parse Excel spreadsheet file. Please check format.'));
      }
    };

    reader.onerror = () => {
      reject(new Error('Failed to read spreadsheet file.'));
    };

    reader.readAsArrayBuffer(file);
  });
}
