/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { StateProvider, useAppState } from './StateContext.tsx';
import { TabType } from './types.ts';
import { DashboardView } from './components/DashboardView.tsx';
import { ClientsView } from './components/ClientsView.tsx';
import { BuildsView } from './components/BuildsView.tsx';
import { BillingView } from './components/BillingView.tsx';
import { SettingsView } from './components/SettingsView.tsx';
import { SyncStatusToast } from './components/SyncStatusToast.tsx';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Menu, 
  Search, 
  LayoutDashboard, 
  Users, 
  Hammer, 
  ReceiptText,
  Clock,
  LogOut,
  Sliders,
  ChevronRight,
  Sparkles,
  Lock,
  Database,
  Settings
} from 'lucide-react';

function AppContent() {
  const { activeTab, setActiveTab, user, logout, globalSearchQuery, setGlobalSearchQuery } = useAppState();
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  // Fallback to avoid empty renders
  if (!user) return null;

  // Render correct view based on active tab state
  const renderActiveView = () => {
    switch (activeTab) {
      case 'dashboard':
        return <DashboardView />;
      case 'clients':
        return <ClientsView />;
      case 'builds':
        return <BuildsView />;
      case 'billing':
        return <BillingView />;
      case 'settings':
        return <SettingsView />;
      default:
        return <BillingView />;
    }
  };

  return (
    <div className="min-h-screen bg-background text-on-background selection:bg-primary-container selection:text-on-background flex flex-col">
      
      {/* TopAppBar */}
      <header className="w-full top-0 sticky border-b border-outline-variant bg-background z-40 flex justify-between items-center px-6 md:px-8 h-16 gap-4">
        <div className="flex items-center gap-4 shrink-0">
          <button 
            id="sidebar-toggle"
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="text-primary hover:text-secondary p-1.5 hover:bg-surface-container-highest transition-colors cursor-pointer rounded-sm"
            title="Toggle Navigation Menu"
          >
            <Menu size={22} />
          </button>
          
          <h1 className="font-narrow text-xl md:text-2xl font-black uppercase tracking-tighter text-primary-container select-none flex items-center gap-1.5">
            <span className="text-primary italic">FRAME SHOP</span>
            <span className="hidden sm:inline">FRAME & ALIGNMENT</span>
          </h1>
        </div>

        {/* Global Search Bar */}
        <div className="flex-1 max-w-md mx-2 md:mx-6 relative">
          <div className="relative flex items-center">
            <Search className="absolute left-3 text-primary pointer-events-none" size={16} />
            <input
              id="global-search-input"
              type="text"
              placeholder="Search name, company, or ID..."
              className="w-full bg-surface-container border border-outline-variant rounded-sm pl-10 pr-8 py-1.5 text-xs font-mono text-on-surface placeholder:text-on-surface-variant/50 focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary transition-all"
              value={globalSearchQuery}
              onChange={(e) => setGlobalSearchQuery(e.target.value)}
            />
            {globalSearchQuery && (
              <button
                id="clear-global-search"
                onClick={() => setGlobalSearchQuery('')}
                className="absolute right-3 text-[10px] font-mono font-bold uppercase tracking-wider text-red-400 hover:text-red-300 transition-colors cursor-pointer"
                title="Clear Search"
              >
                CLEAR
              </button>
            )}
          </div>
        </div>

        {/* Desktop Quick Header Nav */}
        <div className="flex items-center gap-6 shrink-0">
          <div className="hidden md:flex gap-4">
            <button 
              id="top-nav-dashboard"
              onClick={() => setActiveTab('dashboard')}
              className={`font-mono text-xs font-bold uppercase tracking-wider cursor-pointer py-1 transition-all border-b-2 hover:text-primary ${
                activeTab === 'dashboard' ? 'text-primary border-primary' : 'text-on-surface-variant border-transparent'
              }`}
            >
              DASHBOARD
            </button>
            <button 
              id="top-nav-projects"
              onClick={() => setActiveTab('builds')}
              className={`font-mono text-xs font-bold uppercase tracking-wider cursor-pointer py-1 transition-all border-b-2 hover:text-primary ${
                activeTab === 'builds' ? 'text-primary border-primary' : 'text-on-surface-variant border-transparent'
              }`}
            >
              PROJECTS
            </button>
            <button 
              id="top-nav-billing"
              onClick={() => setActiveTab('billing')}
              className={`font-mono text-xs font-bold uppercase tracking-wider cursor-pointer py-1 transition-all border-b-2 hover:text-primary ${
                activeTab === 'billing' ? 'text-primary border-primary' : 'text-on-surface-variant border-transparent'
              }`}
            >
              BILLING
            </button>
            <button 
              id="top-nav-settings"
              onClick={() => setActiveTab('settings')}
              className={`font-mono text-xs font-bold uppercase tracking-wider cursor-pointer py-1 transition-all border-b-2 hover:text-primary ${
                activeTab === 'settings' ? 'text-primary border-primary' : 'text-on-surface-variant border-transparent'
              }`}
            >
              SETTINGS
            </button>
          </div>
          
          {/* Quick info shift telemetry */}
          <div className="flex items-center gap-2">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="hidden leading-none sm:inline font-mono text-[9px] text-[#4caf50] uppercase tracking-widest font-extrabold bg-emerald-950/40 px-2 py-1 border border-emerald-900/60 rounded-xs">
              SHIFT ACTIVE
            </span>
          </div>
        </div>
      </header>

      {/* Main split viewport split container */}
      <div className="flex flex-1 relative">
        
        {/* NavigationDrawer (Desktop Sidebar) */}
        {isSidebarOpen && (
          <aside className="hidden lg:flex flex-col h-[calc(100vh-64px)] w-72 sticky top-16 border-r border-outline-variant bg-surface-container py-6">
            
            {/* Main sidebar links navigation */}
            <nav className="flex flex-col gap-1">
              <button 
                id="side-btn-dashboard"
                onClick={() => setActiveTab('dashboard')}
                className={`flex items-center gap-3.5 px-6 py-3.5 text-left transition-all duration-150 cursor-pointer ${
                  activeTab === 'dashboard' 
                    ? 'bg-primary/10 text-primary border-l-4 border-primary font-bold shadow-md' 
                    : 'text-on-surface-variant hover:bg-surface-container-highest hover:text-on-surface'
                }`}
              >
                <LayoutDashboard size={18} />
                <span className="font-mono text-[11px] font-bold uppercase tracking-wider">Dashboard</span>
              </button>

              <button 
                id="side-btn-clients"
                onClick={() => setActiveTab('clients')}
                className={`flex items-center gap-3.5 px-6 py-3.5 text-left transition-all duration-150 cursor-pointer ${
                  activeTab === 'clients' 
                    ? 'bg-primary/10 text-primary border-l-4 border-primary font-bold shadow-md' 
                    : 'text-on-surface-variant hover:bg-surface-container-highest hover:text-on-surface'
                }`}
              >
                <Users size={18} />
                <span className="font-mono text-[11px] font-bold uppercase tracking-wider">Customers</span>
              </button>

              <button 
                id="side-btn-builds"
                onClick={() => setActiveTab('builds')}
                className={`flex items-center gap-3.5 px-6 py-3.5 text-left transition-all duration-150 cursor-pointer ${
                  activeTab === 'builds' 
                    ? 'bg-primary/10 text-primary border-l-4 border-primary font-bold shadow-md' 
                    : 'text-on-surface-variant hover:bg-surface-container-highest hover:text-on-surface'
                }`}
              >
                <Hammer size={18} />
                <span className="font-mono text-[11px] font-bold uppercase tracking-wider">Projects</span>
              </button>

              <button 
                id="side-btn-billing"
                onClick={() => setActiveTab('billing')}
                className={`flex items-center gap-3.5 px-6 py-3.5 text-left transition-all duration-150 cursor-pointer ${
                  activeTab === 'billing' 
                    ? 'bg-primary/10 text-primary border-l-4 border-primary font-bold shadow-md' 
                    : 'text-on-surface-variant hover:bg-surface-container-highest hover:text-on-surface'
                }`}
              >
                <ReceiptText size={18} />
                <span className="font-mono text-[11px] font-bold uppercase tracking-wider">Billing</span>
              </button>

              <button 
                id="side-btn-settings"
                onClick={() => setActiveTab('settings')}
                className={`flex items-center gap-3.5 px-6 py-3.5 text-left transition-all duration-150 cursor-pointer ${
                  activeTab === 'settings' 
                    ? 'bg-primary/10 text-primary border-l-4 border-primary font-bold shadow-md' 
                    : 'text-on-surface-variant hover:bg-surface-container-highest hover:text-on-surface'
                }`}
              >
                <Settings size={18} />
                <span className="font-mono text-[11px] font-bold uppercase tracking-wider">Settings</span>
              </button>
            </nav>

            {/* Additional bottom actions and telemetry info log details */}
            <div className="mt-auto px-6 flex flex-col gap-4">
              <button
                onClick={logout}
                className="w-full font-mono text-[10px] font-bold uppercase tracking-wider py-2 bg-red-950/20 border border-red-900/40 hover:bg-red-900/20 hover:border-red-800 text-red-400 rounded-sm flex items-center justify-center gap-2 cursor-pointer transition-all hover:scale-[1.01] active:scale-[0.99]"
              >
                <LogOut size={13} />
                <span>Sign Out Shift</span>
              </button>

              <div className="bg-background/40 p-3 border border-outline-variant/40 rounded-xs select-none">
                <span className="text-[9px] font-mono tracking-widest text-primary-container font-black uppercase flex items-center justify-center gap-1">
                  <Sparkles size={11} className="text-amber-400" /> WELDING STATION
                </span>
                <span className="text-[10px] font-mono text-on-surface font-semibold block text-center mt-1">
                  Purge Level: 98.4%
                </span>
              </div>
            </div>
          </aside>
        )}

        {/* Main Content Area */}
        <main className="flex-1 p-6 md:p-10 overflow-x-hidden pb-32">
          
          {/* Framer animated content view panel */}
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.18, ease: "easeOut" }}
            >
              {renderActiveView()}
            </motion.div>
          </AnimatePresence>

        </main>
      </div>

      {/* BottomNavBar (Mobile Layout View Ports Only) */}
      <nav id="bottom-navbar" className="fixed bottom-0 left-0 w-full z-40 flex justify-around items-center px-4 py-2 bg-surface-container-low border-t border-outline-variant md:hidden">
        
        {/* Nav 1 */}
        <button 
          onClick={() => setActiveTab('dashboard')}
          className={`flex flex-col items-center justify-center text-center p-1 cursor-pointer transition-all ${
            activeTab === 'dashboard' ? 'text-primary' : 'text-on-surface-variant'
          }`}
        >
          <LayoutDashboard size={18} />
          <span className="font-mono text-[9px] font-bold uppercase mt-1">Home</span>
        </button>

        {/* Nav 2 */}
        <button 
          onClick={() => setActiveTab('clients')}
          className={`flex flex-col items-center justify-center text-center p-1 cursor-pointer transition-all ${
            activeTab === 'clients' ? 'text-primary' : 'text-on-surface-variant'
          }`}
        >
          <Users size={18} />
          <span className="font-mono text-[9px] font-bold uppercase mt-1">Clients</span>
        </button>

        {/* Nav 3 */}
        <button 
          onClick={() => setActiveTab('builds')}
          className={`flex flex-col items-center justify-center text-center p-1 cursor-pointer transition-all ${
            activeTab === 'builds' ? 'text-primary' : 'text-on-surface-variant'
          }`}
        >
          <Hammer size={18} />
          <span className="font-mono text-[9px] font-bold uppercase mt-1">Builds</span>
        </button>

        {/* Nav 4 */}
        <button 
          onClick={() => setActiveTab('billing')}
          className={`flex flex-col items-center justify-center text-center p-1.5 px-4 rounded-full transition-all ${
            activeTab === 'billing' 
              ? 'bg-primary text-white font-semibold' 
              : 'text-on-surface-variant'
          }`}
        >
          <div className="flex flex-col items-center justify-center">
            <ReceiptText size={18} className={activeTab === 'billing' ? 'text-white' : 'text-on-surface-variant'} />
            <span className="font-mono text-[9px] font-bold uppercase mt-0.5">Billing</span>
          </div>
        </button>

        {/* Nav 5 */}
        <button 
          onClick={() => setActiveTab('settings')}
          className={`flex flex-col items-center justify-center text-center p-1 cursor-pointer transition-all ${
            activeTab === 'settings' ? 'text-primary' : 'text-on-surface-variant'
          }`}
        >
          <Settings size={18} />
          <span className="font-mono text-[9px] font-bold uppercase mt-1">Settings</span>
        </button>
      </nav>

      {/* Sync Status Toast Notification */}
      <SyncStatusToast />
    </div>
  );
}

function LoadingScreen() {
  return (
    <div className="min-h-screen bg-[#0f172a] flex flex-col items-center justify-center p-4">
      <div className="flex flex-col items-center gap-4 text-center">
        <div className="relative flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          <Database className="absolute text-primary" size={16} />
        </div>
        <p className="font-mono text-xs text-slate-400 uppercase tracking-widest">
          CONNECTING LEDGER SYSTEM...
        </p>
      </div>
    </div>
  );
}

function LoginScreen() {
  const { signInWithGoogle } = useAppState();

  return (
    <div className="min-h-screen bg-[#070b13] flex items-center justify-center p-4 relative overflow-hidden">
      {/* Decorative backdrop gradients */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-secondary/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="w-full max-w-md bg-[#0f172a]/90 backdrop-blur-xl border border-slate-800 p-8 md:p-10 rounded-sm shadow-2xl relative z-10">
        
        {/* Branding header */}
        <div className="text-center mb-10">
          <span className="font-mono text-[10px] text-primary bg-primary/10 px-3 py-1 border border-primary/20 rounded-full font-black uppercase tracking-widest inline-flex items-center gap-1.5 mb-4">
            <Sparkles size={11} className="text-amber-400" /> Cloud Database Connected
          </span>
          
          <h1 className="font-narrow text-3xl font-black uppercase tracking-tight text-white leading-none">
            <span className="text-primary italic block text-xl mb-1">FRAME SHOP</span>
            FRAME & ALIGNMENT
          </h1>
          <p className="text-slate-400 text-sm mt-3 font-sans leading-relaxed">
            Real-time multi-user ledger, custom build tracker, and client manager for high-performance fabrication shops.
          </p>
        </div>

        {/* Feature Highlights */}
        <div className="space-y-4 mb-10 bg-slate-900/60 p-4 border border-slate-800/60 rounded-xs">
          <div className="flex items-start gap-3">
            <div className="bg-primary/15 p-1.5 rounded-sm text-primary mt-0.5">
              <Database size={14} />
            </div>
            <div>
              <h4 className="font-mono text-[11px] font-bold text-slate-200 uppercase tracking-wider">Cloud SQL Persistence</h4>
              <p className="text-[11px] text-slate-400 mt-0.5">Safe and durable transactional database storage running on PostgreSQL.</p>
            </div>
          </div>
          
          <div className="flex items-start gap-3">
            <div className="bg-primary/15 p-1.5 rounded-sm text-primary mt-0.5">
              <Lock size={14} />
            </div>
            <div>
              <h4 className="font-mono text-[11px] font-bold text-slate-200 uppercase tracking-wider">Firebase Authentication</h4>
              <p className="text-[11px] text-slate-400 mt-0.5">Secure Google account sign-in protecting your invoices, clients, and blueprints.</p>
            </div>
          </div>
        </div>

        {/* Action Button */}
        <div>
          <button
            onClick={signInWithGoogle}
            className="w-full py-3 px-4 bg-primary hover:bg-secondary text-white font-mono text-xs font-bold uppercase tracking-wider rounded-sm transition-all duration-150 flex items-center justify-center gap-3 shadow-lg hover:shadow-primary/20 cursor-pointer"
          >
            <svg className="h-4 w-4 fill-current" viewBox="0 0 24 24">
              <path d="M12.24 10.285V13.4h6.887C18.2 15.614 15.645 18 12.24 18c-3.86 0-7-3.14-7-7s3.14-7 7-7c1.7 0 3.3.6 4.6 1.8l2.4-2.4C17.3 1.5 14.9 0 12.24 0 6.03 0 1 5.03 1 11s5.03 11 11.24 11c5.83 0 10.76-4.11 10.76-11 0-.7-.1-1.4-.24-1.715H12.24z"/>
            </svg>
            <span>Sign In with Google</span>
          </button>
        </div>

        {/* Footer info line */}
        <div className="text-center mt-8 pt-6 border-t border-slate-800/60">
          <p className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">
            SECURE WELDING PORTAL v2.1.0
          </p>
        </div>
      </div>
    </div>
  );
}

function MainAppSelector() {
  const { user, loading } = useAppState();

  if (loading) {
    return <LoadingScreen />;
  }

  if (!user) {
    return <LoginScreen />;
  }

  return <AppContent />;
}

export default function App() {
  return (
    <StateProvider>
      <MainAppSelector />
    </StateProvider>
  );
}
