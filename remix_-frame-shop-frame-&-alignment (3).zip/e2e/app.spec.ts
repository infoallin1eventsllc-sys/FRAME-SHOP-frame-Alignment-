import { test, expect } from '@playwright/test';

test.describe('App Smoke Test', () => {
  test('should load the main page successfully', async ({ page }) => {
    await page.goto('/');
    // Check that the page loads without crashing
    await expect(page).toHaveTitle(/./);
  });
});
