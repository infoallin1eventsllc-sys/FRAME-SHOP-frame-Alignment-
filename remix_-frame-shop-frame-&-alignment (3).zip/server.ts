import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { requireAuth, AuthRequest } from './src/middleware/auth.ts';
import { getOrCreateUser } from './src/db/users.ts';
import {
  seedUserIfNeeded,
  getClients,
  addClient,
  deleteClient,
  getBuilds,
  addBuild,
  updateBuildStatus,
  addBuildNote,
  deleteBuild,
  updateBuildFabricationNotes,
  archiveBuild,
  getInvoices,
  addInvoice,
  deleteInvoice,
  updateInvoiceStatus
} from './src/db/queries.ts';

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Setup JSON body parsing middleware
  app.use(express.json());

  // API Routes
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok' });
  });

  // Auth synchronization endpoint
  app.post('/api/auth/register', requireAuth, async (req: AuthRequest, res) => {
    try {
      const { uid, email } = req.user!;
      if (!email) {
        return res.status(400).json({ error: 'Email is required from Auth token' });
      }
      const user = await getOrCreateUser(uid, email);
      // Seed user with default records if they have none yet
      await seedUserIfNeeded(user.id);
      res.json({ user });
    } catch (error: any) {
      console.error('Failed in /api/auth/register:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Clients Endpoints
  app.get('/api/clients', requireAuth, async (req: AuthRequest, res) => {
    try {
      const { uid, email } = req.user!;
      const user = await getOrCreateUser(uid, email || '');
      const clientsList = await getClients(user.id);
      res.json(clientsList);
    } catch (error: any) {
      console.error('Failed to get clients:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/clients', requireAuth, async (req: AuthRequest, res) => {
    try {
      const { uid, email } = req.user!;
      const user = await getOrCreateUser(uid, email || '');
      const clientData = req.body;
      await addClient(user.id, clientData);
      res.status(201).json({ success: true });
    } catch (error: any) {
      console.error('Failed to add client:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/clients/:id', requireAuth, async (req: AuthRequest, res) => {
    try {
      const { uid, email } = req.user!;
      const user = await getOrCreateUser(uid, email || '');
      const clientId = req.params.id;
      await deleteClient(user.id, clientId);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to delete client:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Builds Endpoints
  app.get('/api/builds', requireAuth, async (req: AuthRequest, res) => {
    try {
      const { uid, email } = req.user!;
      const user = await getOrCreateUser(uid, email || '');
      const buildsList = await getBuilds(user.id);
      res.json(buildsList);
    } catch (error: any) {
      console.error('Failed to get builds:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/builds', requireAuth, async (req: AuthRequest, res) => {
    try {
      const { uid, email } = req.user!;
      const user = await getOrCreateUser(uid, email || '');
      const buildData = req.body;
      await addBuild(user.id, buildData);
      res.status(201).json({ success: true });
    } catch (error: any) {
      console.error('Failed to add build:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.put('/api/builds/:id/status', requireAuth, async (req: AuthRequest, res) => {
    try {
      const { uid, email } = req.user!;
      const user = await getOrCreateUser(uid, email || '');
      const buildId = req.params.id;
      const { status, actualCost, completionDate, noteToAppend } = req.body;
      await updateBuildStatus(user.id, buildId, status, actualCost, completionDate, noteToAppend);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to update build status:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.put('/api/builds/:id/fabrication-notes', requireAuth, async (req: AuthRequest, res) => {
    try {
      const { uid, email } = req.user!;
      const user = await getOrCreateUser(uid, email || '');
      const buildId = req.params.id;
      const { fabricationNotes } = req.body;
      await updateBuildFabricationNotes(user.id, buildId, fabricationNotes);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to update build fabrication notes:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.put('/api/builds/:id/archive', requireAuth, async (req: AuthRequest, res) => {
    try {
      const { uid, email } = req.user!;
      const user = await getOrCreateUser(uid, email || '');
      const buildId = req.params.id;
      const { isArchived } = req.body;
      await archiveBuild(user.id, buildId, isArchived);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to archive build:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/builds/:id/note', requireAuth, async (req: AuthRequest, res) => {
    try {
      const { uid, email } = req.user!;
      const user = await getOrCreateUser(uid, email || '');
      const buildId = req.params.id;
      const { note } = req.body;
      await addBuildNote(user.id, buildId, note);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to add build note:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/builds/:id', requireAuth, async (req: AuthRequest, res) => {
    try {
      const { uid, email } = req.user!;
      const user = await getOrCreateUser(uid, email || '');
      const buildId = req.params.id;
      await deleteBuild(user.id, buildId);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to delete build:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Invoices Endpoints
  app.get('/api/invoices', requireAuth, async (req: AuthRequest, res) => {
    try {
      const { uid, email } = req.user!;
      const user = await getOrCreateUser(uid, email || '');
      const invoicesList = await getInvoices(user.id);
      res.json(invoicesList);
    } catch (error: any) {
      console.error('Failed to get invoices:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/invoices', requireAuth, async (req: AuthRequest, res) => {
    try {
      const { uid, email } = req.user!;
      const user = await getOrCreateUser(uid, email || '');
      const invoiceData = req.body;
      await addInvoice(user.id, invoiceData);
      res.status(201).json({ success: true });
    } catch (error: any) {
      console.error('Failed to add invoice:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/invoices/send-email', requireAuth, async (req: AuthRequest, res) => {
    try {
      const { uid, email } = req.user!;
      await getOrCreateUser(uid, email || '');
      const { invoiceId, recipientEmail, recipientName, subject, message, amount, project } = req.body;

      if (!recipientEmail || !recipientEmail.includes('@')) {
        return res.status(400).json({ error: 'Valid recipient email address is required.' });
      }

      const sentAt = new Date().toLocaleString('en-US', {
        dateStyle: 'medium',
        timeStyle: 'short'
      });

      console.log(`[EMAIL DISPATCH] Sent invoice ${invoiceId} to ${recipientEmail} (${recipientName || 'Client'})`);

      res.json({
        success: true,
        invoiceId,
        recipientEmail,
        sentAt,
        message: `Invoice #${invoiceId} ($${Number(amount || 0).toLocaleString()}) successfully dispatched via secure SMTP proxy to ${recipientEmail}.`
      });
    } catch (error: any) {
      console.error('Failed to send invoice email:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.put('/api/invoices/:id/status', requireAuth, async (req: AuthRequest, res) => {
    try {
      const { uid, email } = req.user!;
      const user = await getOrCreateUser(uid, email || '');
      const invoiceId = req.params.id;
      const { status } = req.body;
      await updateInvoiceStatus(user.id, invoiceId, status);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to update invoice status:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/invoices/:id', requireAuth, async (req: AuthRequest, res) => {
    try {
      const { uid, email } = req.user!;
      const user = await getOrCreateUser(uid, email || '');
      const invoiceId = req.params.id;
      await deleteInvoice(user.id, invoiceId);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to delete invoice:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Vite development middleware vs Static Production files serving
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
